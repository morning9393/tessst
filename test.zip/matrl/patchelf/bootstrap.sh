#! /bin/sh -e
autoreconf --verbose --install --force --warnings=all
