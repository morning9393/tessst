#include <stdio.h>

int bar()
{
    printf("This is bar()!\n");
    return 34;
}
