#include <stdio.h>

char buf[16 * 1024 * 1024];

int main(int argc, char * * argv)
{
    printf("Hello World\n");
    return 0;
}
