import numpy as np

n = 10
f = open("./matrix10.txt", "w")

code = ""
adv_lines = ""
adv_list = []
for i in range(1, 2**n):
    encoded = str(bin(i))[2:].zfill(n)
    var_name = "adv_"
    policies = ""
    for j in range(0, n):
        if encoded[j] == '0':
            var_name += 'o'
            policies += '\"original\",'
        else:
            var_name += 't'
            policies += '\"tmp\",'
    policies = policies[:-1]

    l = var_name + " = self.calculate_policy_adv(i, [" + policies + "])\n"
    adv_lines += l
    adv_list.append(var_name)

adv_list.insert(0, 0)
# print(adv_list)
A_shape = [2] * n
# print(A_shape)
A = np.array(adv_list).reshape(A_shape)
A = ','.join(str(A).split())

A_str = "A = np.array(" + A + ")"
A_str = A_str.replace("'", '')
print(A_str)

f.write(adv_lines + '\n\n' + A_str)
f.close()