import matplotlib.pyplot as plt
import numpy as np

episode = []
win_rate = []
reward = []

with open('./test_log.txt') as out:
    lines = out.readlines()
    for l in lines:
        line = l.split()
        episode.append(float(line[1].replace(',', '')))
        reward.append(float(line[4].replace(',', '')))
        win_rate.append(float(line[6].replace(',', '')))

l = len(episode)

plt.plot(episode[:l], win_rate[:l])
plt.grid()
plt.title('Combat 2v2')
plt.xlabel('# Episode')
plt.ylabel('Rate (%)')
plt.legend(["Win"])
plt.show()

plt.plot(episode[:l], reward[:l])
plt.grid()
plt.title('Combat 2v2')
plt.xlabel('# Episode (k)')
plt.ylabel('Reward')
plt.show()
