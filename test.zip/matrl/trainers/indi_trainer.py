from trainers.trainer import Trainer
import numpy as np
import time


class IndiTrainer(Trainer):
    def __init__(self, env, num_agents, config):
        super().__init__(env, num_agents, config)
        self.keys = [
            "total_loss",
            "policy_loss",
            "value_loss",
            "kl",
            "entropy",
            "policy_ratio",
            "clip_ratio",
            "adv",
            "value",
            "episode_return",
            "episode_length",
        ]

    def run_one_epoch(self, policies):
        """
        this function execute the multi agent game for one episode
        """
        # obs_n = self.env.reset()
        obs_n, rew_n, done_n, ep_ret_n, ep_len = (
            # np.expand_dims(np.array(self.env.reset()).flatten(), 0).repeat(self.num_agent, axis=0),
            self.env.reset(),
            # self.encode_obs(obs_n),
            [0 for i in range(self.num_agent)],
            False,
            [0 for i in range(self.num_agent)],
            0,
        )
        for t in range(self.local_steps_per_epoch):
            if self.is_rnn:
                self.buf.store_pure_obs(obs_n)
                obs_n = self.buf.get_rnn_obs(obs_n)
            act_n, val_t_n, logp_t_n = self.get_actions(obs_n, policies)
            obs_n_next, rew_n, done_n, info = self.env.step(act_n)

            terminal = np.all(done_n) or (ep_len == self.config["max_ep_len"])

            if type(rew_n) not in [list, np.ndarray]:
                rew_n = [rew_n] * self.num_agent

            for i in range(self.num_agent):
                if act_n[i] > 4 and rew_n[i] > 0:
                    rew_n[i] += 1
                if terminal and info['win']:
                    rew_n[i] += 100

            ep_ret_n = [n + r for n, r in zip(ep_ret_n, rew_n)]
            ep_len += 1
            # collect data
            act_n = np.array(act_n).reshape((len(obs_n), -1))
            self.buf.store(obs_n, np.array(act_n), rew_n, val_t_n, logp_t_n)
            self.logger.store({"value": val_t_n}, [i for i in range(self.num_agent)])

            obs_n = obs_n_next
            # obs_n = np.expand_dims(np.array(obs_n_next).flatten(), 0).repeat(self.num_agent, axis=0)
            # obs_n = self.encode_obs(obs_n_next)

            # terminal = np.all(done_n) or (ep_len == self.config["max_ep_len"])
            if terminal or (t == self.local_steps_per_epoch - 1):
                if not (terminal):
                    if self.is_rnn:
                        obs_n = self.buf.get_rnn_obs(obs_n)
                    print("Warning: trajectory cut off by epoch at %d steps." % ep_len)
                    last_val_n = (
                        [0 for i in range(self.num_agent)]
                        if np.all(done_n)
                        else self.get_value(obs_n, policies)
                    )
                    self.buf.finish_path(last_val_n)
                else:
                    for i in range(len(self.agents)):
                        self.logger.store(
                            {"episode_return": ep_ret_n, "episode_length": [ep_len] * self.num_agent},
                            [i for i in range(self.num_agent)],
                        )
                    last_val_n = (
                        [0 for i in range(self.num_agent)]
                        if np.all(done_n)
                        else self.get_value(obs_n, policies)
                    )
                    self.buf.finish_path(last_val_n)

                # obs_n = self.env.reset()
                obs_n, rew_n, done_n, ep_ret_n, ep_len = (
                    # np.expand_dims(np.array(self.env.reset()).flatten(), 0).repeat(self.num_agent, axis=0),
                    self.env.reset(),
                    # self.encode_obs(obs_n),
                    [0 for i in range(self.num_agent)],
                    False,
                    [0 for i in range(self.num_agent)],
                    0,
                )

    def global_obs(self):
        grid = self.env._full_obs
        agent_h = self.env.agent_health
        opp_h = self.env.opp_health
        agent_c = self.env._agent_cool
        opp_c = self.env._opp_cool
        # pos = self.env.agent_pos
        # grid_shape = self.env._grid_shape
        obs = np.zeros((4, 15, 15))
        for row in range(0, 15):
            for col in range(0, 15):
                if PRE_IDS['empty'] not in grid[row][col]:
                    x = grid[row][col]
                    _type = 1 if PRE_IDS['agent'] in x else -1
                    _id = int(x[1:]) - 1  # id
                    obs[0][row][col] = _type
                    obs[1][row][col] = _id
                    obs[2][row][col] = agent_h[_id] if _type == 1 else opp_h[_id]
                    obs[3][row][col] = agent_c[_id] if _type == 1 else opp_c[_id]
                    obs[3][row][col] = 1 if obs[3][row][col] else -1
        obs = np.expand_dims(obs.flatten(), 0).repeat(self.num_agent, axis=0)
        return obs

    def encode_obs(self, obs_n):
        global_obs = self.global_obs()
        encoded_obs = np.concatenate((global_obs, obs_n), axis=-1)
        return encoded_obs

    def rollouts(self, epochs, policies):
        """
        this function will execute the game for multiple episodes to collect the data save to buffer
        """
        for _ in range(epochs):
            self.run_one_epoch(policies)

    def get_actions(self, obs_n, policies):
        actions = []
        values = []
        logps = []
        for i in range(len(policies)):
            action, value, logp = self.agents[i].get_action(
                self.sess, obs_n[i], policies[i]
            )
            actions.append(action[0])
            values.append(value[0])
            logps.append(logp[0])
        return actions, values, logps

    def get_value(self, obs_n, policies):
        # obs_n [batch, num_agent, space_shape]
        values = []
        for i in range(len(policies)):
            value = self.agents[i].get_value(self.sess, obs_n[i], policies[i])
            values.append(value[0])
        return values

    def update_policies(self):
        data = self.buf.get()
        for i in range(self.num_agent):
            agent_data = [item[:, i] for item in data]
            total_loss, p_loss, v_loss, kl, ent, ratio, clip_ratio = self.agents[
                i
            ].update_original_policy(self.sess, agent_data)

            self.logger.store(
                {
                    "total_loss": total_loss,
                    "policy_loss": p_loss,
                    "value_loss": v_loss,
                    "kl": kl,
                    "entropy": ent,
                    "policy_ratio": np.mean(ratio),
                    "clip_ratio": clip_ratio,
                    "adv": np.mean(data[i][2]),
                },
                agent=[i],
            )
        self.buf.clear()

    def train(self):
        for epoch in range(self.config["epochs"]):
            self.rollouts(self.config["tmp_rollout_epochs"], ["original"] * self.num_agent)
            self.update_policies()

            self.test(epoch)

            self.logger.dump(
                self.keys,
                agents=[i for i in range(len(self.agents))],
                step=epoch,
                mean_only=True,
            )

            if epoch % self.config["save_frequency"] == 0:
                print("--- the model has been saved ---")
                self.save(epoch)

    def test(self, e):
        all_rewards = []
        all_wins = 0
        for i in range(101):
            done_n = [False for _ in range(self.num_agent)]
            ep_reward = 0
            obs_n = self.env.reset()
            # obs_n = np.expand_dims(np.array(self.env.reset()).flatten(), 0).repeat(self.num_agent, axis=0)
            # obs_n = self.env.reset()
            # obs_n = self.encode_obs(obs_n)
            info = None
            while not all(done_n):
                action_n, _, __ = self.get_actions(obs_n, ["original"] * self.num_agent)
                obs_n, reward_n, done_n, info = self.env.step(action_n)
                # obs_n = np.expand_dims(np.array(obs_n).flatten(), 0).repeat(self.num_agent, axis=0)
                # obs_n = self.encode_obs(obs_n)
                if i == 100:
                    self.env.render()
                    time.sleep(0.04)
                else:
                    ep_reward += sum(reward_n)
            if i != 100:
                if info['win']:
                    all_wins += 1
                all_rewards.append(ep_reward)
        aver_ret = np.mean(all_rewards)
        win_rate = all_wins / 100
        print("episode: %s, aver reward: %s, win_rate: %s \n" % (e, aver_ret, win_rate))
        f = open("./test_log.txt", "a")
        f.write("episode: %s, aver reward: %s, win_rate: %s\n" % (e, aver_ret, win_rate))
        f.close()


PRE_IDS = {
    'wall': 'W',
    'empty': 'E',
    'agent': 'A',
    'opponent': 'X',
}
