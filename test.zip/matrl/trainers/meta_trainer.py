from trainers.indi_trainer import IndiTrainer
import numpy as np
from nash_solver3.game import Game
from matrix_games.util import check_all_positive
import time

class MetaTrainer(IndiTrainer):
    def __init__(self, env, num_agents, config):
        super().__init__(env, num_agents, config)
        # init policy and tmp policy with same set of weights
        for agent in self.agents:
            agent.update_policy(self.sess, [i for i in range(self.num_agent)])
        self.keys.append("nash_pair")
        if config["br"]:
            self.keys.append("br_policy_loss")
            self.keys.append("br_importance_rate")

    def update_tmp_policies(self):
        """
        This function updates the tmp policy based on the rollouts data
        """
        data = self.buf.get()

        for i in range(self.num_agent):
            agent_data = [item[:, i] for item in data]
            agent = self.agents[i]
            total_loss, p_loss, v_loss, kl, ent, ratio, clip_ratio = agent.update_tmp(
                self.sess, agent_data
            )
            self.logger.store(
                {
                    "total_loss": total_loss,
                    "policy_loss": p_loss,
                    "value_loss": v_loss,
                    "kl": kl,
                    "entropy": ent,
                    "policy_ratio": np.mean(ratio),
                    "clip_ratio": clip_ratio,
                    "adv": np.mean(data[i][2]),
                },
                agent=[i],
            )
        self.buf.keep_tmp_buf()
        self.buf.clear()

    def update_policies_with_nash(self):
        meta_policies_weight = self.calculate_meta_game_policies()
        for i in range(len(self.agents)):
            self.agents[i].update_policy(self.sess, meta_policies_weight[i])

    def calculate_meta_game_policies(self):
        """TODO: use the trajectories calculated to get the meta game and then get the next policy based on meta game result 
        1. rollouts with different combinations of policies 

        """
        if self.config["meta"]:
            matrix = self.compute_payoff_matrix()
            game = {
                "name": "generated game",
                "players": ["Player {}".format(i) for i in range(self.num_agent)],
                "num_players": self.num_agent,
                "shape": [2 for i in range(self.num_agent)],
                "sum_shape": sum([2 for i in range(self.num_agent)]),
                "array": matrix,
            }

            g = Game(game)
            result = g.findEquilibria(self.config["nash_method"])
            if result == None:
                result = [[1, 0] for i in range(self.num_agent)]
            else:
                result[0].normalize()
                result = result[0]._list
                if not check_all_positive(result):
                    result = [[1, 0] for i in range(self.num_agent)]
        else:
            result = [[0, 1] for i in range(self.num_agent)]
        self.logger.store(
            {"nash_pair": [i[0] for i in result]},
            agent=[i for i in range(self.num_agent)],
        )
        return result

    def calculate_policy_adv(self, main_agent, policies):
        if self.config["meta_rollouts"]:
            # do rollouts to get the advantage
            self.rollouts(self.config["meta_rollout_epochs"], policies)
            # calculate the policy advantage
            data = self.buf.get_tmp()
            adv_data = data[2][:, main_agent]
            # clear the buffer after each rollouts
            self.buf.clear()
            return np.mean(adv_data)
        else:
            # use the policy ratio and the rollout experiments to calculate the advantage
            data = self.buf.get_tmp()
            ratio = 1
            for i in range(self.num_agent):
                ratio *= self.agents[i].get_logp_ratio(
                    self.sess,
                    data[0][:, i, :],
                    data[1][:, i],
                    data[4][:, i],
                    policies[i],
                )
            adv_data = data[2][:, main_agent]
            return np.mean(adv_data) * np.mean(ratio)

    def two_player_matrix_constructor(self):
        matrix = []
        for i in range(self.num_agent):
            adv_origin_tmp = self.calculate_policy_adv(i, ["original", "tmp"])
            adv_tmp_origin = self.calculate_policy_adv(i, ["tmp", "original"])
            adv_tmp_tmp = self.calculate_policy_adv(i, ["tmp", "tmp"])
            A = np.array([[0, adv_origin_tmp], [adv_tmp_origin, adv_tmp_tmp], ])
            matrix.append(A)
        return matrix

    def three_player_matrix_constructor(self):
        matrix = []
        for i in range(self.num_agent):
            adv_origin_origin_tmp = self.calculate_policy_adv(
                i, ["original", "original", "tmp"]
            )
            adv_origin_tmp_origin = self.calculate_policy_adv(
                i, ["original", "tmp", "original"]
            )
            adv_origin_tmp_tmp = self.calculate_policy_adv(
                i, ["original", "tmp", "tmp"]
            )
            adv_tmp_origin_origin = self.calculate_policy_adv(
                i, ["tmp", "original", "origin"]
            )
            adv_tmp_origin_tmp = self.calculate_policy_adv(
                i, ["tmp", "original", "tmp"]
            )
            adv_tmp_tmp_origin = self.calculate_policy_adv(
                i, ["tmp", "tmp", "original"]
            )
            adv_tmp_tmp_tmp = self.calculate_policy_adv(i, ["tmp", "tmp", "tmp"])

            A = np.array(
                [
                    [
                        [0, adv_origin_origin_tmp],
                        [adv_origin_tmp_origin, adv_origin_tmp_tmp],
                    ],
                    [
                        [adv_tmp_origin_origin, adv_tmp_origin_tmp],
                        [adv_tmp_tmp_origin, adv_tmp_tmp_tmp],
                    ],
                ]
            )
            matrix.append(A)
        return matrix

    def four_player_matrix_constructor(self):
        matrix = []
        for i in range(self.num_agent):
            adv_origin_origin_origin_tmp = self.calculate_policy_adv(
                i, ["original", "original", "original", "tmp"]
            )
            adv_origin_origin_tmp_origin = self.calculate_policy_adv(
                i, ["original", "original", "tmp", "origin"]
            )
            adv_origin_origin_tmp_tmp = self.calculate_policy_adv(
                i, ["original", "original", "tmp", "tmp"]
            )
            adv_origin_tmp_origin_origin = self.calculate_policy_adv(
                i, ["original", "tmp", "original", "origin"]
            )
            adv_origin_tmp_origin_tmp = self.calculate_policy_adv(
                i, ["original", "tmp", "original", "tmp"]
            )
            adv_origin_tmp_tmp_origin = self.calculate_policy_adv(
                i, ["original", "tmp", "tmp", "origin"]
            )
            adv_origin_tmp_tmp_tmp = self.calculate_policy_adv(
                i, ["original", "tmp", "tmp", "tmp"]
            )

            adv_tmp_origin_origin_origin = self.calculate_policy_adv(
                i, ["tmp", "original", "original", "original"]
            )
            adv_tmp_origin_origin_tmp = self.calculate_policy_adv(
                i, ["tmp", "original", "original", "tmp"]
            )
            adv_tmp_origin_tmp_origin = self.calculate_policy_adv(
                i, ["tmp", "original", "tmp", "origin"]
            )
            adv_tmp_origin_tmp_tmp = self.calculate_policy_adv(
                i, ["tmp", "original", "tmp", "tmp"]
            )
            adv_tmp_tmp_origin_origin = self.calculate_policy_adv(
                i, ["tmp", "tmp", "original", "origin"]
            )
            adv_tmp_tmp_origin_tmp = self.calculate_policy_adv(
                i, ["tmp", "tmp", "original", "tmp"]
            )
            adv_tmp_tmp_tmp_origin = self.calculate_policy_adv(
                i, ["tmp", "tmp", "tmp", "origin"]
            )
            adv_tmp_tmp_tmp_tmp = self.calculate_policy_adv(
                i, ["tmp", "tmp", "tmp", "tmp"]
            )

            A = np.array(
                [
                    [
                        [
                            [0, adv_origin_origin_origin_tmp],
                            [adv_origin_origin_tmp_origin, adv_origin_origin_tmp_tmp],
                        ],
                        [
                            [adv_origin_tmp_origin_origin, adv_origin_tmp_origin_tmp],
                            [adv_origin_tmp_tmp_origin, adv_origin_tmp_tmp_tmp],
                        ],
                    ],
                    [
                        [
                            [adv_tmp_origin_origin_origin, adv_tmp_origin_origin_tmp],
                            [adv_tmp_origin_tmp_origin, adv_tmp_origin_tmp_tmp],
                        ],
                        [
                            [adv_tmp_tmp_origin_origin, adv_tmp_tmp_origin_tmp],
                            [adv_tmp_tmp_tmp_origin, adv_tmp_tmp_tmp_tmp],
                        ],
                    ],
                ]
            )
            matrix.append(A)
        return matrix

    def compute_payoff_matrix(self):
        if self.num_agent == 2:
            return self.two_player_matrix_constructor()
        if self.num_agent == 3:
            return self.three_player_matrix_constructor()
        if self.num_agent == 4:
            return self.four_player_matrix_constructor()
        if self.num_agent == 5:
            return self.five_player_matrix_constructor()
        if self.num_agent == 10:
            return self.ten_player_matrix_constructor()

    def calculate_importance_ratio(self, agent_idx, data, policies):
        importance_ratio = []

        for i in range(self.num_agent):
            if i != agent_idx:
                logp_tmp = data[-1][:, i]
                obs = data[0][:, i]
                act = data[1][:, i]
                logp_ratio = self.agents[i].get_logp_ratio(
                    self.sess, obs, act, logp_tmp, policies[i]
                )
                importance_ratio.append(logp_ratio)
        return np.mean(importance_ratio, axis=1)

    def compute_br_policies(self):
        data_tmp = self.buf.get_tmp()

        for i in range(self.num_agent):
            i_ratio = self.calculate_importance_ratio(
                i, data_tmp, ["tmp" for i in range(self.num_agent)]
            )
            agent_data = [item[:, i] for item in data_tmp]
            agent = self.agents[i]
            p_loss = agent.br_update(self.sess, agent_data, i_ratio)
            self.logger.store(
                {"br_policy_loss": p_loss, "br_importance_rate": i_ratio, }, [i]
            )

    def train(self):

        for epoch in range(self.config["epochs"]):
            # update the tmp policies of agents
            self.rollouts(1, ["original"] * self.num_agent)
            self.update_tmp_policies()
            # use the tmo policies to construct the meta game payoff matrix
            # update the original policies with the nash pair outputed by nash solver
            self.update_policies_with_nash()
            if self.config["br"]:
                self.compute_br_policies()
            # # Log info about epoch

            self.test(epoch)

            self.logger.dump(
                self.keys,
                agents=[i for i in range(len(self.agents))],
                step=epoch,
                mean_only=True,
            )
            if epoch % self.config["save_frequency"] == 0:
                print("--- the model has been saved ---")
                self.save(step=epoch)

    def test(self, e):
        all_rewards = []
        all_wins = 0
        for i in range(101):
            done_n = [False for _ in range(self.num_agent)]
            ep_reward = 0
            obs_n = self.env.reset()
            # obs_n = np.expand_dims(np.array(self.env.reset()).flatten(), 0).repeat(self.num_agent, axis=0)
            # obs_n = self.env.reset()
            # obs_n = self.encode_obs(obs_n)
            info = None
            while not all(done_n):
                action_n, _, __ = self.get_actions(obs_n, ["original"] * self.num_agent)
                obs_n, reward_n, done_n, info = self.env.step(action_n)
                # obs_n = np.expand_dims(np.array(obs_n).flatten(), 0).repeat(self.num_agent, axis=0)
                # obs_n = self.encode_obs(obs_n)
                if i == 100:
                    self.env.render()
                    time.sleep(0.04)
                else:
                    ep_reward += sum(reward_n)
            if i != 100:
                if info['win']:
                    all_wins += 1
                all_rewards.append(ep_reward)
        aver_ret = np.mean(all_rewards)
        win_rate = all_wins / 100
        print("episode: %s, aver reward: %s, win_rate: %s \n" % (e, aver_ret, win_rate))
        f = open("./test_log.txt", "a")
        f.write("episode: %s, aver reward: %s, win_rate: %s\n" % (e, aver_ret, win_rate))
        f.close()

    # auto-gen
    def five_player_matrix_constructor(self):
        matrix = []
        for i in range(self.num_agent):
            adv_oooot = self.calculate_policy_adv(i, ["original", "original", "original", "original", "tmp"])
            adv_oooto = self.calculate_policy_adv(i, ["original", "original", "original", "tmp", "original"])
            adv_ooott = self.calculate_policy_adv(i, ["original", "original", "original", "tmp", "tmp"])
            adv_ootoo = self.calculate_policy_adv(i, ["original", "original", "tmp", "original", "original"])
            adv_ootot = self.calculate_policy_adv(i, ["original", "original", "tmp", "original", "tmp"])
            adv_ootto = self.calculate_policy_adv(i, ["original", "original", "tmp", "tmp", "original"])
            adv_oottt = self.calculate_policy_adv(i, ["original", "original", "tmp", "tmp", "tmp"])
            adv_otooo = self.calculate_policy_adv(i, ["original", "tmp", "original", "original", "original"])
            adv_otoot = self.calculate_policy_adv(i, ["original", "tmp", "original", "original", "tmp"])
            adv_ototo = self.calculate_policy_adv(i, ["original", "tmp", "original", "tmp", "original"])
            adv_otott = self.calculate_policy_adv(i, ["original", "tmp", "original", "tmp", "tmp"])
            adv_ottoo = self.calculate_policy_adv(i, ["original", "tmp", "tmp", "original", "original"])
            adv_ottot = self.calculate_policy_adv(i, ["original", "tmp", "tmp", "original", "tmp"])
            adv_ottto = self.calculate_policy_adv(i, ["original", "tmp", "tmp", "tmp", "original"])
            adv_otttt = self.calculate_policy_adv(i, ["original", "tmp", "tmp", "tmp", "tmp"])
            adv_toooo = self.calculate_policy_adv(i, ["tmp", "original", "original", "original", "original"])
            adv_tooot = self.calculate_policy_adv(i, ["tmp", "original", "original", "original", "tmp"])
            adv_tooto = self.calculate_policy_adv(i, ["tmp", "original", "original", "tmp", "original"])
            adv_toott = self.calculate_policy_adv(i, ["tmp", "original", "original", "tmp", "tmp"])
            adv_totoo = self.calculate_policy_adv(i, ["tmp", "original", "tmp", "original", "original"])
            adv_totot = self.calculate_policy_adv(i, ["tmp", "original", "tmp", "original", "tmp"])
            adv_totto = self.calculate_policy_adv(i, ["tmp", "original", "tmp", "tmp", "original"])
            adv_tottt = self.calculate_policy_adv(i, ["tmp", "original", "tmp", "tmp", "tmp"])
            adv_ttooo = self.calculate_policy_adv(i, ["tmp", "tmp", "original", "original", "original"])
            adv_ttoot = self.calculate_policy_adv(i, ["tmp", "tmp", "original", "original", "tmp"])
            adv_ttoto = self.calculate_policy_adv(i, ["tmp", "tmp", "original", "tmp", "original"])
            adv_ttott = self.calculate_policy_adv(i, ["tmp", "tmp", "original", "tmp", "tmp"])
            adv_tttoo = self.calculate_policy_adv(i, ["tmp", "tmp", "tmp", "original", "original"])
            adv_tttot = self.calculate_policy_adv(i, ["tmp", "tmp", "tmp", "original", "tmp"])
            adv_tttto = self.calculate_policy_adv(i, ["tmp", "tmp", "tmp", "tmp", "original"])
            adv_ttttt = self.calculate_policy_adv(i, ["tmp", "tmp", "tmp", "tmp", "tmp"])

            A = np.array([[[[[0, adv_oooot], [adv_oooto, adv_ooott]], [[adv_ootoo, adv_ootot], [adv_ootto, adv_oottt]]],
                           [[[adv_otooo, adv_otoot], [adv_ototo, adv_otott]],
                            [[adv_ottoo, adv_ottot], [adv_ottto, adv_otttt]]]], [
                              [[[adv_toooo, adv_tooot], [adv_tooto, adv_toott]],
                               [[adv_totoo, adv_totot], [adv_totto, adv_tottt]]],
                              [[[adv_ttooo, adv_ttoot], [adv_ttoto, adv_ttott]],
                               [[adv_tttoo, adv_tttot], [adv_tttto, adv_ttttt]]]]])
            matrix.append(A)
        return matrix

    def ten_player_matrix_constructor(self):
        matrix = []
        for i in range(self.num_agent):
            A = None
            matrix.append(A)
        return matrix
