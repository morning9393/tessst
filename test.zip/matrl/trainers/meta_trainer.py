from trainers.indi_trainer import IndiTrainer
import numpy as np
import tensorflow as tf
import gym
import time
import utils.core as core
from spinup.utils.mpi_tf import sync_all_params
from spinup.utils.mpi_tools import mpi_fork, num_procs
from spinup.utils.run_utils import setup_logger_kwargs
import yaml
import os
from datetime import datetime
from nash_solver3.game import Game
from matrix_games.util import check_all_positive


class MetaTrainer(IndiTrainer):
    def __init__(self, env, num_agents, config):
        super().__init__(env, num_agents, config)
        # init policy and tmp policy with same set of weights
        for agent in self.agents:
            agent.update_policy(self.sess, [i for i in range(self.num_agent)])
        self.keys.append("nash_pair")
        if config["br"]:
            self.keys.append("br_policy_loss")
            self.keys.append("br_importance_rate")

    def update_tmp_policies(self):
        """
        This function updates the tmp policy based on the rollouts data
        """
        data = self.buf.get()

        for i in range(self.num_agent):
            agent_data = [item[:, i] for item in data]
            agent = self.agents[i]
            total_loss, p_loss, v_loss, kl, ent, ratio, clip_ratio = agent.update_tmp(
                self.sess, agent_data
            )
            self.logger.store(
                {
                    "total_loss": total_loss,
                    "policy_loss": p_loss,
                    "value_loss": v_loss,
                    "kl": kl,
                    "entropy": ent,
                    "policy_ratio": np.mean(ratio),
                    "clip_ratio": clip_ratio,
                    "adv": np.mean(data[i][2]),
                },
                agent=[i],
            )
        self.buf.keep_tmp_buf()
        self.buf.clear()

    def update_policies_with_nash(self):
        meta_policies_weight = self.calculate_meta_game_policies()
        for i in range(len(self.agents)):
            self.agents[i].update_policy(self.sess, meta_policies_weight[i])

    def calculate_meta_game_policies(self):
        """TODO: use the trajectories calculated to get the meta game and then get the next policy based on meta game result 
        1. rollouts with different combinations of policies 

        """
        if self.config["meta"]:
            matrix = self.compute_payoff_matrix()
            game = {
                "name": "generated game",
                "players": ["Player {}".format(i) for i in range(self.num_agent)],
                "num_players": self.num_agent,
                "shape": [2 for i in range(self.num_agent)],
                "sum_shape": sum([2 for i in range(self.num_agent)]),
                "array": matrix,
            }

            g = Game(game)
            result = g.findEquilibria(self.config["nash_method"])
            if result == None:
                result = [[1, 0] for i in range(self.num_agent)]
            else:
                result[0].normalize()
                result = result[0]._list
                if not check_all_positive(result):
                    result = [[1, 0] for i in range(self.num_agent)]
        else:
            result = [[0, 1] for i in range(self.num_agent)]
        self.logger.store(
            {"nash_pair": [i[0] for i in result]},
            agent=[i for i in range(self.num_agent)],
        )
        return result

    def calculate_policy_adv(self, main_agent, policies):
        if self.config["meta_rollouts"]:
            # do rollouts to get the advantage
            self.rollouts(self.config["meta_rollout_epochs"], policies)
            # calculate the policy advantage
            data = self.buf.get_tmp()
            adv_data = data[2][:, main_agent]
            # clear the buffer after each rollouts
            self.buf.clear()
            return np.mean(adv_data)
        else:
            # use the policy ratio and the rollout experiments to calculate the advantage
            data = self.buf.get_tmp()
            ratio = 1
            for i in range(self.num_agent):
                ratio *= self.agents[i].get_logp_ratio(
                    self.sess,
                    data[0][:, i, :],
                    data[1][:, i],
                    data[4][:, i],
                    policies[i],
                )
            adv_data = data[2][:, main_agent]
            return np.mean(adv_data) * np.mean(ratio)

    def two_player_matrix_constructor(self):
        matrix = []
        for i in range(self.num_agent):
            adv_origin_tmp = self.calculate_policy_adv(i, ["original", "tmp"])
            adv_tmp_origin = self.calculate_policy_adv(i, ["tmp", "original"])
            adv_tmp_tmp = self.calculate_policy_adv(i, ["tmp", "tmp"])
            A = np.array([[0, adv_origin_tmp], [adv_tmp_origin, adv_tmp_tmp], ])
            matrix.append(A)
        return matrix

    def three_player_matrix_constructor(self):
        matrix = []
        for i in range(self.num_agent):
            adv_origin_origin_tmp = self.calculate_policy_adv(
                i, ["original", "original", "tmp"]
            )
            adv_origin_tmp_origin = self.calculate_policy_adv(
                i, ["original", "tmp", "original"]
            )
            adv_origin_tmp_tmp = self.calculate_policy_adv(
                i, ["original", "tmp", "tmp"]
            )
            adv_tmp_origin_origin = self.calculate_policy_adv(
                i, ["tmp", "original", "origin"]
            )
            adv_tmp_origin_tmp = self.calculate_policy_adv(
                i, ["tmp", "original", "tmp"]
            )
            adv_tmp_tmp_origin = self.calculate_policy_adv(
                i, ["tmp", "tmp", "original"]
            )
            adv_tmp_tmp_tmp = self.calculate_policy_adv(i, ["tmp", "tmp", "tmp"])

            A = np.array(
                [
                    [
                        [0, adv_origin_origin_tmp],
                        [adv_origin_tmp_origin, adv_origin_tmp_tmp],
                    ],
                    [
                        [adv_tmp_origin_origin, adv_tmp_origin_tmp],
                        [adv_tmp_tmp_origin, adv_tmp_tmp_tmp],
                    ],
                ]
            )
            matrix.append(A)
        return matrix

    def four_player_matrix_constructor(self):
        matrix = []
        for i in range(self.num_agent):
            adv_origin_origin_origin_tmp = self.calculate_policy_adv(
                i, ["original", "original", "original", "tmp"]
            )
            adv_origin_origin_tmp_origin = self.calculate_policy_adv(
                i, ["original", "original", "tmp", "origin"]
            )
            adv_origin_origin_tmp_tmp = self.calculate_policy_adv(
                i, ["original", "original", "tmp", "tmp"]
            )
            adv_origin_tmp_origin_origin = self.calculate_policy_adv(
                i, ["original", "tmp", "original", "origin"]
            )
            adv_origin_tmp_origin_tmp = self.calculate_policy_adv(
                i, ["original", "tmp", "original", "tmp"]
            )
            adv_origin_tmp_tmp_origin = self.calculate_policy_adv(
                i, ["original", "tmp", "tmp", "origin"]
            )
            adv_origin_tmp_tmp_tmp = self.calculate_policy_adv(
                i, ["original", "tmp", "tmp", "tmp"]
            )

            adv_tmp_origin_origin_origin = self.calculate_policy_adv(
                i, ["tmp", "original", "original", "original"]
            )
            adv_tmp_origin_origin_tmp = self.calculate_policy_adv(
                i, ["tmp", "original", "original", "tmp"]
            )
            adv_tmp_origin_tmp_origin = self.calculate_policy_adv(
                i, ["tmp", "original", "tmp", "origin"]
            )
            adv_tmp_origin_tmp_tmp = self.calculate_policy_adv(
                i, ["tmp", "original", "tmp", "tmp"]
            )
            adv_tmp_tmp_origin_origin = self.calculate_policy_adv(
                i, ["tmp", "tmp", "original", "origin"]
            )
            adv_tmp_tmp_origin_tmp = self.calculate_policy_adv(
                i, ["tmp", "tmp", "original", "tmp"]
            )
            adv_tmp_tmp_tmp_origin = self.calculate_policy_adv(
                i, ["tmp", "tmp", "tmp", "origin"]
            )
            adv_tmp_tmp_tmp_tmp = self.calculate_policy_adv(
                i, ["tmp", "tmp", "tmp", "tmp"]
            )

            A = np.array(
                [
                    [
                        [
                            [0, adv_origin_origin_origin_tmp],
                            [adv_origin_origin_tmp_origin, adv_origin_origin_tmp_tmp],
                        ],
                        [
                            [adv_origin_tmp_origin_origin, adv_origin_tmp_origin_tmp],
                            [adv_origin_tmp_tmp_origin, adv_origin_tmp_tmp_tmp],
                        ],
                    ],
                    [
                        [
                            [adv_tmp_origin_origin_origin, adv_tmp_origin_origin_tmp],
                            [adv_tmp_origin_tmp_origin, adv_tmp_origin_tmp_tmp],
                        ],
                        [
                            [adv_tmp_tmp_origin_origin, adv_tmp_tmp_origin_tmp],
                            [adv_tmp_tmp_tmp_origin, adv_tmp_tmp_tmp_tmp],
                        ],
                    ],
                ]
            )
            matrix.append(A)
        return matrix

    def compute_payoff_matrix(self):
        if self.num_agent == 2:
            return self.two_player_matrix_constructor()
        if self.num_agent == 3:
            return self.three_player_matrix_constructor()
        if self.num_agent == 4:
            return self.four_player_matrix_constructor()
        if self.num_agent == 5:
            return self.five_player_matrix_constructor()
        if self.num_agent == 10:
            return self.ten_player_matrix_constructor()

    def calculate_importance_ratio(self, agent_idx, data, policies):
        importance_ratio = []

        for i in range(self.num_agent):
            if i != agent_idx:
                logp_tmp = data[-1][:, i]
                obs = data[0][:, i]
                act = data[1][:, i]
                logp_ratio = self.agents[i].get_logp_ratio(
                    self.sess, obs, act, logp_tmp, policies[i]
                )
                importance_ratio.append(logp_ratio)
        return np.mean(importance_ratio, axis=1)

    def compute_br_policies(self):
        data_tmp = self.buf.get_tmp()

        for i in range(self.num_agent):
            i_ratio = self.calculate_importance_ratio(
                i, data_tmp, ["tmp" for i in range(self.num_agent)]
            )
            agent_data = [item[:, i] for item in data_tmp]
            agent = self.agents[i]
            p_loss = agent.br_update(self.sess, agent_data, i_ratio)
            self.logger.store(
                {"br_policy_loss": p_loss, "br_importance_rate": i_ratio, }, [i]
            )

    def train(self):

        for epoch in range(self.config["epochs"]):
            # update the tmp policies of agents
            self.rollouts(1, ["original"] * self.num_agent)
            self.update_tmp_policies()
            # use the tmo policies to construct the meta game payoff matrix
            # update the original policies with the nash pair outputed by nash solver
            self.update_policies_with_nash()
            if self.config["br"]:
                self.compute_br_policies()
            # # Log info about epoch

            self.test(epoch)

            self.logger.dump(
                self.keys,
                agents=[i for i in range(len(self.agents))],
                step=epoch,
                mean_only=True,
            )
            if epoch % self.config["save_frequency"] == 0:
                print("--- the model has been saved ---")
                self.save(step=epoch)

    def test(self, e):
        all_ret = []
        for i in range(100):
            done_n = [False for _ in range(self.num_agent)]
            ep_reward = 0
            # obs_n = self.env.reset()
            obs_n = np.expand_dims(np.array(self.env.reset()).flatten(), 0).repeat(self.num_agent, axis=0)
            while not all(done_n):
                action_n, _, __ = self.get_actions(obs_n, ["original"] * self.num_agent)
                obs_n, reward_n, done_n, info = self.env.step(action_n)
                obs_n = np.expand_dims(np.array(obs_n).flatten(), 0).repeat(self.num_agent, axis=0)
                ep_reward += sum(reward_n)
            all_ret.append(ep_reward)
        aver_ret = np.mean(all_ret)
        all_win = [1 if r > 0 else 0 for r in all_ret]
        win_rate = np.mean(all_win)
        print("episode: %s, aver reward: %s, win_rate: %s" % (e, aver_ret, win_rate))
        f = open("./test_log.txt", "a")
        f.write("episode: %s, aver reward: %s, win_rate: %s \n" % (e, aver_ret, win_rate))
        f.close()

    # auto-gen
    def five_player_matrix_constructor(self):
        matrix = []
        for i in range(self.num_agent):
            adv_oooot = self.calculate_policy_adv(i, ["original", "original", "original", "original", "tmp"])
            adv_oooto = self.calculate_policy_adv(i, ["original", "original", "original", "tmp", "original"])
            adv_ooott = self.calculate_policy_adv(i, ["original", "original", "original", "tmp", "tmp"])
            adv_ootoo = self.calculate_policy_adv(i, ["original", "original", "tmp", "original", "original"])
            adv_ootot = self.calculate_policy_adv(i, ["original", "original", "tmp", "original", "tmp"])
            adv_ootto = self.calculate_policy_adv(i, ["original", "original", "tmp", "tmp", "original"])
            adv_oottt = self.calculate_policy_adv(i, ["original", "original", "tmp", "tmp", "tmp"])
            adv_otooo = self.calculate_policy_adv(i, ["original", "tmp", "original", "original", "original"])
            adv_otoot = self.calculate_policy_adv(i, ["original", "tmp", "original", "original", "tmp"])
            adv_ototo = self.calculate_policy_adv(i, ["original", "tmp", "original", "tmp", "original"])
            adv_otott = self.calculate_policy_adv(i, ["original", "tmp", "original", "tmp", "tmp"])
            adv_ottoo = self.calculate_policy_adv(i, ["original", "tmp", "tmp", "original", "original"])
            adv_ottot = self.calculate_policy_adv(i, ["original", "tmp", "tmp", "original", "tmp"])
            adv_ottto = self.calculate_policy_adv(i, ["original", "tmp", "tmp", "tmp", "original"])
            adv_otttt = self.calculate_policy_adv(i, ["original", "tmp", "tmp", "tmp", "tmp"])
            adv_toooo = self.calculate_policy_adv(i, ["tmp", "original", "original", "original", "original"])
            adv_tooot = self.calculate_policy_adv(i, ["tmp", "original", "original", "original", "tmp"])
            adv_tooto = self.calculate_policy_adv(i, ["tmp", "original", "original", "tmp", "original"])
            adv_toott = self.calculate_policy_adv(i, ["tmp", "original", "original", "tmp", "tmp"])
            adv_totoo = self.calculate_policy_adv(i, ["tmp", "original", "tmp", "original", "original"])
            adv_totot = self.calculate_policy_adv(i, ["tmp", "original", "tmp", "original", "tmp"])
            adv_totto = self.calculate_policy_adv(i, ["tmp", "original", "tmp", "tmp", "original"])
            adv_tottt = self.calculate_policy_adv(i, ["tmp", "original", "tmp", "tmp", "tmp"])
            adv_ttooo = self.calculate_policy_adv(i, ["tmp", "tmp", "original", "original", "original"])
            adv_ttoot = self.calculate_policy_adv(i, ["tmp", "tmp", "original", "original", "tmp"])
            adv_ttoto = self.calculate_policy_adv(i, ["tmp", "tmp", "original", "tmp", "original"])
            adv_ttott = self.calculate_policy_adv(i, ["tmp", "tmp", "original", "tmp", "tmp"])
            adv_tttoo = self.calculate_policy_adv(i, ["tmp", "tmp", "tmp", "original", "original"])
            adv_tttot = self.calculate_policy_adv(i, ["tmp", "tmp", "tmp", "original", "tmp"])
            adv_tttto = self.calculate_policy_adv(i, ["tmp", "tmp", "tmp", "tmp", "original"])
            adv_ttttt = self.calculate_policy_adv(i, ["tmp", "tmp", "tmp", "tmp", "tmp"])

            A = np.array([[[[[0, adv_oooot], [adv_oooto, adv_ooott]], [[adv_ootoo, adv_ootot], [adv_ootto, adv_oottt]]],
                           [[[adv_otooo, adv_otoot], [adv_ototo, adv_otott]],
                            [[adv_ottoo, adv_ottot], [adv_ottto, adv_otttt]]]], [
                              [[[adv_toooo, adv_tooot], [adv_tooto, adv_toott]],
                               [[adv_totoo, adv_totot], [adv_totto, adv_tottt]]],
                              [[[adv_ttooo, adv_ttoot], [adv_ttoto, adv_ttott]],
                               [[adv_tttoo, adv_tttot], [adv_tttto, adv_ttttt]]]]])
            matrix.append(A)
        return matrix

    def ten_player_matrix_constructor(self):
        matrix = []
        for i in range(self.num_agent):
            adv_ooooooooot = self.calculate_policy_adv(i, ["original", "original", "original", "original", "original",
                                                           "original", "original", "original", "original", "tmp"])
            adv_ooooooooto = self.calculate_policy_adv(i, ["original", "original", "original", "original", "original",
                                                           "original", "original", "original", "tmp", "original"])
            adv_oooooooott = self.calculate_policy_adv(i, ["original", "original", "original", "original", "original",
                                                           "original", "original", "original", "tmp", "tmp"])
            adv_oooooootoo = self.calculate_policy_adv(i, ["original", "original", "original", "original", "original",
                                                           "original", "original", "tmp", "original", "original"])
            adv_oooooootot = self.calculate_policy_adv(i, ["original", "original", "original", "original", "original",
                                                           "original", "original", "tmp", "original", "tmp"])
            adv_oooooootto = self.calculate_policy_adv(i, ["original", "original", "original", "original", "original",
                                                           "original", "original", "tmp", "tmp", "original"])
            adv_ooooooottt = self.calculate_policy_adv(i, ["original", "original", "original", "original", "original",
                                                           "original", "original", "tmp", "tmp", "tmp"])
            adv_ooooootooo = self.calculate_policy_adv(i, ["original", "original", "original", "original", "original",
                                                           "original", "tmp", "original", "original", "original"])
            adv_ooooootoot = self.calculate_policy_adv(i, ["original", "original", "original", "original", "original",
                                                           "original", "tmp", "original", "original", "tmp"])
            adv_oooooototo = self.calculate_policy_adv(i, ["original", "original", "original", "original", "original",
                                                           "original", "tmp", "original", "tmp", "original"])
            adv_ooooootott = self.calculate_policy_adv(i, ["original", "original", "original", "original", "original",
                                                           "original", "tmp", "original", "tmp", "tmp"])
            adv_oooooottoo = self.calculate_policy_adv(i, ["original", "original", "original", "original", "original",
                                                           "original", "tmp", "tmp", "original", "original"])
            adv_oooooottot = self.calculate_policy_adv(i, ["original", "original", "original", "original", "original",
                                                           "original", "tmp", "tmp", "original", "tmp"])
            adv_oooooottto = self.calculate_policy_adv(i, ["original", "original", "original", "original", "original",
                                                           "original", "tmp", "tmp", "tmp", "original"])
            adv_ooooootttt = self.calculate_policy_adv(i, ["original", "original", "original", "original", "original",
                                                           "original", "tmp", "tmp", "tmp", "tmp"])
            adv_oooootoooo = self.calculate_policy_adv(i, ["original", "original", "original", "original", "original",
                                                           "tmp", "original", "original", "original", "original"])
            adv_oooootooot = self.calculate_policy_adv(i, ["original", "original", "original", "original", "original",
                                                           "tmp", "original", "original", "original", "tmp"])
            adv_oooootooto = self.calculate_policy_adv(i, ["original", "original", "original", "original", "original",
                                                           "tmp", "original", "original", "tmp", "original"])
            adv_oooootoott = self.calculate_policy_adv(i, ["original", "original", "original", "original", "original",
                                                           "tmp", "original", "original", "tmp", "tmp"])
            adv_ooooototoo = self.calculate_policy_adv(i, ["original", "original", "original", "original", "original",
                                                           "tmp", "original", "tmp", "original", "original"])
            adv_ooooototot = self.calculate_policy_adv(i, ["original", "original", "original", "original", "original",
                                                           "tmp", "original", "tmp", "original", "tmp"])
            adv_ooooototto = self.calculate_policy_adv(i, ["original", "original", "original", "original", "original",
                                                           "tmp", "original", "tmp", "tmp", "original"])
            adv_oooootottt = self.calculate_policy_adv(i, ["original", "original", "original", "original", "original",
                                                           "tmp", "original", "tmp", "tmp", "tmp"])
            adv_ooooottooo = self.calculate_policy_adv(i, ["original", "original", "original", "original", "original",
                                                           "tmp", "tmp", "original", "original", "original"])
            adv_ooooottoot = self.calculate_policy_adv(i, ["original", "original", "original", "original", "original",
                                                           "tmp", "tmp", "original", "original", "tmp"])
            adv_ooooottoto = self.calculate_policy_adv(i, ["original", "original", "original", "original", "original",
                                                           "tmp", "tmp", "original", "tmp", "original"])
            adv_ooooottott = self.calculate_policy_adv(i, ["original", "original", "original", "original", "original",
                                                           "tmp", "tmp", "original", "tmp", "tmp"])
            adv_oooootttoo = self.calculate_policy_adv(i, ["original", "original", "original", "original", "original",
                                                           "tmp", "tmp", "tmp", "original", "original"])
            adv_oooootttot = self.calculate_policy_adv(i, ["original", "original", "original", "original", "original",
                                                           "tmp", "tmp", "tmp", "original", "tmp"])
            adv_oooootttto = self.calculate_policy_adv(i, ["original", "original", "original", "original", "original",
                                                           "tmp", "tmp", "tmp", "tmp", "original"])
            adv_ooooottttt = self.calculate_policy_adv(i, ["original", "original", "original", "original", "original",
                                                           "tmp", "tmp", "tmp", "tmp", "tmp"])
            adv_ooootooooo = self.calculate_policy_adv(i, ["original", "original", "original", "original", "tmp",
                                                           "original", "original", "original", "original", "original"])
            adv_ooootoooot = self.calculate_policy_adv(i, ["original", "original", "original", "original", "tmp",
                                                           "original", "original", "original", "original", "tmp"])
            adv_ooootoooto = self.calculate_policy_adv(i, ["original", "original", "original", "original", "tmp",
                                                           "original", "original", "original", "tmp", "original"])
            adv_ooootooott = self.calculate_policy_adv(i, ["original", "original", "original", "original", "tmp",
                                                           "original", "original", "original", "tmp", "tmp"])
            adv_ooootootoo = self.calculate_policy_adv(i, ["original", "original", "original", "original", "tmp",
                                                           "original", "original", "tmp", "original", "original"])
            adv_ooootootot = self.calculate_policy_adv(i, ["original", "original", "original", "original", "tmp",
                                                           "original", "original", "tmp", "original", "tmp"])
            adv_ooootootto = self.calculate_policy_adv(i, ["original", "original", "original", "original", "tmp",
                                                           "original", "original", "tmp", "tmp", "original"])
            adv_ooootoottt = self.calculate_policy_adv(i, ["original", "original", "original", "original", "tmp",
                                                           "original", "original", "tmp", "tmp", "tmp"])
            adv_oooototooo = self.calculate_policy_adv(i, ["original", "original", "original", "original", "tmp",
                                                           "original", "tmp", "original", "original", "original"])
            adv_oooototoot = self.calculate_policy_adv(i, ["original", "original", "original", "original", "tmp",
                                                           "original", "tmp", "original", "original", "tmp"])
            adv_ooootototo = self.calculate_policy_adv(i, ["original", "original", "original", "original", "tmp",
                                                           "original", "tmp", "original", "tmp", "original"])
            adv_oooototott = self.calculate_policy_adv(i, ["original", "original", "original", "original", "tmp",
                                                           "original", "tmp", "original", "tmp", "tmp"])
            adv_ooootottoo = self.calculate_policy_adv(i, ["original", "original", "original", "original", "tmp",
                                                           "original", "tmp", "tmp", "original", "original"])
            adv_ooootottot = self.calculate_policy_adv(i, ["original", "original", "original", "original", "tmp",
                                                           "original", "tmp", "tmp", "original", "tmp"])
            adv_ooootottto = self.calculate_policy_adv(i, ["original", "original", "original", "original", "tmp",
                                                           "original", "tmp", "tmp", "tmp", "original"])
            adv_oooototttt = self.calculate_policy_adv(i, ["original", "original", "original", "original", "tmp",
                                                           "original", "tmp", "tmp", "tmp", "tmp"])
            adv_oooottoooo = self.calculate_policy_adv(i, ["original", "original", "original", "original", "tmp", "tmp",
                                                           "original", "original", "original", "original"])
            adv_oooottooot = self.calculate_policy_adv(i, ["original", "original", "original", "original", "tmp", "tmp",
                                                           "original", "original", "original", "tmp"])
            adv_oooottooto = self.calculate_policy_adv(i, ["original", "original", "original", "original", "tmp", "tmp",
                                                           "original", "original", "tmp", "original"])
            adv_oooottoott = self.calculate_policy_adv(i, ["original", "original", "original", "original", "tmp", "tmp",
                                                           "original", "original", "tmp", "tmp"])
            adv_oooottotoo = self.calculate_policy_adv(i, ["original", "original", "original", "original", "tmp", "tmp",
                                                           "original", "tmp", "original", "original"])
            adv_oooottotot = self.calculate_policy_adv(i, ["original", "original", "original", "original", "tmp", "tmp",
                                                           "original", "tmp", "original", "tmp"])
            adv_oooottotto = self.calculate_policy_adv(i, ["original", "original", "original", "original", "tmp", "tmp",
                                                           "original", "tmp", "tmp", "original"])
            adv_oooottottt = self.calculate_policy_adv(i, ["original", "original", "original", "original", "tmp", "tmp",
                                                           "original", "tmp", "tmp", "tmp"])
            adv_ooootttooo = self.calculate_policy_adv(i, ["original", "original", "original", "original", "tmp", "tmp",
                                                           "tmp", "original", "original", "original"])
            adv_ooootttoot = self.calculate_policy_adv(i, ["original", "original", "original", "original", "tmp", "tmp",
                                                           "tmp", "original", "original", "tmp"])
            adv_ooootttoto = self.calculate_policy_adv(i, ["original", "original", "original", "original", "tmp", "tmp",
                                                           "tmp", "original", "tmp", "original"])
            adv_ooootttott = self.calculate_policy_adv(i, ["original", "original", "original", "original", "tmp", "tmp",
                                                           "tmp", "original", "tmp", "tmp"])
            adv_oooottttoo = self.calculate_policy_adv(i, ["original", "original", "original", "original", "tmp", "tmp",
                                                           "tmp", "tmp", "original", "original"])
            adv_oooottttot = self.calculate_policy_adv(i, ["original", "original", "original", "original", "tmp", "tmp",
                                                           "tmp", "tmp", "original", "tmp"])
            adv_oooottttto = self.calculate_policy_adv(i, ["original", "original", "original", "original", "tmp", "tmp",
                                                           "tmp", "tmp", "tmp", "original"])
            adv_ooootttttt = self.calculate_policy_adv(i, ["original", "original", "original", "original", "tmp", "tmp",
                                                           "tmp", "tmp", "tmp", "tmp"])
            adv_oootoooooo = self.calculate_policy_adv(i, ["original", "original", "original", "tmp", "original",
                                                           "original", "original", "original", "original", "original"])
            adv_oootooooot = self.calculate_policy_adv(i, ["original", "original", "original", "tmp", "original",
                                                           "original", "original", "original", "original", "tmp"])
            adv_oootooooto = self.calculate_policy_adv(i, ["original", "original", "original", "tmp", "original",
                                                           "original", "original", "original", "tmp", "original"])
            adv_oootoooott = self.calculate_policy_adv(i, ["original", "original", "original", "tmp", "original",
                                                           "original", "original", "original", "tmp", "tmp"])
            adv_oootoootoo = self.calculate_policy_adv(i, ["original", "original", "original", "tmp", "original",
                                                           "original", "original", "tmp", "original", "original"])
            adv_oootoootot = self.calculate_policy_adv(i, ["original", "original", "original", "tmp", "original",
                                                           "original", "original", "tmp", "original", "tmp"])
            adv_oootoootto = self.calculate_policy_adv(i, ["original", "original", "original", "tmp", "original",
                                                           "original", "original", "tmp", "tmp", "original"])
            adv_oootooottt = self.calculate_policy_adv(i, ["original", "original", "original", "tmp", "original",
                                                           "original", "original", "tmp", "tmp", "tmp"])
            adv_oootootooo = self.calculate_policy_adv(i, ["original", "original", "original", "tmp", "original",
                                                           "original", "tmp", "original", "original", "original"])
            adv_oootootoot = self.calculate_policy_adv(i, ["original", "original", "original", "tmp", "original",
                                                           "original", "tmp", "original", "original", "tmp"])
            adv_oootoototo = self.calculate_policy_adv(i, ["original", "original", "original", "tmp", "original",
                                                           "original", "tmp", "original", "tmp", "original"])
            adv_oootootott = self.calculate_policy_adv(i, ["original", "original", "original", "tmp", "original",
                                                           "original", "tmp", "original", "tmp", "tmp"])
            adv_oootoottoo = self.calculate_policy_adv(i, ["original", "original", "original", "tmp", "original",
                                                           "original", "tmp", "tmp", "original", "original"])
            adv_oootoottot = self.calculate_policy_adv(i, ["original", "original", "original", "tmp", "original",
                                                           "original", "tmp", "tmp", "original", "tmp"])
            adv_oootoottto = self.calculate_policy_adv(i, ["original", "original", "original", "tmp", "original",
                                                           "original", "tmp", "tmp", "tmp", "original"])
            adv_oootootttt = self.calculate_policy_adv(i, ["original", "original", "original", "tmp", "original",
                                                           "original", "tmp", "tmp", "tmp", "tmp"])
            adv_ooototoooo = self.calculate_policy_adv(i, ["original", "original", "original", "tmp", "original", "tmp",
                                                           "original", "original", "original", "original"])
            adv_ooototooot = self.calculate_policy_adv(i, ["original", "original", "original", "tmp", "original", "tmp",
                                                           "original", "original", "original", "tmp"])
            adv_ooototooto = self.calculate_policy_adv(i, ["original", "original", "original", "tmp", "original", "tmp",
                                                           "original", "original", "tmp", "original"])
            adv_ooototoott = self.calculate_policy_adv(i, ["original", "original", "original", "tmp", "original", "tmp",
                                                           "original", "original", "tmp", "tmp"])
            adv_oootototoo = self.calculate_policy_adv(i, ["original", "original", "original", "tmp", "original", "tmp",
                                                           "original", "tmp", "original", "original"])
            adv_oootototot = self.calculate_policy_adv(i, ["original", "original", "original", "tmp", "original", "tmp",
                                                           "original", "tmp", "original", "tmp"])
            adv_oootototto = self.calculate_policy_adv(i, ["original", "original", "original", "tmp", "original", "tmp",
                                                           "original", "tmp", "tmp", "original"])
            adv_ooototottt = self.calculate_policy_adv(i, ["original", "original", "original", "tmp", "original", "tmp",
                                                           "original", "tmp", "tmp", "tmp"])
            adv_oootottooo = self.calculate_policy_adv(i, ["original", "original", "original", "tmp", "original", "tmp",
                                                           "tmp", "original", "original", "original"])
            adv_oootottoot = self.calculate_policy_adv(i, ["original", "original", "original", "tmp", "original", "tmp",
                                                           "tmp", "original", "original", "tmp"])
            adv_oootottoto = self.calculate_policy_adv(i, ["original", "original", "original", "tmp", "original", "tmp",
                                                           "tmp", "original", "tmp", "original"])
            adv_oootottott = self.calculate_policy_adv(i, ["original", "original", "original", "tmp", "original", "tmp",
                                                           "tmp", "original", "tmp", "tmp"])
            adv_ooototttoo = self.calculate_policy_adv(i, ["original", "original", "original", "tmp", "original", "tmp",
                                                           "tmp", "tmp", "original", "original"])
            adv_ooototttot = self.calculate_policy_adv(i, ["original", "original", "original", "tmp", "original", "tmp",
                                                           "tmp", "tmp", "original", "tmp"])
            adv_ooototttto = self.calculate_policy_adv(i, ["original", "original", "original", "tmp", "original", "tmp",
                                                           "tmp", "tmp", "tmp", "original"])
            adv_oootottttt = self.calculate_policy_adv(i, ["original", "original", "original", "tmp", "original", "tmp",
                                                           "tmp", "tmp", "tmp", "tmp"])
            adv_ooottooooo = self.calculate_policy_adv(i, ["original", "original", "original", "tmp", "tmp", "original",
                                                           "original", "original", "original", "original"])
            adv_ooottoooot = self.calculate_policy_adv(i, ["original", "original", "original", "tmp", "tmp", "original",
                                                           "original", "original", "original", "tmp"])
            adv_ooottoooto = self.calculate_policy_adv(i, ["original", "original", "original", "tmp", "tmp", "original",
                                                           "original", "original", "tmp", "original"])
            adv_ooottooott = self.calculate_policy_adv(i, ["original", "original", "original", "tmp", "tmp", "original",
                                                           "original", "original", "tmp", "tmp"])
            adv_ooottootoo = self.calculate_policy_adv(i, ["original", "original", "original", "tmp", "tmp", "original",
                                                           "original", "tmp", "original", "original"])
            adv_ooottootot = self.calculate_policy_adv(i, ["original", "original", "original", "tmp", "tmp", "original",
                                                           "original", "tmp", "original", "tmp"])
            adv_ooottootto = self.calculate_policy_adv(i, ["original", "original", "original", "tmp", "tmp", "original",
                                                           "original", "tmp", "tmp", "original"])
            adv_ooottoottt = self.calculate_policy_adv(i, ["original", "original", "original", "tmp", "tmp", "original",
                                                           "original", "tmp", "tmp", "tmp"])
            adv_ooottotooo = self.calculate_policy_adv(i, ["original", "original", "original", "tmp", "tmp", "original",
                                                           "tmp", "original", "original", "original"])
            adv_ooottotoot = self.calculate_policy_adv(i, ["original", "original", "original", "tmp", "tmp", "original",
                                                           "tmp", "original", "original", "tmp"])
            adv_ooottototo = self.calculate_policy_adv(i, ["original", "original", "original", "tmp", "tmp", "original",
                                                           "tmp", "original", "tmp", "original"])
            adv_ooottotott = self.calculate_policy_adv(i, ["original", "original", "original", "tmp", "tmp", "original",
                                                           "tmp", "original", "tmp", "tmp"])
            adv_ooottottoo = self.calculate_policy_adv(i, ["original", "original", "original", "tmp", "tmp", "original",
                                                           "tmp", "tmp", "original", "original"])
            adv_ooottottot = self.calculate_policy_adv(i, ["original", "original", "original", "tmp", "tmp", "original",
                                                           "tmp", "tmp", "original", "tmp"])
            adv_ooottottto = self.calculate_policy_adv(i, ["original", "original", "original", "tmp", "tmp", "original",
                                                           "tmp", "tmp", "tmp", "original"])
            adv_ooottotttt = self.calculate_policy_adv(i, ["original", "original", "original", "tmp", "tmp", "original",
                                                           "tmp", "tmp", "tmp", "tmp"])
            adv_oootttoooo = self.calculate_policy_adv(i, ["original", "original", "original", "tmp", "tmp", "tmp",
                                                           "original", "original", "original", "original"])
            adv_oootttooot = self.calculate_policy_adv(i, ["original", "original", "original", "tmp", "tmp", "tmp",
                                                           "original", "original", "original", "tmp"])
            adv_oootttooto = self.calculate_policy_adv(i, ["original", "original", "original", "tmp", "tmp", "tmp",
                                                           "original", "original", "tmp", "original"])
            adv_oootttoott = self.calculate_policy_adv(i, ["original", "original", "original", "tmp", "tmp", "tmp",
                                                           "original", "original", "tmp", "tmp"])
            adv_oootttotoo = self.calculate_policy_adv(i, ["original", "original", "original", "tmp", "tmp", "tmp",
                                                           "original", "tmp", "original", "original"])
            adv_oootttotot = self.calculate_policy_adv(i, ["original", "original", "original", "tmp", "tmp", "tmp",
                                                           "original", "tmp", "original", "tmp"])
            adv_oootttotto = self.calculate_policy_adv(i, ["original", "original", "original", "tmp", "tmp", "tmp",
                                                           "original", "tmp", "tmp", "original"])
            adv_oootttottt = self.calculate_policy_adv(i, ["original", "original", "original", "tmp", "tmp", "tmp",
                                                           "original", "tmp", "tmp", "tmp"])
            adv_ooottttooo = self.calculate_policy_adv(i,
                                                       ["original", "original", "original", "tmp", "tmp", "tmp", "tmp",
                                                        "original", "original", "original"])
            adv_ooottttoot = self.calculate_policy_adv(i,
                                                       ["original", "original", "original", "tmp", "tmp", "tmp", "tmp",
                                                        "original", "original", "tmp"])
            adv_ooottttoto = self.calculate_policy_adv(i,
                                                       ["original", "original", "original", "tmp", "tmp", "tmp", "tmp",
                                                        "original", "tmp", "original"])
            adv_ooottttott = self.calculate_policy_adv(i,
                                                       ["original", "original", "original", "tmp", "tmp", "tmp", "tmp",
                                                        "original", "tmp", "tmp"])
            adv_oootttttoo = self.calculate_policy_adv(i,
                                                       ["original", "original", "original", "tmp", "tmp", "tmp", "tmp",
                                                        "tmp", "original", "original"])
            adv_oootttttot = self.calculate_policy_adv(i,
                                                       ["original", "original", "original", "tmp", "tmp", "tmp", "tmp",
                                                        "tmp", "original", "tmp"])
            adv_oootttttto = self.calculate_policy_adv(i,
                                                       ["original", "original", "original", "tmp", "tmp", "tmp", "tmp",
                                                        "tmp", "tmp", "original"])
            adv_ooottttttt = self.calculate_policy_adv(i,
                                                       ["original", "original", "original", "tmp", "tmp", "tmp", "tmp",
                                                        "tmp", "tmp", "tmp"])
            adv_ootooooooo = self.calculate_policy_adv(i, ["original", "original", "tmp", "original", "original",
                                                           "original", "original", "original", "original", "original"])
            adv_ootoooooot = self.calculate_policy_adv(i, ["original", "original", "tmp", "original", "original",
                                                           "original", "original", "original", "original", "tmp"])
            adv_ootoooooto = self.calculate_policy_adv(i, ["original", "original", "tmp", "original", "original",
                                                           "original", "original", "original", "tmp", "original"])
            adv_ootooooott = self.calculate_policy_adv(i, ["original", "original", "tmp", "original", "original",
                                                           "original", "original", "original", "tmp", "tmp"])
            adv_ootooootoo = self.calculate_policy_adv(i, ["original", "original", "tmp", "original", "original",
                                                           "original", "original", "tmp", "original", "original"])
            adv_ootooootot = self.calculate_policy_adv(i, ["original", "original", "tmp", "original", "original",
                                                           "original", "original", "tmp", "original", "tmp"])
            adv_ootooootto = self.calculate_policy_adv(i, ["original", "original", "tmp", "original", "original",
                                                           "original", "original", "tmp", "tmp", "original"])
            adv_ootoooottt = self.calculate_policy_adv(i, ["original", "original", "tmp", "original", "original",
                                                           "original", "original", "tmp", "tmp", "tmp"])
            adv_ootoootooo = self.calculate_policy_adv(i, ["original", "original", "tmp", "original", "original",
                                                           "original", "tmp", "original", "original", "original"])
            adv_ootoootoot = self.calculate_policy_adv(i, ["original", "original", "tmp", "original", "original",
                                                           "original", "tmp", "original", "original", "tmp"])
            adv_ootooototo = self.calculate_policy_adv(i, ["original", "original", "tmp", "original", "original",
                                                           "original", "tmp", "original", "tmp", "original"])
            adv_ootoootott = self.calculate_policy_adv(i, ["original", "original", "tmp", "original", "original",
                                                           "original", "tmp", "original", "tmp", "tmp"])
            adv_ootooottoo = self.calculate_policy_adv(i, ["original", "original", "tmp", "original", "original",
                                                           "original", "tmp", "tmp", "original", "original"])
            adv_ootooottot = self.calculate_policy_adv(i, ["original", "original", "tmp", "original", "original",
                                                           "original", "tmp", "tmp", "original", "tmp"])
            adv_ootooottto = self.calculate_policy_adv(i, ["original", "original", "tmp", "original", "original",
                                                           "original", "tmp", "tmp", "tmp", "original"])
            adv_ootoootttt = self.calculate_policy_adv(i, ["original", "original", "tmp", "original", "original",
                                                           "original", "tmp", "tmp", "tmp", "tmp"])
            adv_ootootoooo = self.calculate_policy_adv(i, ["original", "original", "tmp", "original", "original", "tmp",
                                                           "original", "original", "original", "original"])
            adv_ootootooot = self.calculate_policy_adv(i, ["original", "original", "tmp", "original", "original", "tmp",
                                                           "original", "original", "original", "tmp"])
            adv_ootootooto = self.calculate_policy_adv(i, ["original", "original", "tmp", "original", "original", "tmp",
                                                           "original", "original", "tmp", "original"])
            adv_ootootoott = self.calculate_policy_adv(i, ["original", "original", "tmp", "original", "original", "tmp",
                                                           "original", "original", "tmp", "tmp"])
            adv_ootoototoo = self.calculate_policy_adv(i, ["original", "original", "tmp", "original", "original", "tmp",
                                                           "original", "tmp", "original", "original"])
            adv_ootoototot = self.calculate_policy_adv(i, ["original", "original", "tmp", "original", "original", "tmp",
                                                           "original", "tmp", "original", "tmp"])
            adv_ootoototto = self.calculate_policy_adv(i, ["original", "original", "tmp", "original", "original", "tmp",
                                                           "original", "tmp", "tmp", "original"])
            adv_ootootottt = self.calculate_policy_adv(i, ["original", "original", "tmp", "original", "original", "tmp",
                                                           "original", "tmp", "tmp", "tmp"])
            adv_ootoottooo = self.calculate_policy_adv(i, ["original", "original", "tmp", "original", "original", "tmp",
                                                           "tmp", "original", "original", "original"])
            adv_ootoottoot = self.calculate_policy_adv(i, ["original", "original", "tmp", "original", "original", "tmp",
                                                           "tmp", "original", "original", "tmp"])
            adv_ootoottoto = self.calculate_policy_adv(i, ["original", "original", "tmp", "original", "original", "tmp",
                                                           "tmp", "original", "tmp", "original"])
            adv_ootoottott = self.calculate_policy_adv(i, ["original", "original", "tmp", "original", "original", "tmp",
                                                           "tmp", "original", "tmp", "tmp"])
            adv_ootootttoo = self.calculate_policy_adv(i, ["original", "original", "tmp", "original", "original", "tmp",
                                                           "tmp", "tmp", "original", "original"])
            adv_ootootttot = self.calculate_policy_adv(i, ["original", "original", "tmp", "original", "original", "tmp",
                                                           "tmp", "tmp", "original", "tmp"])
            adv_ootootttto = self.calculate_policy_adv(i, ["original", "original", "tmp", "original", "original", "tmp",
                                                           "tmp", "tmp", "tmp", "original"])
            adv_ootoottttt = self.calculate_policy_adv(i, ["original", "original", "tmp", "original", "original", "tmp",
                                                           "tmp", "tmp", "tmp", "tmp"])
            adv_oototooooo = self.calculate_policy_adv(i, ["original", "original", "tmp", "original", "tmp", "original",
                                                           "original", "original", "original", "original"])
            adv_oototoooot = self.calculate_policy_adv(i, ["original", "original", "tmp", "original", "tmp", "original",
                                                           "original", "original", "original", "tmp"])
            adv_oototoooto = self.calculate_policy_adv(i, ["original", "original", "tmp", "original", "tmp", "original",
                                                           "original", "original", "tmp", "original"])
            adv_oototooott = self.calculate_policy_adv(i, ["original", "original", "tmp", "original", "tmp", "original",
                                                           "original", "original", "tmp", "tmp"])
            adv_oototootoo = self.calculate_policy_adv(i, ["original", "original", "tmp", "original", "tmp", "original",
                                                           "original", "tmp", "original", "original"])
            adv_oototootot = self.calculate_policy_adv(i, ["original", "original", "tmp", "original", "tmp", "original",
                                                           "original", "tmp", "original", "tmp"])
            adv_oototootto = self.calculate_policy_adv(i, ["original", "original", "tmp", "original", "tmp", "original",
                                                           "original", "tmp", "tmp", "original"])
            adv_oototoottt = self.calculate_policy_adv(i, ["original", "original", "tmp", "original", "tmp", "original",
                                                           "original", "tmp", "tmp", "tmp"])
            adv_ootototooo = self.calculate_policy_adv(i, ["original", "original", "tmp", "original", "tmp", "original",
                                                           "tmp", "original", "original", "original"])
            adv_ootototoot = self.calculate_policy_adv(i, ["original", "original", "tmp", "original", "tmp", "original",
                                                           "tmp", "original", "original", "tmp"])
            adv_oototototo = self.calculate_policy_adv(i, ["original", "original", "tmp", "original", "tmp", "original",
                                                           "tmp", "original", "tmp", "original"])
            adv_ootototott = self.calculate_policy_adv(i, ["original", "original", "tmp", "original", "tmp", "original",
                                                           "tmp", "original", "tmp", "tmp"])
            adv_oototottoo = self.calculate_policy_adv(i, ["original", "original", "tmp", "original", "tmp", "original",
                                                           "tmp", "tmp", "original", "original"])
            adv_oototottot = self.calculate_policy_adv(i, ["original", "original", "tmp", "original", "tmp", "original",
                                                           "tmp", "tmp", "original", "tmp"])
            adv_oototottto = self.calculate_policy_adv(i, ["original", "original", "tmp", "original", "tmp", "original",
                                                           "tmp", "tmp", "tmp", "original"])
            adv_ootototttt = self.calculate_policy_adv(i, ["original", "original", "tmp", "original", "tmp", "original",
                                                           "tmp", "tmp", "tmp", "tmp"])
            adv_ootottoooo = self.calculate_policy_adv(i, ["original", "original", "tmp", "original", "tmp", "tmp",
                                                           "original", "original", "original", "original"])
            adv_ootottooot = self.calculate_policy_adv(i, ["original", "original", "tmp", "original", "tmp", "tmp",
                                                           "original", "original", "original", "tmp"])
            adv_ootottooto = self.calculate_policy_adv(i, ["original", "original", "tmp", "original", "tmp", "tmp",
                                                           "original", "original", "tmp", "original"])
            adv_ootottoott = self.calculate_policy_adv(i, ["original", "original", "tmp", "original", "tmp", "tmp",
                                                           "original", "original", "tmp", "tmp"])
            adv_ootottotoo = self.calculate_policy_adv(i, ["original", "original", "tmp", "original", "tmp", "tmp",
                                                           "original", "tmp", "original", "original"])
            adv_ootottotot = self.calculate_policy_adv(i, ["original", "original", "tmp", "original", "tmp", "tmp",
                                                           "original", "tmp", "original", "tmp"])
            adv_ootottotto = self.calculate_policy_adv(i, ["original", "original", "tmp", "original", "tmp", "tmp",
                                                           "original", "tmp", "tmp", "original"])
            adv_ootottottt = self.calculate_policy_adv(i, ["original", "original", "tmp", "original", "tmp", "tmp",
                                                           "original", "tmp", "tmp", "tmp"])
            adv_oototttooo = self.calculate_policy_adv(i,
                                                       ["original", "original", "tmp", "original", "tmp", "tmp", "tmp",
                                                        "original", "original", "original"])
            adv_oototttoot = self.calculate_policy_adv(i,
                                                       ["original", "original", "tmp", "original", "tmp", "tmp", "tmp",
                                                        "original", "original", "tmp"])
            adv_oototttoto = self.calculate_policy_adv(i,
                                                       ["original", "original", "tmp", "original", "tmp", "tmp", "tmp",
                                                        "original", "tmp", "original"])
            adv_oototttott = self.calculate_policy_adv(i,
                                                       ["original", "original", "tmp", "original", "tmp", "tmp", "tmp",
                                                        "original", "tmp", "tmp"])
            adv_ootottttoo = self.calculate_policy_adv(i,
                                                       ["original", "original", "tmp", "original", "tmp", "tmp", "tmp",
                                                        "tmp", "original", "original"])
            adv_ootottttot = self.calculate_policy_adv(i,
                                                       ["original", "original", "tmp", "original", "tmp", "tmp", "tmp",
                                                        "tmp", "original", "tmp"])
            adv_ootottttto = self.calculate_policy_adv(i,
                                                       ["original", "original", "tmp", "original", "tmp", "tmp", "tmp",
                                                        "tmp", "tmp", "original"])
            adv_oototttttt = self.calculate_policy_adv(i,
                                                       ["original", "original", "tmp", "original", "tmp", "tmp", "tmp",
                                                        "tmp", "tmp", "tmp"])
            adv_oottoooooo = self.calculate_policy_adv(i, ["original", "original", "tmp", "tmp", "original", "original",
                                                           "original", "original", "original", "original"])
            adv_oottooooot = self.calculate_policy_adv(i, ["original", "original", "tmp", "tmp", "original", "original",
                                                           "original", "original", "original", "tmp"])
            adv_oottooooto = self.calculate_policy_adv(i, ["original", "original", "tmp", "tmp", "original", "original",
                                                           "original", "original", "tmp", "original"])
            adv_oottoooott = self.calculate_policy_adv(i, ["original", "original", "tmp", "tmp", "original", "original",
                                                           "original", "original", "tmp", "tmp"])
            adv_oottoootoo = self.calculate_policy_adv(i, ["original", "original", "tmp", "tmp", "original", "original",
                                                           "original", "tmp", "original", "original"])
            adv_oottoootot = self.calculate_policy_adv(i, ["original", "original", "tmp", "tmp", "original", "original",
                                                           "original", "tmp", "original", "tmp"])
            adv_oottoootto = self.calculate_policy_adv(i, ["original", "original", "tmp", "tmp", "original", "original",
                                                           "original", "tmp", "tmp", "original"])
            adv_oottooottt = self.calculate_policy_adv(i, ["original", "original", "tmp", "tmp", "original", "original",
                                                           "original", "tmp", "tmp", "tmp"])
            adv_oottootooo = self.calculate_policy_adv(i, ["original", "original", "tmp", "tmp", "original", "original",
                                                           "tmp", "original", "original", "original"])
            adv_oottootoot = self.calculate_policy_adv(i, ["original", "original", "tmp", "tmp", "original", "original",
                                                           "tmp", "original", "original", "tmp"])
            adv_oottoototo = self.calculate_policy_adv(i, ["original", "original", "tmp", "tmp", "original", "original",
                                                           "tmp", "original", "tmp", "original"])
            adv_oottootott = self.calculate_policy_adv(i, ["original", "original", "tmp", "tmp", "original", "original",
                                                           "tmp", "original", "tmp", "tmp"])
            adv_oottoottoo = self.calculate_policy_adv(i, ["original", "original", "tmp", "tmp", "original", "original",
                                                           "tmp", "tmp", "original", "original"])
            adv_oottoottot = self.calculate_policy_adv(i, ["original", "original", "tmp", "tmp", "original", "original",
                                                           "tmp", "tmp", "original", "tmp"])
            adv_oottoottto = self.calculate_policy_adv(i, ["original", "original", "tmp", "tmp", "original", "original",
                                                           "tmp", "tmp", "tmp", "original"])
            adv_oottootttt = self.calculate_policy_adv(i, ["original", "original", "tmp", "tmp", "original", "original",
                                                           "tmp", "tmp", "tmp", "tmp"])
            adv_oottotoooo = self.calculate_policy_adv(i, ["original", "original", "tmp", "tmp", "original", "tmp",
                                                           "original", "original", "original", "original"])
            adv_oottotooot = self.calculate_policy_adv(i, ["original", "original", "tmp", "tmp", "original", "tmp",
                                                           "original", "original", "original", "tmp"])
            adv_oottotooto = self.calculate_policy_adv(i, ["original", "original", "tmp", "tmp", "original", "tmp",
                                                           "original", "original", "tmp", "original"])
            adv_oottotoott = self.calculate_policy_adv(i, ["original", "original", "tmp", "tmp", "original", "tmp",
                                                           "original", "original", "tmp", "tmp"])
            adv_oottototoo = self.calculate_policy_adv(i, ["original", "original", "tmp", "tmp", "original", "tmp",
                                                           "original", "tmp", "original", "original"])
            adv_oottototot = self.calculate_policy_adv(i, ["original", "original", "tmp", "tmp", "original", "tmp",
                                                           "original", "tmp", "original", "tmp"])
            adv_oottototto = self.calculate_policy_adv(i, ["original", "original", "tmp", "tmp", "original", "tmp",
                                                           "original", "tmp", "tmp", "original"])
            adv_oottotottt = self.calculate_policy_adv(i, ["original", "original", "tmp", "tmp", "original", "tmp",
                                                           "original", "tmp", "tmp", "tmp"])
            adv_oottottooo = self.calculate_policy_adv(i,
                                                       ["original", "original", "tmp", "tmp", "original", "tmp", "tmp",
                                                        "original", "original", "original"])
            adv_oottottoot = self.calculate_policy_adv(i,
                                                       ["original", "original", "tmp", "tmp", "original", "tmp", "tmp",
                                                        "original", "original", "tmp"])
            adv_oottottoto = self.calculate_policy_adv(i,
                                                       ["original", "original", "tmp", "tmp", "original", "tmp", "tmp",
                                                        "original", "tmp", "original"])
            adv_oottottott = self.calculate_policy_adv(i,
                                                       ["original", "original", "tmp", "tmp", "original", "tmp", "tmp",
                                                        "original", "tmp", "tmp"])
            adv_oottotttoo = self.calculate_policy_adv(i,
                                                       ["original", "original", "tmp", "tmp", "original", "tmp", "tmp",
                                                        "tmp", "original", "original"])
            adv_oottotttot = self.calculate_policy_adv(i,
                                                       ["original", "original", "tmp", "tmp", "original", "tmp", "tmp",
                                                        "tmp", "original", "tmp"])
            adv_oottotttto = self.calculate_policy_adv(i,
                                                       ["original", "original", "tmp", "tmp", "original", "tmp", "tmp",
                                                        "tmp", "tmp", "original"])
            adv_oottottttt = self.calculate_policy_adv(i,
                                                       ["original", "original", "tmp", "tmp", "original", "tmp", "tmp",
                                                        "tmp", "tmp", "tmp"])
            adv_ootttooooo = self.calculate_policy_adv(i, ["original", "original", "tmp", "tmp", "tmp", "original",
                                                           "original", "original", "original", "original"])
            adv_ootttoooot = self.calculate_policy_adv(i, ["original", "original", "tmp", "tmp", "tmp", "original",
                                                           "original", "original", "original", "tmp"])
            adv_ootttoooto = self.calculate_policy_adv(i, ["original", "original", "tmp", "tmp", "tmp", "original",
                                                           "original", "original", "tmp", "original"])
            adv_ootttooott = self.calculate_policy_adv(i, ["original", "original", "tmp", "tmp", "tmp", "original",
                                                           "original", "original", "tmp", "tmp"])
            adv_ootttootoo = self.calculate_policy_adv(i, ["original", "original", "tmp", "tmp", "tmp", "original",
                                                           "original", "tmp", "original", "original"])
            adv_ootttootot = self.calculate_policy_adv(i, ["original", "original", "tmp", "tmp", "tmp", "original",
                                                           "original", "tmp", "original", "tmp"])
            adv_ootttootto = self.calculate_policy_adv(i, ["original", "original", "tmp", "tmp", "tmp", "original",
                                                           "original", "tmp", "tmp", "original"])
            adv_ootttoottt = self.calculate_policy_adv(i, ["original", "original", "tmp", "tmp", "tmp", "original",
                                                           "original", "tmp", "tmp", "tmp"])
            adv_ootttotooo = self.calculate_policy_adv(i,
                                                       ["original", "original", "tmp", "tmp", "tmp", "original", "tmp",
                                                        "original", "original", "original"])
            adv_ootttotoot = self.calculate_policy_adv(i,
                                                       ["original", "original", "tmp", "tmp", "tmp", "original", "tmp",
                                                        "original", "original", "tmp"])
            adv_ootttototo = self.calculate_policy_adv(i,
                                                       ["original", "original", "tmp", "tmp", "tmp", "original", "tmp",
                                                        "original", "tmp", "original"])
            adv_ootttotott = self.calculate_policy_adv(i,
                                                       ["original", "original", "tmp", "tmp", "tmp", "original", "tmp",
                                                        "original", "tmp", "tmp"])
            adv_ootttottoo = self.calculate_policy_adv(i,
                                                       ["original", "original", "tmp", "tmp", "tmp", "original", "tmp",
                                                        "tmp", "original", "original"])
            adv_ootttottot = self.calculate_policy_adv(i,
                                                       ["original", "original", "tmp", "tmp", "tmp", "original", "tmp",
                                                        "tmp", "original", "tmp"])
            adv_ootttottto = self.calculate_policy_adv(i,
                                                       ["original", "original", "tmp", "tmp", "tmp", "original", "tmp",
                                                        "tmp", "tmp", "original"])
            adv_ootttotttt = self.calculate_policy_adv(i,
                                                       ["original", "original", "tmp", "tmp", "tmp", "original", "tmp",
                                                        "tmp", "tmp", "tmp"])
            adv_oottttoooo = self.calculate_policy_adv(i,
                                                       ["original", "original", "tmp", "tmp", "tmp", "tmp", "original",
                                                        "original", "original", "original"])
            adv_oottttooot = self.calculate_policy_adv(i,
                                                       ["original", "original", "tmp", "tmp", "tmp", "tmp", "original",
                                                        "original", "original", "tmp"])
            adv_oottttooto = self.calculate_policy_adv(i,
                                                       ["original", "original", "tmp", "tmp", "tmp", "tmp", "original",
                                                        "original", "tmp", "original"])
            adv_oottttoott = self.calculate_policy_adv(i,
                                                       ["original", "original", "tmp", "tmp", "tmp", "tmp", "original",
                                                        "original", "tmp", "tmp"])
            adv_oottttotoo = self.calculate_policy_adv(i,
                                                       ["original", "original", "tmp", "tmp", "tmp", "tmp", "original",
                                                        "tmp", "original", "original"])
            adv_oottttotot = self.calculate_policy_adv(i,
                                                       ["original", "original", "tmp", "tmp", "tmp", "tmp", "original",
                                                        "tmp", "original", "tmp"])
            adv_oottttotto = self.calculate_policy_adv(i,
                                                       ["original", "original", "tmp", "tmp", "tmp", "tmp", "original",
                                                        "tmp", "tmp", "original"])
            adv_oottttottt = self.calculate_policy_adv(i,
                                                       ["original", "original", "tmp", "tmp", "tmp", "tmp", "original",
                                                        "tmp", "tmp", "tmp"])
            adv_ootttttooo = self.calculate_policy_adv(i, ["original", "original", "tmp", "tmp", "tmp", "tmp", "tmp",
                                                           "original", "original", "original"])
            adv_ootttttoot = self.calculate_policy_adv(i, ["original", "original", "tmp", "tmp", "tmp", "tmp", "tmp",
                                                           "original", "original", "tmp"])
            adv_ootttttoto = self.calculate_policy_adv(i, ["original", "original", "tmp", "tmp", "tmp", "tmp", "tmp",
                                                           "original", "tmp", "original"])
            adv_ootttttott = self.calculate_policy_adv(i, ["original", "original", "tmp", "tmp", "tmp", "tmp", "tmp",
                                                           "original", "tmp", "tmp"])
            adv_oottttttoo = self.calculate_policy_adv(i, ["original", "original", "tmp", "tmp", "tmp", "tmp", "tmp",
                                                           "tmp", "original", "original"])
            adv_oottttttot = self.calculate_policy_adv(i, ["original", "original", "tmp", "tmp", "tmp", "tmp", "tmp",
                                                           "tmp", "original", "tmp"])
            adv_oottttttto = self.calculate_policy_adv(i, ["original", "original", "tmp", "tmp", "tmp", "tmp", "tmp",
                                                           "tmp", "tmp", "original"])
            adv_ootttttttt = self.calculate_policy_adv(i, ["original", "original", "tmp", "tmp", "tmp", "tmp", "tmp",
                                                           "tmp", "tmp", "tmp"])
            adv_otoooooooo = self.calculate_policy_adv(i, ["original", "tmp", "original", "original", "original",
                                                           "original", "original", "original", "original", "original"])
            adv_otooooooot = self.calculate_policy_adv(i, ["original", "tmp", "original", "original", "original",
                                                           "original", "original", "original", "original", "tmp"])
            adv_otooooooto = self.calculate_policy_adv(i, ["original", "tmp", "original", "original", "original",
                                                           "original", "original", "original", "tmp", "original"])
            adv_otoooooott = self.calculate_policy_adv(i, ["original", "tmp", "original", "original", "original",
                                                           "original", "original", "original", "tmp", "tmp"])
            adv_otoooootoo = self.calculate_policy_adv(i, ["original", "tmp", "original", "original", "original",
                                                           "original", "original", "tmp", "original", "original"])
            adv_otoooootot = self.calculate_policy_adv(i, ["original", "tmp", "original", "original", "original",
                                                           "original", "original", "tmp", "original", "tmp"])
            adv_otoooootto = self.calculate_policy_adv(i, ["original", "tmp", "original", "original", "original",
                                                           "original", "original", "tmp", "tmp", "original"])
            adv_otooooottt = self.calculate_policy_adv(i, ["original", "tmp", "original", "original", "original",
                                                           "original", "original", "tmp", "tmp", "tmp"])
            adv_otooootooo = self.calculate_policy_adv(i, ["original", "tmp", "original", "original", "original",
                                                           "original", "tmp", "original", "original", "original"])
            adv_otooootoot = self.calculate_policy_adv(i, ["original", "tmp", "original", "original", "original",
                                                           "original", "tmp", "original", "original", "tmp"])
            adv_otoooototo = self.calculate_policy_adv(i, ["original", "tmp", "original", "original", "original",
                                                           "original", "tmp", "original", "tmp", "original"])
            adv_otooootott = self.calculate_policy_adv(i, ["original", "tmp", "original", "original", "original",
                                                           "original", "tmp", "original", "tmp", "tmp"])
            adv_otoooottoo = self.calculate_policy_adv(i, ["original", "tmp", "original", "original", "original",
                                                           "original", "tmp", "tmp", "original", "original"])
            adv_otoooottot = self.calculate_policy_adv(i, ["original", "tmp", "original", "original", "original",
                                                           "original", "tmp", "tmp", "original", "tmp"])
            adv_otoooottto = self.calculate_policy_adv(i, ["original", "tmp", "original", "original", "original",
                                                           "original", "tmp", "tmp", "tmp", "original"])
            adv_otooootttt = self.calculate_policy_adv(i, ["original", "tmp", "original", "original", "original",
                                                           "original", "tmp", "tmp", "tmp", "tmp"])
            adv_otoootoooo = self.calculate_policy_adv(i, ["original", "tmp", "original", "original", "original", "tmp",
                                                           "original", "original", "original", "original"])
            adv_otoootooot = self.calculate_policy_adv(i, ["original", "tmp", "original", "original", "original", "tmp",
                                                           "original", "original", "original", "tmp"])
            adv_otoootooto = self.calculate_policy_adv(i, ["original", "tmp", "original", "original", "original", "tmp",
                                                           "original", "original", "tmp", "original"])
            adv_otoootoott = self.calculate_policy_adv(i, ["original", "tmp", "original", "original", "original", "tmp",
                                                           "original", "original", "tmp", "tmp"])
            adv_otooototoo = self.calculate_policy_adv(i, ["original", "tmp", "original", "original", "original", "tmp",
                                                           "original", "tmp", "original", "original"])
            adv_otooototot = self.calculate_policy_adv(i, ["original", "tmp", "original", "original", "original", "tmp",
                                                           "original", "tmp", "original", "tmp"])
            adv_otooototto = self.calculate_policy_adv(i, ["original", "tmp", "original", "original", "original", "tmp",
                                                           "original", "tmp", "tmp", "original"])
            adv_otoootottt = self.calculate_policy_adv(i, ["original", "tmp", "original", "original", "original", "tmp",
                                                           "original", "tmp", "tmp", "tmp"])
            adv_otooottooo = self.calculate_policy_adv(i, ["original", "tmp", "original", "original", "original", "tmp",
                                                           "tmp", "original", "original", "original"])
            adv_otooottoot = self.calculate_policy_adv(i, ["original", "tmp", "original", "original", "original", "tmp",
                                                           "tmp", "original", "original", "tmp"])
            adv_otooottoto = self.calculate_policy_adv(i, ["original", "tmp", "original", "original", "original", "tmp",
                                                           "tmp", "original", "tmp", "original"])
            adv_otooottott = self.calculate_policy_adv(i, ["original", "tmp", "original", "original", "original", "tmp",
                                                           "tmp", "original", "tmp", "tmp"])
            adv_otoootttoo = self.calculate_policy_adv(i, ["original", "tmp", "original", "original", "original", "tmp",
                                                           "tmp", "tmp", "original", "original"])
            adv_otoootttot = self.calculate_policy_adv(i, ["original", "tmp", "original", "original", "original", "tmp",
                                                           "tmp", "tmp", "original", "tmp"])
            adv_otoootttto = self.calculate_policy_adv(i, ["original", "tmp", "original", "original", "original", "tmp",
                                                           "tmp", "tmp", "tmp", "original"])
            adv_otooottttt = self.calculate_policy_adv(i, ["original", "tmp", "original", "original", "original", "tmp",
                                                           "tmp", "tmp", "tmp", "tmp"])
            adv_otootooooo = self.calculate_policy_adv(i, ["original", "tmp", "original", "original", "tmp", "original",
                                                           "original", "original", "original", "original"])
            adv_otootoooot = self.calculate_policy_adv(i, ["original", "tmp", "original", "original", "tmp", "original",
                                                           "original", "original", "original", "tmp"])
            adv_otootoooto = self.calculate_policy_adv(i, ["original", "tmp", "original", "original", "tmp", "original",
                                                           "original", "original", "tmp", "original"])
            adv_otootooott = self.calculate_policy_adv(i, ["original", "tmp", "original", "original", "tmp", "original",
                                                           "original", "original", "tmp", "tmp"])
            adv_otootootoo = self.calculate_policy_adv(i, ["original", "tmp", "original", "original", "tmp", "original",
                                                           "original", "tmp", "original", "original"])
            adv_otootootot = self.calculate_policy_adv(i, ["original", "tmp", "original", "original", "tmp", "original",
                                                           "original", "tmp", "original", "tmp"])
            adv_otootootto = self.calculate_policy_adv(i, ["original", "tmp", "original", "original", "tmp", "original",
                                                           "original", "tmp", "tmp", "original"])
            adv_otootoottt = self.calculate_policy_adv(i, ["original", "tmp", "original", "original", "tmp", "original",
                                                           "original", "tmp", "tmp", "tmp"])
            adv_otoototooo = self.calculate_policy_adv(i, ["original", "tmp", "original", "original", "tmp", "original",
                                                           "tmp", "original", "original", "original"])
            adv_otoototoot = self.calculate_policy_adv(i, ["original", "tmp", "original", "original", "tmp", "original",
                                                           "tmp", "original", "original", "tmp"])
            adv_otootototo = self.calculate_policy_adv(i, ["original", "tmp", "original", "original", "tmp", "original",
                                                           "tmp", "original", "tmp", "original"])
            adv_otoototott = self.calculate_policy_adv(i, ["original", "tmp", "original", "original", "tmp", "original",
                                                           "tmp", "original", "tmp", "tmp"])
            adv_otootottoo = self.calculate_policy_adv(i, ["original", "tmp", "original", "original", "tmp", "original",
                                                           "tmp", "tmp", "original", "original"])
            adv_otootottot = self.calculate_policy_adv(i, ["original", "tmp", "original", "original", "tmp", "original",
                                                           "tmp", "tmp", "original", "tmp"])
            adv_otootottto = self.calculate_policy_adv(i, ["original", "tmp", "original", "original", "tmp", "original",
                                                           "tmp", "tmp", "tmp", "original"])
            adv_otoototttt = self.calculate_policy_adv(i, ["original", "tmp", "original", "original", "tmp", "original",
                                                           "tmp", "tmp", "tmp", "tmp"])
            adv_otoottoooo = self.calculate_policy_adv(i, ["original", "tmp", "original", "original", "tmp", "tmp",
                                                           "original", "original", "original", "original"])
            adv_otoottooot = self.calculate_policy_adv(i, ["original", "tmp", "original", "original", "tmp", "tmp",
                                                           "original", "original", "original", "tmp"])
            adv_otoottooto = self.calculate_policy_adv(i, ["original", "tmp", "original", "original", "tmp", "tmp",
                                                           "original", "original", "tmp", "original"])
            adv_otoottoott = self.calculate_policy_adv(i, ["original", "tmp", "original", "original", "tmp", "tmp",
                                                           "original", "original", "tmp", "tmp"])
            adv_otoottotoo = self.calculate_policy_adv(i, ["original", "tmp", "original", "original", "tmp", "tmp",
                                                           "original", "tmp", "original", "original"])
            adv_otoottotot = self.calculate_policy_adv(i, ["original", "tmp", "original", "original", "tmp", "tmp",
                                                           "original", "tmp", "original", "tmp"])
            adv_otoottotto = self.calculate_policy_adv(i, ["original", "tmp", "original", "original", "tmp", "tmp",
                                                           "original", "tmp", "tmp", "original"])
            adv_otoottottt = self.calculate_policy_adv(i, ["original", "tmp", "original", "original", "tmp", "tmp",
                                                           "original", "tmp", "tmp", "tmp"])
            adv_otootttooo = self.calculate_policy_adv(i,
                                                       ["original", "tmp", "original", "original", "tmp", "tmp", "tmp",
                                                        "original", "original", "original"])
            adv_otootttoot = self.calculate_policy_adv(i,
                                                       ["original", "tmp", "original", "original", "tmp", "tmp", "tmp",
                                                        "original", "original", "tmp"])
            adv_otootttoto = self.calculate_policy_adv(i,
                                                       ["original", "tmp", "original", "original", "tmp", "tmp", "tmp",
                                                        "original", "tmp", "original"])
            adv_otootttott = self.calculate_policy_adv(i,
                                                       ["original", "tmp", "original", "original", "tmp", "tmp", "tmp",
                                                        "original", "tmp", "tmp"])
            adv_otoottttoo = self.calculate_policy_adv(i,
                                                       ["original", "tmp", "original", "original", "tmp", "tmp", "tmp",
                                                        "tmp", "original", "original"])
            adv_otoottttot = self.calculate_policy_adv(i,
                                                       ["original", "tmp", "original", "original", "tmp", "tmp", "tmp",
                                                        "tmp", "original", "tmp"])
            adv_otoottttto = self.calculate_policy_adv(i,
                                                       ["original", "tmp", "original", "original", "tmp", "tmp", "tmp",
                                                        "tmp", "tmp", "original"])
            adv_otootttttt = self.calculate_policy_adv(i,
                                                       ["original", "tmp", "original", "original", "tmp", "tmp", "tmp",
                                                        "tmp", "tmp", "tmp"])
            adv_ototoooooo = self.calculate_policy_adv(i, ["original", "tmp", "original", "tmp", "original", "original",
                                                           "original", "original", "original", "original"])
            adv_ototooooot = self.calculate_policy_adv(i, ["original", "tmp", "original", "tmp", "original", "original",
                                                           "original", "original", "original", "tmp"])
            adv_ototooooto = self.calculate_policy_adv(i, ["original", "tmp", "original", "tmp", "original", "original",
                                                           "original", "original", "tmp", "original"])
            adv_ototoooott = self.calculate_policy_adv(i, ["original", "tmp", "original", "tmp", "original", "original",
                                                           "original", "original", "tmp", "tmp"])
            adv_ototoootoo = self.calculate_policy_adv(i, ["original", "tmp", "original", "tmp", "original", "original",
                                                           "original", "tmp", "original", "original"])
            adv_ototoootot = self.calculate_policy_adv(i, ["original", "tmp", "original", "tmp", "original", "original",
                                                           "original", "tmp", "original", "tmp"])
            adv_ototoootto = self.calculate_policy_adv(i, ["original", "tmp", "original", "tmp", "original", "original",
                                                           "original", "tmp", "tmp", "original"])
            adv_ototooottt = self.calculate_policy_adv(i, ["original", "tmp", "original", "tmp", "original", "original",
                                                           "original", "tmp", "tmp", "tmp"])
            adv_ototootooo = self.calculate_policy_adv(i, ["original", "tmp", "original", "tmp", "original", "original",
                                                           "tmp", "original", "original", "original"])
            adv_ototootoot = self.calculate_policy_adv(i, ["original", "tmp", "original", "tmp", "original", "original",
                                                           "tmp", "original", "original", "tmp"])
            adv_ototoototo = self.calculate_policy_adv(i, ["original", "tmp", "original", "tmp", "original", "original",
                                                           "tmp", "original", "tmp", "original"])
            adv_ototootott = self.calculate_policy_adv(i, ["original", "tmp", "original", "tmp", "original", "original",
                                                           "tmp", "original", "tmp", "tmp"])
            adv_ototoottoo = self.calculate_policy_adv(i, ["original", "tmp", "original", "tmp", "original", "original",
                                                           "tmp", "tmp", "original", "original"])
            adv_ototoottot = self.calculate_policy_adv(i, ["original", "tmp", "original", "tmp", "original", "original",
                                                           "tmp", "tmp", "original", "tmp"])
            adv_ototoottto = self.calculate_policy_adv(i, ["original", "tmp", "original", "tmp", "original", "original",
                                                           "tmp", "tmp", "tmp", "original"])
            adv_ototootttt = self.calculate_policy_adv(i, ["original", "tmp", "original", "tmp", "original", "original",
                                                           "tmp", "tmp", "tmp", "tmp"])
            adv_otototoooo = self.calculate_policy_adv(i, ["original", "tmp", "original", "tmp", "original", "tmp",
                                                           "original", "original", "original", "original"])
            adv_otototooot = self.calculate_policy_adv(i, ["original", "tmp", "original", "tmp", "original", "tmp",
                                                           "original", "original", "original", "tmp"])
            adv_otototooto = self.calculate_policy_adv(i, ["original", "tmp", "original", "tmp", "original", "tmp",
                                                           "original", "original", "tmp", "original"])
            adv_otototoott = self.calculate_policy_adv(i, ["original", "tmp", "original", "tmp", "original", "tmp",
                                                           "original", "original", "tmp", "tmp"])
            adv_ototototoo = self.calculate_policy_adv(i, ["original", "tmp", "original", "tmp", "original", "tmp",
                                                           "original", "tmp", "original", "original"])
            adv_ototototot = self.calculate_policy_adv(i, ["original", "tmp", "original", "tmp", "original", "tmp",
                                                           "original", "tmp", "original", "tmp"])
            adv_ototototto = self.calculate_policy_adv(i, ["original", "tmp", "original", "tmp", "original", "tmp",
                                                           "original", "tmp", "tmp", "original"])
            adv_otototottt = self.calculate_policy_adv(i, ["original", "tmp", "original", "tmp", "original", "tmp",
                                                           "original", "tmp", "tmp", "tmp"])
            adv_ototottooo = self.calculate_policy_adv(i,
                                                       ["original", "tmp", "original", "tmp", "original", "tmp", "tmp",
                                                        "original", "original", "original"])
            adv_ototottoot = self.calculate_policy_adv(i,
                                                       ["original", "tmp", "original", "tmp", "original", "tmp", "tmp",
                                                        "original", "original", "tmp"])
            adv_ototottoto = self.calculate_policy_adv(i,
                                                       ["original", "tmp", "original", "tmp", "original", "tmp", "tmp",
                                                        "original", "tmp", "original"])
            adv_ototottott = self.calculate_policy_adv(i,
                                                       ["original", "tmp", "original", "tmp", "original", "tmp", "tmp",
                                                        "original", "tmp", "tmp"])
            adv_otototttoo = self.calculate_policy_adv(i,
                                                       ["original", "tmp", "original", "tmp", "original", "tmp", "tmp",
                                                        "tmp", "original", "original"])
            adv_otototttot = self.calculate_policy_adv(i,
                                                       ["original", "tmp", "original", "tmp", "original", "tmp", "tmp",
                                                        "tmp", "original", "tmp"])
            adv_otototttto = self.calculate_policy_adv(i,
                                                       ["original", "tmp", "original", "tmp", "original", "tmp", "tmp",
                                                        "tmp", "tmp", "original"])
            adv_ototottttt = self.calculate_policy_adv(i,
                                                       ["original", "tmp", "original", "tmp", "original", "tmp", "tmp",
                                                        "tmp", "tmp", "tmp"])
            adv_otottooooo = self.calculate_policy_adv(i, ["original", "tmp", "original", "tmp", "tmp", "original",
                                                           "original", "original", "original", "original"])
            adv_otottoooot = self.calculate_policy_adv(i, ["original", "tmp", "original", "tmp", "tmp", "original",
                                                           "original", "original", "original", "tmp"])
            adv_otottoooto = self.calculate_policy_adv(i, ["original", "tmp", "original", "tmp", "tmp", "original",
                                                           "original", "original", "tmp", "original"])
            adv_otottooott = self.calculate_policy_adv(i, ["original", "tmp", "original", "tmp", "tmp", "original",
                                                           "original", "original", "tmp", "tmp"])
            adv_otottootoo = self.calculate_policy_adv(i, ["original", "tmp", "original", "tmp", "tmp", "original",
                                                           "original", "tmp", "original", "original"])
            adv_otottootot = self.calculate_policy_adv(i, ["original", "tmp", "original", "tmp", "tmp", "original",
                                                           "original", "tmp", "original", "tmp"])
            adv_otottootto = self.calculate_policy_adv(i, ["original", "tmp", "original", "tmp", "tmp", "original",
                                                           "original", "tmp", "tmp", "original"])
            adv_otottoottt = self.calculate_policy_adv(i, ["original", "tmp", "original", "tmp", "tmp", "original",
                                                           "original", "tmp", "tmp", "tmp"])
            adv_otottotooo = self.calculate_policy_adv(i,
                                                       ["original", "tmp", "original", "tmp", "tmp", "original", "tmp",
                                                        "original", "original", "original"])
            adv_otottotoot = self.calculate_policy_adv(i,
                                                       ["original", "tmp", "original", "tmp", "tmp", "original", "tmp",
                                                        "original", "original", "tmp"])
            adv_otottototo = self.calculate_policy_adv(i,
                                                       ["original", "tmp", "original", "tmp", "tmp", "original", "tmp",
                                                        "original", "tmp", "original"])
            adv_otottotott = self.calculate_policy_adv(i,
                                                       ["original", "tmp", "original", "tmp", "tmp", "original", "tmp",
                                                        "original", "tmp", "tmp"])
            adv_otottottoo = self.calculate_policy_adv(i,
                                                       ["original", "tmp", "original", "tmp", "tmp", "original", "tmp",
                                                        "tmp", "original", "original"])
            adv_otottottot = self.calculate_policy_adv(i,
                                                       ["original", "tmp", "original", "tmp", "tmp", "original", "tmp",
                                                        "tmp", "original", "tmp"])
            adv_otottottto = self.calculate_policy_adv(i,
                                                       ["original", "tmp", "original", "tmp", "tmp", "original", "tmp",
                                                        "tmp", "tmp", "original"])
            adv_otottotttt = self.calculate_policy_adv(i,
                                                       ["original", "tmp", "original", "tmp", "tmp", "original", "tmp",
                                                        "tmp", "tmp", "tmp"])
            adv_ototttoooo = self.calculate_policy_adv(i,
                                                       ["original", "tmp", "original", "tmp", "tmp", "tmp", "original",
                                                        "original", "original", "original"])
            adv_ototttooot = self.calculate_policy_adv(i,
                                                       ["original", "tmp", "original", "tmp", "tmp", "tmp", "original",
                                                        "original", "original", "tmp"])
            adv_ototttooto = self.calculate_policy_adv(i,
                                                       ["original", "tmp", "original", "tmp", "tmp", "tmp", "original",
                                                        "original", "tmp", "original"])
            adv_ototttoott = self.calculate_policy_adv(i,
                                                       ["original", "tmp", "original", "tmp", "tmp", "tmp", "original",
                                                        "original", "tmp", "tmp"])
            adv_ototttotoo = self.calculate_policy_adv(i,
                                                       ["original", "tmp", "original", "tmp", "tmp", "tmp", "original",
                                                        "tmp", "original", "original"])
            adv_ototttotot = self.calculate_policy_adv(i,
                                                       ["original", "tmp", "original", "tmp", "tmp", "tmp", "original",
                                                        "tmp", "original", "tmp"])
            adv_ototttotto = self.calculate_policy_adv(i,
                                                       ["original", "tmp", "original", "tmp", "tmp", "tmp", "original",
                                                        "tmp", "tmp", "original"])
            adv_ototttottt = self.calculate_policy_adv(i,
                                                       ["original", "tmp", "original", "tmp", "tmp", "tmp", "original",
                                                        "tmp", "tmp", "tmp"])
            adv_otottttooo = self.calculate_policy_adv(i, ["original", "tmp", "original", "tmp", "tmp", "tmp", "tmp",
                                                           "original", "original", "original"])
            adv_otottttoot = self.calculate_policy_adv(i, ["original", "tmp", "original", "tmp", "tmp", "tmp", "tmp",
                                                           "original", "original", "tmp"])
            adv_otottttoto = self.calculate_policy_adv(i, ["original", "tmp", "original", "tmp", "tmp", "tmp", "tmp",
                                                           "original", "tmp", "original"])
            adv_otottttott = self.calculate_policy_adv(i, ["original", "tmp", "original", "tmp", "tmp", "tmp", "tmp",
                                                           "original", "tmp", "tmp"])
            adv_ototttttoo = self.calculate_policy_adv(i, ["original", "tmp", "original", "tmp", "tmp", "tmp", "tmp",
                                                           "tmp", "original", "original"])
            adv_ototttttot = self.calculate_policy_adv(i, ["original", "tmp", "original", "tmp", "tmp", "tmp", "tmp",
                                                           "tmp", "original", "tmp"])
            adv_ototttttto = self.calculate_policy_adv(i, ["original", "tmp", "original", "tmp", "tmp", "tmp", "tmp",
                                                           "tmp", "tmp", "original"])
            adv_otottttttt = self.calculate_policy_adv(i, ["original", "tmp", "original", "tmp", "tmp", "tmp", "tmp",
                                                           "tmp", "tmp", "tmp"])
            adv_ottooooooo = self.calculate_policy_adv(i, ["original", "tmp", "tmp", "original", "original", "original",
                                                           "original", "original", "original", "original"])
            adv_ottoooooot = self.calculate_policy_adv(i, ["original", "tmp", "tmp", "original", "original", "original",
                                                           "original", "original", "original", "tmp"])
            adv_ottoooooto = self.calculate_policy_adv(i, ["original", "tmp", "tmp", "original", "original", "original",
                                                           "original", "original", "tmp", "original"])
            adv_ottooooott = self.calculate_policy_adv(i, ["original", "tmp", "tmp", "original", "original", "original",
                                                           "original", "original", "tmp", "tmp"])
            adv_ottooootoo = self.calculate_policy_adv(i, ["original", "tmp", "tmp", "original", "original", "original",
                                                           "original", "tmp", "original", "original"])
            adv_ottooootot = self.calculate_policy_adv(i, ["original", "tmp", "tmp", "original", "original", "original",
                                                           "original", "tmp", "original", "tmp"])
            adv_ottooootto = self.calculate_policy_adv(i, ["original", "tmp", "tmp", "original", "original", "original",
                                                           "original", "tmp", "tmp", "original"])
            adv_ottoooottt = self.calculate_policy_adv(i, ["original", "tmp", "tmp", "original", "original", "original",
                                                           "original", "tmp", "tmp", "tmp"])
            adv_ottoootooo = self.calculate_policy_adv(i, ["original", "tmp", "tmp", "original", "original", "original",
                                                           "tmp", "original", "original", "original"])
            adv_ottoootoot = self.calculate_policy_adv(i, ["original", "tmp", "tmp", "original", "original", "original",
                                                           "tmp", "original", "original", "tmp"])
            adv_ottooototo = self.calculate_policy_adv(i, ["original", "tmp", "tmp", "original", "original", "original",
                                                           "tmp", "original", "tmp", "original"])
            adv_ottoootott = self.calculate_policy_adv(i, ["original", "tmp", "tmp", "original", "original", "original",
                                                           "tmp", "original", "tmp", "tmp"])
            adv_ottooottoo = self.calculate_policy_adv(i, ["original", "tmp", "tmp", "original", "original", "original",
                                                           "tmp", "tmp", "original", "original"])
            adv_ottooottot = self.calculate_policy_adv(i, ["original", "tmp", "tmp", "original", "original", "original",
                                                           "tmp", "tmp", "original", "tmp"])
            adv_ottooottto = self.calculate_policy_adv(i, ["original", "tmp", "tmp", "original", "original", "original",
                                                           "tmp", "tmp", "tmp", "original"])
            adv_ottoootttt = self.calculate_policy_adv(i, ["original", "tmp", "tmp", "original", "original", "original",
                                                           "tmp", "tmp", "tmp", "tmp"])
            adv_ottootoooo = self.calculate_policy_adv(i, ["original", "tmp", "tmp", "original", "original", "tmp",
                                                           "original", "original", "original", "original"])
            adv_ottootooot = self.calculate_policy_adv(i, ["original", "tmp", "tmp", "original", "original", "tmp",
                                                           "original", "original", "original", "tmp"])
            adv_ottootooto = self.calculate_policy_adv(i, ["original", "tmp", "tmp", "original", "original", "tmp",
                                                           "original", "original", "tmp", "original"])
            adv_ottootoott = self.calculate_policy_adv(i, ["original", "tmp", "tmp", "original", "original", "tmp",
                                                           "original", "original", "tmp", "tmp"])
            adv_ottoototoo = self.calculate_policy_adv(i, ["original", "tmp", "tmp", "original", "original", "tmp",
                                                           "original", "tmp", "original", "original"])
            adv_ottoototot = self.calculate_policy_adv(i, ["original", "tmp", "tmp", "original", "original", "tmp",
                                                           "original", "tmp", "original", "tmp"])
            adv_ottoototto = self.calculate_policy_adv(i, ["original", "tmp", "tmp", "original", "original", "tmp",
                                                           "original", "tmp", "tmp", "original"])
            adv_ottootottt = self.calculate_policy_adv(i, ["original", "tmp", "tmp", "original", "original", "tmp",
                                                           "original", "tmp", "tmp", "tmp"])
            adv_ottoottooo = self.calculate_policy_adv(i,
                                                       ["original", "tmp", "tmp", "original", "original", "tmp", "tmp",
                                                        "original", "original", "original"])
            adv_ottoottoot = self.calculate_policy_adv(i,
                                                       ["original", "tmp", "tmp", "original", "original", "tmp", "tmp",
                                                        "original", "original", "tmp"])
            adv_ottoottoto = self.calculate_policy_adv(i,
                                                       ["original", "tmp", "tmp", "original", "original", "tmp", "tmp",
                                                        "original", "tmp", "original"])
            adv_ottoottott = self.calculate_policy_adv(i,
                                                       ["original", "tmp", "tmp", "original", "original", "tmp", "tmp",
                                                        "original", "tmp", "tmp"])
            adv_ottootttoo = self.calculate_policy_adv(i,
                                                       ["original", "tmp", "tmp", "original", "original", "tmp", "tmp",
                                                        "tmp", "original", "original"])
            adv_ottootttot = self.calculate_policy_adv(i,
                                                       ["original", "tmp", "tmp", "original", "original", "tmp", "tmp",
                                                        "tmp", "original", "tmp"])
            adv_ottootttto = self.calculate_policy_adv(i,
                                                       ["original", "tmp", "tmp", "original", "original", "tmp", "tmp",
                                                        "tmp", "tmp", "original"])
            adv_ottoottttt = self.calculate_policy_adv(i,
                                                       ["original", "tmp", "tmp", "original", "original", "tmp", "tmp",
                                                        "tmp", "tmp", "tmp"])
            adv_ottotooooo = self.calculate_policy_adv(i, ["original", "tmp", "tmp", "original", "tmp", "original",
                                                           "original", "original", "original", "original"])
            adv_ottotoooot = self.calculate_policy_adv(i, ["original", "tmp", "tmp", "original", "tmp", "original",
                                                           "original", "original", "original", "tmp"])
            adv_ottotoooto = self.calculate_policy_adv(i, ["original", "tmp", "tmp", "original", "tmp", "original",
                                                           "original", "original", "tmp", "original"])
            adv_ottotooott = self.calculate_policy_adv(i, ["original", "tmp", "tmp", "original", "tmp", "original",
                                                           "original", "original", "tmp", "tmp"])
            adv_ottotootoo = self.calculate_policy_adv(i, ["original", "tmp", "tmp", "original", "tmp", "original",
                                                           "original", "tmp", "original", "original"])
            adv_ottotootot = self.calculate_policy_adv(i, ["original", "tmp", "tmp", "original", "tmp", "original",
                                                           "original", "tmp", "original", "tmp"])
            adv_ottotootto = self.calculate_policy_adv(i, ["original", "tmp", "tmp", "original", "tmp", "original",
                                                           "original", "tmp", "tmp", "original"])
            adv_ottotoottt = self.calculate_policy_adv(i, ["original", "tmp", "tmp", "original", "tmp", "original",
                                                           "original", "tmp", "tmp", "tmp"])
            adv_ottototooo = self.calculate_policy_adv(i,
                                                       ["original", "tmp", "tmp", "original", "tmp", "original", "tmp",
                                                        "original", "original", "original"])
            adv_ottototoot = self.calculate_policy_adv(i,
                                                       ["original", "tmp", "tmp", "original", "tmp", "original", "tmp",
                                                        "original", "original", "tmp"])
            adv_ottotototo = self.calculate_policy_adv(i,
                                                       ["original", "tmp", "tmp", "original", "tmp", "original", "tmp",
                                                        "original", "tmp", "original"])
            adv_ottototott = self.calculate_policy_adv(i,
                                                       ["original", "tmp", "tmp", "original", "tmp", "original", "tmp",
                                                        "original", "tmp", "tmp"])
            adv_ottotottoo = self.calculate_policy_adv(i,
                                                       ["original", "tmp", "tmp", "original", "tmp", "original", "tmp",
                                                        "tmp", "original", "original"])
            adv_ottotottot = self.calculate_policy_adv(i,
                                                       ["original", "tmp", "tmp", "original", "tmp", "original", "tmp",
                                                        "tmp", "original", "tmp"])
            adv_ottotottto = self.calculate_policy_adv(i,
                                                       ["original", "tmp", "tmp", "original", "tmp", "original", "tmp",
                                                        "tmp", "tmp", "original"])
            adv_ottototttt = self.calculate_policy_adv(i,
                                                       ["original", "tmp", "tmp", "original", "tmp", "original", "tmp",
                                                        "tmp", "tmp", "tmp"])
            adv_ottottoooo = self.calculate_policy_adv(i,
                                                       ["original", "tmp", "tmp", "original", "tmp", "tmp", "original",
                                                        "original", "original", "original"])
            adv_ottottooot = self.calculate_policy_adv(i,
                                                       ["original", "tmp", "tmp", "original", "tmp", "tmp", "original",
                                                        "original", "original", "tmp"])
            adv_ottottooto = self.calculate_policy_adv(i,
                                                       ["original", "tmp", "tmp", "original", "tmp", "tmp", "original",
                                                        "original", "tmp", "original"])
            adv_ottottoott = self.calculate_policy_adv(i,
                                                       ["original", "tmp", "tmp", "original", "tmp", "tmp", "original",
                                                        "original", "tmp", "tmp"])
            adv_ottottotoo = self.calculate_policy_adv(i,
                                                       ["original", "tmp", "tmp", "original", "tmp", "tmp", "original",
                                                        "tmp", "original", "original"])
            adv_ottottotot = self.calculate_policy_adv(i,
                                                       ["original", "tmp", "tmp", "original", "tmp", "tmp", "original",
                                                        "tmp", "original", "tmp"])
            adv_ottottotto = self.calculate_policy_adv(i,
                                                       ["original", "tmp", "tmp", "original", "tmp", "tmp", "original",
                                                        "tmp", "tmp", "original"])
            adv_ottottottt = self.calculate_policy_adv(i,
                                                       ["original", "tmp", "tmp", "original", "tmp", "tmp", "original",
                                                        "tmp", "tmp", "tmp"])
            adv_ottotttooo = self.calculate_policy_adv(i, ["original", "tmp", "tmp", "original", "tmp", "tmp", "tmp",
                                                           "original", "original", "original"])
            adv_ottotttoot = self.calculate_policy_adv(i, ["original", "tmp", "tmp", "original", "tmp", "tmp", "tmp",
                                                           "original", "original", "tmp"])
            adv_ottotttoto = self.calculate_policy_adv(i, ["original", "tmp", "tmp", "original", "tmp", "tmp", "tmp",
                                                           "original", "tmp", "original"])
            adv_ottotttott = self.calculate_policy_adv(i, ["original", "tmp", "tmp", "original", "tmp", "tmp", "tmp",
                                                           "original", "tmp", "tmp"])
            adv_ottottttoo = self.calculate_policy_adv(i, ["original", "tmp", "tmp", "original", "tmp", "tmp", "tmp",
                                                           "tmp", "original", "original"])
            adv_ottottttot = self.calculate_policy_adv(i, ["original", "tmp", "tmp", "original", "tmp", "tmp", "tmp",
                                                           "tmp", "original", "tmp"])
            adv_ottottttto = self.calculate_policy_adv(i, ["original", "tmp", "tmp", "original", "tmp", "tmp", "tmp",
                                                           "tmp", "tmp", "original"])
            adv_ottotttttt = self.calculate_policy_adv(i, ["original", "tmp", "tmp", "original", "tmp", "tmp", "tmp",
                                                           "tmp", "tmp", "tmp"])
            adv_otttoooooo = self.calculate_policy_adv(i, ["original", "tmp", "tmp", "tmp", "original", "original",
                                                           "original", "original", "original", "original"])
            adv_otttooooot = self.calculate_policy_adv(i, ["original", "tmp", "tmp", "tmp", "original", "original",
                                                           "original", "original", "original", "tmp"])
            adv_otttooooto = self.calculate_policy_adv(i, ["original", "tmp", "tmp", "tmp", "original", "original",
                                                           "original", "original", "tmp", "original"])
            adv_otttoooott = self.calculate_policy_adv(i, ["original", "tmp", "tmp", "tmp", "original", "original",
                                                           "original", "original", "tmp", "tmp"])
            adv_otttoootoo = self.calculate_policy_adv(i, ["original", "tmp", "tmp", "tmp", "original", "original",
                                                           "original", "tmp", "original", "original"])
            adv_otttoootot = self.calculate_policy_adv(i, ["original", "tmp", "tmp", "tmp", "original", "original",
                                                           "original", "tmp", "original", "tmp"])
            adv_otttoootto = self.calculate_policy_adv(i, ["original", "tmp", "tmp", "tmp", "original", "original",
                                                           "original", "tmp", "tmp", "original"])
            adv_otttooottt = self.calculate_policy_adv(i, ["original", "tmp", "tmp", "tmp", "original", "original",
                                                           "original", "tmp", "tmp", "tmp"])
            adv_otttootooo = self.calculate_policy_adv(i,
                                                       ["original", "tmp", "tmp", "tmp", "original", "original", "tmp",
                                                        "original", "original", "original"])
            adv_otttootoot = self.calculate_policy_adv(i,
                                                       ["original", "tmp", "tmp", "tmp", "original", "original", "tmp",
                                                        "original", "original", "tmp"])
            adv_otttoototo = self.calculate_policy_adv(i,
                                                       ["original", "tmp", "tmp", "tmp", "original", "original", "tmp",
                                                        "original", "tmp", "original"])
            adv_otttootott = self.calculate_policy_adv(i,
                                                       ["original", "tmp", "tmp", "tmp", "original", "original", "tmp",
                                                        "original", "tmp", "tmp"])
            adv_otttoottoo = self.calculate_policy_adv(i,
                                                       ["original", "tmp", "tmp", "tmp", "original", "original", "tmp",
                                                        "tmp", "original", "original"])
            adv_otttoottot = self.calculate_policy_adv(i,
                                                       ["original", "tmp", "tmp", "tmp", "original", "original", "tmp",
                                                        "tmp", "original", "tmp"])
            adv_otttoottto = self.calculate_policy_adv(i,
                                                       ["original", "tmp", "tmp", "tmp", "original", "original", "tmp",
                                                        "tmp", "tmp", "original"])
            adv_otttootttt = self.calculate_policy_adv(i,
                                                       ["original", "tmp", "tmp", "tmp", "original", "original", "tmp",
                                                        "tmp", "tmp", "tmp"])
            adv_otttotoooo = self.calculate_policy_adv(i,
                                                       ["original", "tmp", "tmp", "tmp", "original", "tmp", "original",
                                                        "original", "original", "original"])
            adv_otttotooot = self.calculate_policy_adv(i,
                                                       ["original", "tmp", "tmp", "tmp", "original", "tmp", "original",
                                                        "original", "original", "tmp"])
            adv_otttotooto = self.calculate_policy_adv(i,
                                                       ["original", "tmp", "tmp", "tmp", "original", "tmp", "original",
                                                        "original", "tmp", "original"])
            adv_otttotoott = self.calculate_policy_adv(i,
                                                       ["original", "tmp", "tmp", "tmp", "original", "tmp", "original",
                                                        "original", "tmp", "tmp"])
            adv_otttototoo = self.calculate_policy_adv(i,
                                                       ["original", "tmp", "tmp", "tmp", "original", "tmp", "original",
                                                        "tmp", "original", "original"])
            adv_otttototot = self.calculate_policy_adv(i,
                                                       ["original", "tmp", "tmp", "tmp", "original", "tmp", "original",
                                                        "tmp", "original", "tmp"])
            adv_otttototto = self.calculate_policy_adv(i,
                                                       ["original", "tmp", "tmp", "tmp", "original", "tmp", "original",
                                                        "tmp", "tmp", "original"])
            adv_otttotottt = self.calculate_policy_adv(i,
                                                       ["original", "tmp", "tmp", "tmp", "original", "tmp", "original",
                                                        "tmp", "tmp", "tmp"])
            adv_otttottooo = self.calculate_policy_adv(i, ["original", "tmp", "tmp", "tmp", "original", "tmp", "tmp",
                                                           "original", "original", "original"])
            adv_otttottoot = self.calculate_policy_adv(i, ["original", "tmp", "tmp", "tmp", "original", "tmp", "tmp",
                                                           "original", "original", "tmp"])
            adv_otttottoto = self.calculate_policy_adv(i, ["original", "tmp", "tmp", "tmp", "original", "tmp", "tmp",
                                                           "original", "tmp", "original"])
            adv_otttottott = self.calculate_policy_adv(i, ["original", "tmp", "tmp", "tmp", "original", "tmp", "tmp",
                                                           "original", "tmp", "tmp"])
            adv_otttotttoo = self.calculate_policy_adv(i, ["original", "tmp", "tmp", "tmp", "original", "tmp", "tmp",
                                                           "tmp", "original", "original"])
            adv_otttotttot = self.calculate_policy_adv(i, ["original", "tmp", "tmp", "tmp", "original", "tmp", "tmp",
                                                           "tmp", "original", "tmp"])
            adv_otttotttto = self.calculate_policy_adv(i, ["original", "tmp", "tmp", "tmp", "original", "tmp", "tmp",
                                                           "tmp", "tmp", "original"])
            adv_otttottttt = self.calculate_policy_adv(i, ["original", "tmp", "tmp", "tmp", "original", "tmp", "tmp",
                                                           "tmp", "tmp", "tmp"])
            adv_ottttooooo = self.calculate_policy_adv(i,
                                                       ["original", "tmp", "tmp", "tmp", "tmp", "original", "original",
                                                        "original", "original", "original"])
            adv_ottttoooot = self.calculate_policy_adv(i,
                                                       ["original", "tmp", "tmp", "tmp", "tmp", "original", "original",
                                                        "original", "original", "tmp"])
            adv_ottttoooto = self.calculate_policy_adv(i,
                                                       ["original", "tmp", "tmp", "tmp", "tmp", "original", "original",
                                                        "original", "tmp", "original"])
            adv_ottttooott = self.calculate_policy_adv(i,
                                                       ["original", "tmp", "tmp", "tmp", "tmp", "original", "original",
                                                        "original", "tmp", "tmp"])
            adv_ottttootoo = self.calculate_policy_adv(i,
                                                       ["original", "tmp", "tmp", "tmp", "tmp", "original", "original",
                                                        "tmp", "original", "original"])
            adv_ottttootot = self.calculate_policy_adv(i,
                                                       ["original", "tmp", "tmp", "tmp", "tmp", "original", "original",
                                                        "tmp", "original", "tmp"])
            adv_ottttootto = self.calculate_policy_adv(i,
                                                       ["original", "tmp", "tmp", "tmp", "tmp", "original", "original",
                                                        "tmp", "tmp", "original"])
            adv_ottttoottt = self.calculate_policy_adv(i,
                                                       ["original", "tmp", "tmp", "tmp", "tmp", "original", "original",
                                                        "tmp", "tmp", "tmp"])
            adv_ottttotooo = self.calculate_policy_adv(i, ["original", "tmp", "tmp", "tmp", "tmp", "original", "tmp",
                                                           "original", "original", "original"])
            adv_ottttotoot = self.calculate_policy_adv(i, ["original", "tmp", "tmp", "tmp", "tmp", "original", "tmp",
                                                           "original", "original", "tmp"])
            adv_ottttototo = self.calculate_policy_adv(i, ["original", "tmp", "tmp", "tmp", "tmp", "original", "tmp",
                                                           "original", "tmp", "original"])
            adv_ottttotott = self.calculate_policy_adv(i, ["original", "tmp", "tmp", "tmp", "tmp", "original", "tmp",
                                                           "original", "tmp", "tmp"])
            adv_ottttottoo = self.calculate_policy_adv(i, ["original", "tmp", "tmp", "tmp", "tmp", "original", "tmp",
                                                           "tmp", "original", "original"])
            adv_ottttottot = self.calculate_policy_adv(i, ["original", "tmp", "tmp", "tmp", "tmp", "original", "tmp",
                                                           "tmp", "original", "tmp"])
            adv_ottttottto = self.calculate_policy_adv(i, ["original", "tmp", "tmp", "tmp", "tmp", "original", "tmp",
                                                           "tmp", "tmp", "original"])
            adv_ottttotttt = self.calculate_policy_adv(i, ["original", "tmp", "tmp", "tmp", "tmp", "original", "tmp",
                                                           "tmp", "tmp", "tmp"])
            adv_otttttoooo = self.calculate_policy_adv(i, ["original", "tmp", "tmp", "tmp", "tmp", "tmp", "original",
                                                           "original", "original", "original"])
            adv_otttttooot = self.calculate_policy_adv(i, ["original", "tmp", "tmp", "tmp", "tmp", "tmp", "original",
                                                           "original", "original", "tmp"])
            adv_otttttooto = self.calculate_policy_adv(i, ["original", "tmp", "tmp", "tmp", "tmp", "tmp", "original",
                                                           "original", "tmp", "original"])
            adv_otttttoott = self.calculate_policy_adv(i, ["original", "tmp", "tmp", "tmp", "tmp", "tmp", "original",
                                                           "original", "tmp", "tmp"])
            adv_otttttotoo = self.calculate_policy_adv(i, ["original", "tmp", "tmp", "tmp", "tmp", "tmp", "original",
                                                           "tmp", "original", "original"])
            adv_otttttotot = self.calculate_policy_adv(i, ["original", "tmp", "tmp", "tmp", "tmp", "tmp", "original",
                                                           "tmp", "original", "tmp"])
            adv_otttttotto = self.calculate_policy_adv(i, ["original", "tmp", "tmp", "tmp", "tmp", "tmp", "original",
                                                           "tmp", "tmp", "original"])
            adv_otttttottt = self.calculate_policy_adv(i, ["original", "tmp", "tmp", "tmp", "tmp", "tmp", "original",
                                                           "tmp", "tmp", "tmp"])
            adv_ottttttooo = self.calculate_policy_adv(i, ["original", "tmp", "tmp", "tmp", "tmp", "tmp", "tmp",
                                                           "original", "original", "original"])
            adv_ottttttoot = self.calculate_policy_adv(i, ["original", "tmp", "tmp", "tmp", "tmp", "tmp", "tmp",
                                                           "original", "original", "tmp"])
            adv_ottttttoto = self.calculate_policy_adv(i, ["original", "tmp", "tmp", "tmp", "tmp", "tmp", "tmp",
                                                           "original", "tmp", "original"])
            adv_ottttttott = self.calculate_policy_adv(i, ["original", "tmp", "tmp", "tmp", "tmp", "tmp", "tmp",
                                                           "original", "tmp", "tmp"])
            adv_otttttttoo = self.calculate_policy_adv(i, ["original", "tmp", "tmp", "tmp", "tmp", "tmp", "tmp", "tmp",
                                                           "original", "original"])
            adv_otttttttot = self.calculate_policy_adv(i, ["original", "tmp", "tmp", "tmp", "tmp", "tmp", "tmp", "tmp",
                                                           "original", "tmp"])
            adv_otttttttto = self.calculate_policy_adv(i, ["original", "tmp", "tmp", "tmp", "tmp", "tmp", "tmp", "tmp",
                                                           "tmp", "original"])
            adv_ottttttttt = self.calculate_policy_adv(i, ["original", "tmp", "tmp", "tmp", "tmp", "tmp", "tmp", "tmp",
                                                           "tmp", "tmp"])
            adv_tooooooooo = self.calculate_policy_adv(i, ["tmp", "original", "original", "original", "original",
                                                           "original", "original", "original", "original", "original"])
            adv_toooooooot = self.calculate_policy_adv(i, ["tmp", "original", "original", "original", "original",
                                                           "original", "original", "original", "original", "tmp"])
            adv_toooooooto = self.calculate_policy_adv(i, ["tmp", "original", "original", "original", "original",
                                                           "original", "original", "original", "tmp", "original"])
            adv_tooooooott = self.calculate_policy_adv(i, ["tmp", "original", "original", "original", "original",
                                                           "original", "original", "original", "tmp", "tmp"])
            adv_tooooootoo = self.calculate_policy_adv(i, ["tmp", "original", "original", "original", "original",
                                                           "original", "original", "tmp", "original", "original"])
            adv_tooooootot = self.calculate_policy_adv(i, ["tmp", "original", "original", "original", "original",
                                                           "original", "original", "tmp", "original", "tmp"])
            adv_tooooootto = self.calculate_policy_adv(i, ["tmp", "original", "original", "original", "original",
                                                           "original", "original", "tmp", "tmp", "original"])
            adv_toooooottt = self.calculate_policy_adv(i, ["tmp", "original", "original", "original", "original",
                                                           "original", "original", "tmp", "tmp", "tmp"])
            adv_toooootooo = self.calculate_policy_adv(i, ["tmp", "original", "original", "original", "original",
                                                           "original", "tmp", "original", "original", "original"])
            adv_toooootoot = self.calculate_policy_adv(i, ["tmp", "original", "original", "original", "original",
                                                           "original", "tmp", "original", "original", "tmp"])
            adv_tooooototo = self.calculate_policy_adv(i, ["tmp", "original", "original", "original", "original",
                                                           "original", "tmp", "original", "tmp", "original"])
            adv_toooootott = self.calculate_policy_adv(i, ["tmp", "original", "original", "original", "original",
                                                           "original", "tmp", "original", "tmp", "tmp"])
            adv_tooooottoo = self.calculate_policy_adv(i, ["tmp", "original", "original", "original", "original",
                                                           "original", "tmp", "tmp", "original", "original"])
            adv_tooooottot = self.calculate_policy_adv(i, ["tmp", "original", "original", "original", "original",
                                                           "original", "tmp", "tmp", "original", "tmp"])
            adv_tooooottto = self.calculate_policy_adv(i, ["tmp", "original", "original", "original", "original",
                                                           "original", "tmp", "tmp", "tmp", "original"])
            adv_toooootttt = self.calculate_policy_adv(i, ["tmp", "original", "original", "original", "original",
                                                           "original", "tmp", "tmp", "tmp", "tmp"])
            adv_tooootoooo = self.calculate_policy_adv(i, ["tmp", "original", "original", "original", "original", "tmp",
                                                           "original", "original", "original", "original"])
            adv_tooootooot = self.calculate_policy_adv(i, ["tmp", "original", "original", "original", "original", "tmp",
                                                           "original", "original", "original", "tmp"])
            adv_tooootooto = self.calculate_policy_adv(i, ["tmp", "original", "original", "original", "original", "tmp",
                                                           "original", "original", "tmp", "original"])
            adv_tooootoott = self.calculate_policy_adv(i, ["tmp", "original", "original", "original", "original", "tmp",
                                                           "original", "original", "tmp", "tmp"])
            adv_toooototoo = self.calculate_policy_adv(i, ["tmp", "original", "original", "original", "original", "tmp",
                                                           "original", "tmp", "original", "original"])
            adv_toooototot = self.calculate_policy_adv(i, ["tmp", "original", "original", "original", "original", "tmp",
                                                           "original", "tmp", "original", "tmp"])
            adv_toooototto = self.calculate_policy_adv(i, ["tmp", "original", "original", "original", "original", "tmp",
                                                           "original", "tmp", "tmp", "original"])
            adv_tooootottt = self.calculate_policy_adv(i, ["tmp", "original", "original", "original", "original", "tmp",
                                                           "original", "tmp", "tmp", "tmp"])
            adv_toooottooo = self.calculate_policy_adv(i, ["tmp", "original", "original", "original", "original", "tmp",
                                                           "tmp", "original", "original", "original"])
            adv_toooottoot = self.calculate_policy_adv(i, ["tmp", "original", "original", "original", "original", "tmp",
                                                           "tmp", "original", "original", "tmp"])
            adv_toooottoto = self.calculate_policy_adv(i, ["tmp", "original", "original", "original", "original", "tmp",
                                                           "tmp", "original", "tmp", "original"])
            adv_toooottott = self.calculate_policy_adv(i, ["tmp", "original", "original", "original", "original", "tmp",
                                                           "tmp", "original", "tmp", "tmp"])
            adv_tooootttoo = self.calculate_policy_adv(i, ["tmp", "original", "original", "original", "original", "tmp",
                                                           "tmp", "tmp", "original", "original"])
            adv_tooootttot = self.calculate_policy_adv(i, ["tmp", "original", "original", "original", "original", "tmp",
                                                           "tmp", "tmp", "original", "tmp"])
            adv_tooootttto = self.calculate_policy_adv(i, ["tmp", "original", "original", "original", "original", "tmp",
                                                           "tmp", "tmp", "tmp", "original"])
            adv_toooottttt = self.calculate_policy_adv(i, ["tmp", "original", "original", "original", "original", "tmp",
                                                           "tmp", "tmp", "tmp", "tmp"])
            adv_toootooooo = self.calculate_policy_adv(i, ["tmp", "original", "original", "original", "tmp", "original",
                                                           "original", "original", "original", "original"])
            adv_toootoooot = self.calculate_policy_adv(i, ["tmp", "original", "original", "original", "tmp", "original",
                                                           "original", "original", "original", "tmp"])
            adv_toootoooto = self.calculate_policy_adv(i, ["tmp", "original", "original", "original", "tmp", "original",
                                                           "original", "original", "tmp", "original"])
            adv_toootooott = self.calculate_policy_adv(i, ["tmp", "original", "original", "original", "tmp", "original",
                                                           "original", "original", "tmp", "tmp"])
            adv_toootootoo = self.calculate_policy_adv(i, ["tmp", "original", "original", "original", "tmp", "original",
                                                           "original", "tmp", "original", "original"])
            adv_toootootot = self.calculate_policy_adv(i, ["tmp", "original", "original", "original", "tmp", "original",
                                                           "original", "tmp", "original", "tmp"])
            adv_toootootto = self.calculate_policy_adv(i, ["tmp", "original", "original", "original", "tmp", "original",
                                                           "original", "tmp", "tmp", "original"])
            adv_toootoottt = self.calculate_policy_adv(i, ["tmp", "original", "original", "original", "tmp", "original",
                                                           "original", "tmp", "tmp", "tmp"])
            adv_tooototooo = self.calculate_policy_adv(i, ["tmp", "original", "original", "original", "tmp", "original",
                                                           "tmp", "original", "original", "original"])
            adv_tooototoot = self.calculate_policy_adv(i, ["tmp", "original", "original", "original", "tmp", "original",
                                                           "tmp", "original", "original", "tmp"])
            adv_toootototo = self.calculate_policy_adv(i, ["tmp", "original", "original", "original", "tmp", "original",
                                                           "tmp", "original", "tmp", "original"])
            adv_tooototott = self.calculate_policy_adv(i, ["tmp", "original", "original", "original", "tmp", "original",
                                                           "tmp", "original", "tmp", "tmp"])
            adv_toootottoo = self.calculate_policy_adv(i, ["tmp", "original", "original", "original", "tmp", "original",
                                                           "tmp", "tmp", "original", "original"])
            adv_toootottot = self.calculate_policy_adv(i, ["tmp", "original", "original", "original", "tmp", "original",
                                                           "tmp", "tmp", "original", "tmp"])
            adv_toootottto = self.calculate_policy_adv(i, ["tmp", "original", "original", "original", "tmp", "original",
                                                           "tmp", "tmp", "tmp", "original"])
            adv_tooototttt = self.calculate_policy_adv(i, ["tmp", "original", "original", "original", "tmp", "original",
                                                           "tmp", "tmp", "tmp", "tmp"])
            adv_tooottoooo = self.calculate_policy_adv(i, ["tmp", "original", "original", "original", "tmp", "tmp",
                                                           "original", "original", "original", "original"])
            adv_tooottooot = self.calculate_policy_adv(i, ["tmp", "original", "original", "original", "tmp", "tmp",
                                                           "original", "original", "original", "tmp"])
            adv_tooottooto = self.calculate_policy_adv(i, ["tmp", "original", "original", "original", "tmp", "tmp",
                                                           "original", "original", "tmp", "original"])
            adv_tooottoott = self.calculate_policy_adv(i, ["tmp", "original", "original", "original", "tmp", "tmp",
                                                           "original", "original", "tmp", "tmp"])
            adv_tooottotoo = self.calculate_policy_adv(i, ["tmp", "original", "original", "original", "tmp", "tmp",
                                                           "original", "tmp", "original", "original"])
            adv_tooottotot = self.calculate_policy_adv(i, ["tmp", "original", "original", "original", "tmp", "tmp",
                                                           "original", "tmp", "original", "tmp"])
            adv_tooottotto = self.calculate_policy_adv(i, ["tmp", "original", "original", "original", "tmp", "tmp",
                                                           "original", "tmp", "tmp", "original"])
            adv_tooottottt = self.calculate_policy_adv(i, ["tmp", "original", "original", "original", "tmp", "tmp",
                                                           "original", "tmp", "tmp", "tmp"])
            adv_toootttooo = self.calculate_policy_adv(i,
                                                       ["tmp", "original", "original", "original", "tmp", "tmp", "tmp",
                                                        "original", "original", "original"])
            adv_toootttoot = self.calculate_policy_adv(i,
                                                       ["tmp", "original", "original", "original", "tmp", "tmp", "tmp",
                                                        "original", "original", "tmp"])
            adv_toootttoto = self.calculate_policy_adv(i,
                                                       ["tmp", "original", "original", "original", "tmp", "tmp", "tmp",
                                                        "original", "tmp", "original"])
            adv_toootttott = self.calculate_policy_adv(i,
                                                       ["tmp", "original", "original", "original", "tmp", "tmp", "tmp",
                                                        "original", "tmp", "tmp"])
            adv_tooottttoo = self.calculate_policy_adv(i,
                                                       ["tmp", "original", "original", "original", "tmp", "tmp", "tmp",
                                                        "tmp", "original", "original"])
            adv_tooottttot = self.calculate_policy_adv(i,
                                                       ["tmp", "original", "original", "original", "tmp", "tmp", "tmp",
                                                        "tmp", "original", "tmp"])
            adv_tooottttto = self.calculate_policy_adv(i,
                                                       ["tmp", "original", "original", "original", "tmp", "tmp", "tmp",
                                                        "tmp", "tmp", "original"])
            adv_toootttttt = self.calculate_policy_adv(i,
                                                       ["tmp", "original", "original", "original", "tmp", "tmp", "tmp",
                                                        "tmp", "tmp", "tmp"])
            adv_tootoooooo = self.calculate_policy_adv(i, ["tmp", "original", "original", "tmp", "original", "original",
                                                           "original", "original", "original", "original"])
            adv_tootooooot = self.calculate_policy_adv(i, ["tmp", "original", "original", "tmp", "original", "original",
                                                           "original", "original", "original", "tmp"])
            adv_tootooooto = self.calculate_policy_adv(i, ["tmp", "original", "original", "tmp", "original", "original",
                                                           "original", "original", "tmp", "original"])
            adv_tootoooott = self.calculate_policy_adv(i, ["tmp", "original", "original", "tmp", "original", "original",
                                                           "original", "original", "tmp", "tmp"])
            adv_tootoootoo = self.calculate_policy_adv(i, ["tmp", "original", "original", "tmp", "original", "original",
                                                           "original", "tmp", "original", "original"])
            adv_tootoootot = self.calculate_policy_adv(i, ["tmp", "original", "original", "tmp", "original", "original",
                                                           "original", "tmp", "original", "tmp"])
            adv_tootoootto = self.calculate_policy_adv(i, ["tmp", "original", "original", "tmp", "original", "original",
                                                           "original", "tmp", "tmp", "original"])
            adv_tootooottt = self.calculate_policy_adv(i, ["tmp", "original", "original", "tmp", "original", "original",
                                                           "original", "tmp", "tmp", "tmp"])
            adv_tootootooo = self.calculate_policy_adv(i, ["tmp", "original", "original", "tmp", "original", "original",
                                                           "tmp", "original", "original", "original"])
            adv_tootootoot = self.calculate_policy_adv(i, ["tmp", "original", "original", "tmp", "original", "original",
                                                           "tmp", "original", "original", "tmp"])
            adv_tootoototo = self.calculate_policy_adv(i, ["tmp", "original", "original", "tmp", "original", "original",
                                                           "tmp", "original", "tmp", "original"])
            adv_tootootott = self.calculate_policy_adv(i, ["tmp", "original", "original", "tmp", "original", "original",
                                                           "tmp", "original", "tmp", "tmp"])
            adv_tootoottoo = self.calculate_policy_adv(i, ["tmp", "original", "original", "tmp", "original", "original",
                                                           "tmp", "tmp", "original", "original"])
            adv_tootoottot = self.calculate_policy_adv(i, ["tmp", "original", "original", "tmp", "original", "original",
                                                           "tmp", "tmp", "original", "tmp"])
            adv_tootoottto = self.calculate_policy_adv(i, ["tmp", "original", "original", "tmp", "original", "original",
                                                           "tmp", "tmp", "tmp", "original"])
            adv_tootootttt = self.calculate_policy_adv(i, ["tmp", "original", "original", "tmp", "original", "original",
                                                           "tmp", "tmp", "tmp", "tmp"])
            adv_toototoooo = self.calculate_policy_adv(i, ["tmp", "original", "original", "tmp", "original", "tmp",
                                                           "original", "original", "original", "original"])
            adv_toototooot = self.calculate_policy_adv(i, ["tmp", "original", "original", "tmp", "original", "tmp",
                                                           "original", "original", "original", "tmp"])
            adv_toototooto = self.calculate_policy_adv(i, ["tmp", "original", "original", "tmp", "original", "tmp",
                                                           "original", "original", "tmp", "original"])
            adv_toototoott = self.calculate_policy_adv(i, ["tmp", "original", "original", "tmp", "original", "tmp",
                                                           "original", "original", "tmp", "tmp"])
            adv_tootototoo = self.calculate_policy_adv(i, ["tmp", "original", "original", "tmp", "original", "tmp",
                                                           "original", "tmp", "original", "original"])
            adv_tootototot = self.calculate_policy_adv(i, ["tmp", "original", "original", "tmp", "original", "tmp",
                                                           "original", "tmp", "original", "tmp"])
            adv_tootototto = self.calculate_policy_adv(i, ["tmp", "original", "original", "tmp", "original", "tmp",
                                                           "original", "tmp", "tmp", "original"])
            adv_toototottt = self.calculate_policy_adv(i, ["tmp", "original", "original", "tmp", "original", "tmp",
                                                           "original", "tmp", "tmp", "tmp"])
            adv_tootottooo = self.calculate_policy_adv(i,
                                                       ["tmp", "original", "original", "tmp", "original", "tmp", "tmp",
                                                        "original", "original", "original"])
            adv_tootottoot = self.calculate_policy_adv(i,
                                                       ["tmp", "original", "original", "tmp", "original", "tmp", "tmp",
                                                        "original", "original", "tmp"])
            adv_tootottoto = self.calculate_policy_adv(i,
                                                       ["tmp", "original", "original", "tmp", "original", "tmp", "tmp",
                                                        "original", "tmp", "original"])
            adv_tootottott = self.calculate_policy_adv(i,
                                                       ["tmp", "original", "original", "tmp", "original", "tmp", "tmp",
                                                        "original", "tmp", "tmp"])
            adv_toototttoo = self.calculate_policy_adv(i,
                                                       ["tmp", "original", "original", "tmp", "original", "tmp", "tmp",
                                                        "tmp", "original", "original"])
            adv_toototttot = self.calculate_policy_adv(i,
                                                       ["tmp", "original", "original", "tmp", "original", "tmp", "tmp",
                                                        "tmp", "original", "tmp"])
            adv_toototttto = self.calculate_policy_adv(i,
                                                       ["tmp", "original", "original", "tmp", "original", "tmp", "tmp",
                                                        "tmp", "tmp", "original"])
            adv_tootottttt = self.calculate_policy_adv(i,
                                                       ["tmp", "original", "original", "tmp", "original", "tmp", "tmp",
                                                        "tmp", "tmp", "tmp"])
            adv_toottooooo = self.calculate_policy_adv(i, ["tmp", "original", "original", "tmp", "tmp", "original",
                                                           "original", "original", "original", "original"])
            adv_toottoooot = self.calculate_policy_adv(i, ["tmp", "original", "original", "tmp", "tmp", "original",
                                                           "original", "original", "original", "tmp"])
            adv_toottoooto = self.calculate_policy_adv(i, ["tmp", "original", "original", "tmp", "tmp", "original",
                                                           "original", "original", "tmp", "original"])
            adv_toottooott = self.calculate_policy_adv(i, ["tmp", "original", "original", "tmp", "tmp", "original",
                                                           "original", "original", "tmp", "tmp"])
            adv_toottootoo = self.calculate_policy_adv(i, ["tmp", "original", "original", "tmp", "tmp", "original",
                                                           "original", "tmp", "original", "original"])
            adv_toottootot = self.calculate_policy_adv(i, ["tmp", "original", "original", "tmp", "tmp", "original",
                                                           "original", "tmp", "original", "tmp"])
            adv_toottootto = self.calculate_policy_adv(i, ["tmp", "original", "original", "tmp", "tmp", "original",
                                                           "original", "tmp", "tmp", "original"])
            adv_toottoottt = self.calculate_policy_adv(i, ["tmp", "original", "original", "tmp", "tmp", "original",
                                                           "original", "tmp", "tmp", "tmp"])
            adv_toottotooo = self.calculate_policy_adv(i,
                                                       ["tmp", "original", "original", "tmp", "tmp", "original", "tmp",
                                                        "original", "original", "original"])
            adv_toottotoot = self.calculate_policy_adv(i,
                                                       ["tmp", "original", "original", "tmp", "tmp", "original", "tmp",
                                                        "original", "original", "tmp"])
            adv_toottototo = self.calculate_policy_adv(i,
                                                       ["tmp", "original", "original", "tmp", "tmp", "original", "tmp",
                                                        "original", "tmp", "original"])
            adv_toottotott = self.calculate_policy_adv(i,
                                                       ["tmp", "original", "original", "tmp", "tmp", "original", "tmp",
                                                        "original", "tmp", "tmp"])
            adv_toottottoo = self.calculate_policy_adv(i,
                                                       ["tmp", "original", "original", "tmp", "tmp", "original", "tmp",
                                                        "tmp", "original", "original"])
            adv_toottottot = self.calculate_policy_adv(i,
                                                       ["tmp", "original", "original", "tmp", "tmp", "original", "tmp",
                                                        "tmp", "original", "tmp"])
            adv_toottottto = self.calculate_policy_adv(i,
                                                       ["tmp", "original", "original", "tmp", "tmp", "original", "tmp",
                                                        "tmp", "tmp", "original"])
            adv_toottotttt = self.calculate_policy_adv(i,
                                                       ["tmp", "original", "original", "tmp", "tmp", "original", "tmp",
                                                        "tmp", "tmp", "tmp"])
            adv_tootttoooo = self.calculate_policy_adv(i,
                                                       ["tmp", "original", "original", "tmp", "tmp", "tmp", "original",
                                                        "original", "original", "original"])
            adv_tootttooot = self.calculate_policy_adv(i,
                                                       ["tmp", "original", "original", "tmp", "tmp", "tmp", "original",
                                                        "original", "original", "tmp"])
            adv_tootttooto = self.calculate_policy_adv(i,
                                                       ["tmp", "original", "original", "tmp", "tmp", "tmp", "original",
                                                        "original", "tmp", "original"])
            adv_tootttoott = self.calculate_policy_adv(i,
                                                       ["tmp", "original", "original", "tmp", "tmp", "tmp", "original",
                                                        "original", "tmp", "tmp"])
            adv_tootttotoo = self.calculate_policy_adv(i,
                                                       ["tmp", "original", "original", "tmp", "tmp", "tmp", "original",
                                                        "tmp", "original", "original"])
            adv_tootttotot = self.calculate_policy_adv(i,
                                                       ["tmp", "original", "original", "tmp", "tmp", "tmp", "original",
                                                        "tmp", "original", "tmp"])
            adv_tootttotto = self.calculate_policy_adv(i,
                                                       ["tmp", "original", "original", "tmp", "tmp", "tmp", "original",
                                                        "tmp", "tmp", "original"])
            adv_tootttottt = self.calculate_policy_adv(i,
                                                       ["tmp", "original", "original", "tmp", "tmp", "tmp", "original",
                                                        "tmp", "tmp", "tmp"])
            adv_toottttooo = self.calculate_policy_adv(i, ["tmp", "original", "original", "tmp", "tmp", "tmp", "tmp",
                                                           "original", "original", "original"])
            adv_toottttoot = self.calculate_policy_adv(i, ["tmp", "original", "original", "tmp", "tmp", "tmp", "tmp",
                                                           "original", "original", "tmp"])
            adv_toottttoto = self.calculate_policy_adv(i, ["tmp", "original", "original", "tmp", "tmp", "tmp", "tmp",
                                                           "original", "tmp", "original"])
            adv_toottttott = self.calculate_policy_adv(i, ["tmp", "original", "original", "tmp", "tmp", "tmp", "tmp",
                                                           "original", "tmp", "tmp"])
            adv_tootttttoo = self.calculate_policy_adv(i, ["tmp", "original", "original", "tmp", "tmp", "tmp", "tmp",
                                                           "tmp", "original", "original"])
            adv_tootttttot = self.calculate_policy_adv(i, ["tmp", "original", "original", "tmp", "tmp", "tmp", "tmp",
                                                           "tmp", "original", "tmp"])
            adv_tootttttto = self.calculate_policy_adv(i, ["tmp", "original", "original", "tmp", "tmp", "tmp", "tmp",
                                                           "tmp", "tmp", "original"])
            adv_toottttttt = self.calculate_policy_adv(i, ["tmp", "original", "original", "tmp", "tmp", "tmp", "tmp",
                                                           "tmp", "tmp", "tmp"])
            adv_totooooooo = self.calculate_policy_adv(i, ["tmp", "original", "tmp", "original", "original", "original",
                                                           "original", "original", "original", "original"])
            adv_totoooooot = self.calculate_policy_adv(i, ["tmp", "original", "tmp", "original", "original", "original",
                                                           "original", "original", "original", "tmp"])
            adv_totoooooto = self.calculate_policy_adv(i, ["tmp", "original", "tmp", "original", "original", "original",
                                                           "original", "original", "tmp", "original"])
            adv_totooooott = self.calculate_policy_adv(i, ["tmp", "original", "tmp", "original", "original", "original",
                                                           "original", "original", "tmp", "tmp"])
            adv_totooootoo = self.calculate_policy_adv(i, ["tmp", "original", "tmp", "original", "original", "original",
                                                           "original", "tmp", "original", "original"])
            adv_totooootot = self.calculate_policy_adv(i, ["tmp", "original", "tmp", "original", "original", "original",
                                                           "original", "tmp", "original", "tmp"])
            adv_totooootto = self.calculate_policy_adv(i, ["tmp", "original", "tmp", "original", "original", "original",
                                                           "original", "tmp", "tmp", "original"])
            adv_totoooottt = self.calculate_policy_adv(i, ["tmp", "original", "tmp", "original", "original", "original",
                                                           "original", "tmp", "tmp", "tmp"])
            adv_totoootooo = self.calculate_policy_adv(i, ["tmp", "original", "tmp", "original", "original", "original",
                                                           "tmp", "original", "original", "original"])
            adv_totoootoot = self.calculate_policy_adv(i, ["tmp", "original", "tmp", "original", "original", "original",
                                                           "tmp", "original", "original", "tmp"])
            adv_totooototo = self.calculate_policy_adv(i, ["tmp", "original", "tmp", "original", "original", "original",
                                                           "tmp", "original", "tmp", "original"])
            adv_totoootott = self.calculate_policy_adv(i, ["tmp", "original", "tmp", "original", "original", "original",
                                                           "tmp", "original", "tmp", "tmp"])
            adv_totooottoo = self.calculate_policy_adv(i, ["tmp", "original", "tmp", "original", "original", "original",
                                                           "tmp", "tmp", "original", "original"])
            adv_totooottot = self.calculate_policy_adv(i, ["tmp", "original", "tmp", "original", "original", "original",
                                                           "tmp", "tmp", "original", "tmp"])
            adv_totooottto = self.calculate_policy_adv(i, ["tmp", "original", "tmp", "original", "original", "original",
                                                           "tmp", "tmp", "tmp", "original"])
            adv_totoootttt = self.calculate_policy_adv(i, ["tmp", "original", "tmp", "original", "original", "original",
                                                           "tmp", "tmp", "tmp", "tmp"])
            adv_totootoooo = self.calculate_policy_adv(i, ["tmp", "original", "tmp", "original", "original", "tmp",
                                                           "original", "original", "original", "original"])
            adv_totootooot = self.calculate_policy_adv(i, ["tmp", "original", "tmp", "original", "original", "tmp",
                                                           "original", "original", "original", "tmp"])
            adv_totootooto = self.calculate_policy_adv(i, ["tmp", "original", "tmp", "original", "original", "tmp",
                                                           "original", "original", "tmp", "original"])
            adv_totootoott = self.calculate_policy_adv(i, ["tmp", "original", "tmp", "original", "original", "tmp",
                                                           "original", "original", "tmp", "tmp"])
            adv_totoototoo = self.calculate_policy_adv(i, ["tmp", "original", "tmp", "original", "original", "tmp",
                                                           "original", "tmp", "original", "original"])
            adv_totoototot = self.calculate_policy_adv(i, ["tmp", "original", "tmp", "original", "original", "tmp",
                                                           "original", "tmp", "original", "tmp"])
            adv_totoototto = self.calculate_policy_adv(i, ["tmp", "original", "tmp", "original", "original", "tmp",
                                                           "original", "tmp", "tmp", "original"])
            adv_totootottt = self.calculate_policy_adv(i, ["tmp", "original", "tmp", "original", "original", "tmp",
                                                           "original", "tmp", "tmp", "tmp"])
            adv_totoottooo = self.calculate_policy_adv(i,
                                                       ["tmp", "original", "tmp", "original", "original", "tmp", "tmp",
                                                        "original", "original", "original"])
            adv_totoottoot = self.calculate_policy_adv(i,
                                                       ["tmp", "original", "tmp", "original", "original", "tmp", "tmp",
                                                        "original", "original", "tmp"])
            adv_totoottoto = self.calculate_policy_adv(i,
                                                       ["tmp", "original", "tmp", "original", "original", "tmp", "tmp",
                                                        "original", "tmp", "original"])
            adv_totoottott = self.calculate_policy_adv(i,
                                                       ["tmp", "original", "tmp", "original", "original", "tmp", "tmp",
                                                        "original", "tmp", "tmp"])
            adv_totootttoo = self.calculate_policy_adv(i,
                                                       ["tmp", "original", "tmp", "original", "original", "tmp", "tmp",
                                                        "tmp", "original", "original"])
            adv_totootttot = self.calculate_policy_adv(i,
                                                       ["tmp", "original", "tmp", "original", "original", "tmp", "tmp",
                                                        "tmp", "original", "tmp"])
            adv_totootttto = self.calculate_policy_adv(i,
                                                       ["tmp", "original", "tmp", "original", "original", "tmp", "tmp",
                                                        "tmp", "tmp", "original"])
            adv_totoottttt = self.calculate_policy_adv(i,
                                                       ["tmp", "original", "tmp", "original", "original", "tmp", "tmp",
                                                        "tmp", "tmp", "tmp"])
            adv_tototooooo = self.calculate_policy_adv(i, ["tmp", "original", "tmp", "original", "tmp", "original",
                                                           "original", "original", "original", "original"])
            adv_tototoooot = self.calculate_policy_adv(i, ["tmp", "original", "tmp", "original", "tmp", "original",
                                                           "original", "original", "original", "tmp"])
            adv_tototoooto = self.calculate_policy_adv(i, ["tmp", "original", "tmp", "original", "tmp", "original",
                                                           "original", "original", "tmp", "original"])
            adv_tototooott = self.calculate_policy_adv(i, ["tmp", "original", "tmp", "original", "tmp", "original",
                                                           "original", "original", "tmp", "tmp"])
            adv_tototootoo = self.calculate_policy_adv(i, ["tmp", "original", "tmp", "original", "tmp", "original",
                                                           "original", "tmp", "original", "original"])
            adv_tototootot = self.calculate_policy_adv(i, ["tmp", "original", "tmp", "original", "tmp", "original",
                                                           "original", "tmp", "original", "tmp"])
            adv_tototootto = self.calculate_policy_adv(i, ["tmp", "original", "tmp", "original", "tmp", "original",
                                                           "original", "tmp", "tmp", "original"])
            adv_tototoottt = self.calculate_policy_adv(i, ["tmp", "original", "tmp", "original", "tmp", "original",
                                                           "original", "tmp", "tmp", "tmp"])
            adv_totototooo = self.calculate_policy_adv(i,
                                                       ["tmp", "original", "tmp", "original", "tmp", "original", "tmp",
                                                        "original", "original", "original"])
            adv_totototoot = self.calculate_policy_adv(i,
                                                       ["tmp", "original", "tmp", "original", "tmp", "original", "tmp",
                                                        "original", "original", "tmp"])
            adv_tototototo = self.calculate_policy_adv(i,
                                                       ["tmp", "original", "tmp", "original", "tmp", "original", "tmp",
                                                        "original", "tmp", "original"])
            adv_totototott = self.calculate_policy_adv(i,
                                                       ["tmp", "original", "tmp", "original", "tmp", "original", "tmp",
                                                        "original", "tmp", "tmp"])
            adv_tototottoo = self.calculate_policy_adv(i,
                                                       ["tmp", "original", "tmp", "original", "tmp", "original", "tmp",
                                                        "tmp", "original", "original"])
            adv_tototottot = self.calculate_policy_adv(i,
                                                       ["tmp", "original", "tmp", "original", "tmp", "original", "tmp",
                                                        "tmp", "original", "tmp"])
            adv_tototottto = self.calculate_policy_adv(i,
                                                       ["tmp", "original", "tmp", "original", "tmp", "original", "tmp",
                                                        "tmp", "tmp", "original"])
            adv_totototttt = self.calculate_policy_adv(i,
                                                       ["tmp", "original", "tmp", "original", "tmp", "original", "tmp",
                                                        "tmp", "tmp", "tmp"])
            adv_totottoooo = self.calculate_policy_adv(i,
                                                       ["tmp", "original", "tmp", "original", "tmp", "tmp", "original",
                                                        "original", "original", "original"])
            adv_totottooot = self.calculate_policy_adv(i,
                                                       ["tmp", "original", "tmp", "original", "tmp", "tmp", "original",
                                                        "original", "original", "tmp"])
            adv_totottooto = self.calculate_policy_adv(i,
                                                       ["tmp", "original", "tmp", "original", "tmp", "tmp", "original",
                                                        "original", "tmp", "original"])
            adv_totottoott = self.calculate_policy_adv(i,
                                                       ["tmp", "original", "tmp", "original", "tmp", "tmp", "original",
                                                        "original", "tmp", "tmp"])
            adv_totottotoo = self.calculate_policy_adv(i,
                                                       ["tmp", "original", "tmp", "original", "tmp", "tmp", "original",
                                                        "tmp", "original", "original"])
            adv_totottotot = self.calculate_policy_adv(i,
                                                       ["tmp", "original", "tmp", "original", "tmp", "tmp", "original",
                                                        "tmp", "original", "tmp"])
            adv_totottotto = self.calculate_policy_adv(i,
                                                       ["tmp", "original", "tmp", "original", "tmp", "tmp", "original",
                                                        "tmp", "tmp", "original"])
            adv_totottottt = self.calculate_policy_adv(i,
                                                       ["tmp", "original", "tmp", "original", "tmp", "tmp", "original",
                                                        "tmp", "tmp", "tmp"])
            adv_tototttooo = self.calculate_policy_adv(i, ["tmp", "original", "tmp", "original", "tmp", "tmp", "tmp",
                                                           "original", "original", "original"])
            adv_tototttoot = self.calculate_policy_adv(i, ["tmp", "original", "tmp", "original", "tmp", "tmp", "tmp",
                                                           "original", "original", "tmp"])
            adv_tototttoto = self.calculate_policy_adv(i, ["tmp", "original", "tmp", "original", "tmp", "tmp", "tmp",
                                                           "original", "tmp", "original"])
            adv_tototttott = self.calculate_policy_adv(i, ["tmp", "original", "tmp", "original", "tmp", "tmp", "tmp",
                                                           "original", "tmp", "tmp"])
            adv_totottttoo = self.calculate_policy_adv(i, ["tmp", "original", "tmp", "original", "tmp", "tmp", "tmp",
                                                           "tmp", "original", "original"])
            adv_totottttot = self.calculate_policy_adv(i, ["tmp", "original", "tmp", "original", "tmp", "tmp", "tmp",
                                                           "tmp", "original", "tmp"])
            adv_totottttto = self.calculate_policy_adv(i, ["tmp", "original", "tmp", "original", "tmp", "tmp", "tmp",
                                                           "tmp", "tmp", "original"])
            adv_tototttttt = self.calculate_policy_adv(i, ["tmp", "original", "tmp", "original", "tmp", "tmp", "tmp",
                                                           "tmp", "tmp", "tmp"])
            adv_tottoooooo = self.calculate_policy_adv(i, ["tmp", "original", "tmp", "tmp", "original", "original",
                                                           "original", "original", "original", "original"])
            adv_tottooooot = self.calculate_policy_adv(i, ["tmp", "original", "tmp", "tmp", "original", "original",
                                                           "original", "original", "original", "tmp"])
            adv_tottooooto = self.calculate_policy_adv(i, ["tmp", "original", "tmp", "tmp", "original", "original",
                                                           "original", "original", "tmp", "original"])
            adv_tottoooott = self.calculate_policy_adv(i, ["tmp", "original", "tmp", "tmp", "original", "original",
                                                           "original", "original", "tmp", "tmp"])
            adv_tottoootoo = self.calculate_policy_adv(i, ["tmp", "original", "tmp", "tmp", "original", "original",
                                                           "original", "tmp", "original", "original"])
            adv_tottoootot = self.calculate_policy_adv(i, ["tmp", "original", "tmp", "tmp", "original", "original",
                                                           "original", "tmp", "original", "tmp"])
            adv_tottoootto = self.calculate_policy_adv(i, ["tmp", "original", "tmp", "tmp", "original", "original",
                                                           "original", "tmp", "tmp", "original"])
            adv_tottooottt = self.calculate_policy_adv(i, ["tmp", "original", "tmp", "tmp", "original", "original",
                                                           "original", "tmp", "tmp", "tmp"])
            adv_tottootooo = self.calculate_policy_adv(i,
                                                       ["tmp", "original", "tmp", "tmp", "original", "original", "tmp",
                                                        "original", "original", "original"])
            adv_tottootoot = self.calculate_policy_adv(i,
                                                       ["tmp", "original", "tmp", "tmp", "original", "original", "tmp",
                                                        "original", "original", "tmp"])
            adv_tottoototo = self.calculate_policy_adv(i,
                                                       ["tmp", "original", "tmp", "tmp", "original", "original", "tmp",
                                                        "original", "tmp", "original"])
            adv_tottootott = self.calculate_policy_adv(i,
                                                       ["tmp", "original", "tmp", "tmp", "original", "original", "tmp",
                                                        "original", "tmp", "tmp"])
            adv_tottoottoo = self.calculate_policy_adv(i,
                                                       ["tmp", "original", "tmp", "tmp", "original", "original", "tmp",
                                                        "tmp", "original", "original"])
            adv_tottoottot = self.calculate_policy_adv(i,
                                                       ["tmp", "original", "tmp", "tmp", "original", "original", "tmp",
                                                        "tmp", "original", "tmp"])
            adv_tottoottto = self.calculate_policy_adv(i,
                                                       ["tmp", "original", "tmp", "tmp", "original", "original", "tmp",
                                                        "tmp", "tmp", "original"])
            adv_tottootttt = self.calculate_policy_adv(i,
                                                       ["tmp", "original", "tmp", "tmp", "original", "original", "tmp",
                                                        "tmp", "tmp", "tmp"])
            adv_tottotoooo = self.calculate_policy_adv(i,
                                                       ["tmp", "original", "tmp", "tmp", "original", "tmp", "original",
                                                        "original", "original", "original"])
            adv_tottotooot = self.calculate_policy_adv(i,
                                                       ["tmp", "original", "tmp", "tmp", "original", "tmp", "original",
                                                        "original", "original", "tmp"])
            adv_tottotooto = self.calculate_policy_adv(i,
                                                       ["tmp", "original", "tmp", "tmp", "original", "tmp", "original",
                                                        "original", "tmp", "original"])
            adv_tottotoott = self.calculate_policy_adv(i,
                                                       ["tmp", "original", "tmp", "tmp", "original", "tmp", "original",
                                                        "original", "tmp", "tmp"])
            adv_tottototoo = self.calculate_policy_adv(i,
                                                       ["tmp", "original", "tmp", "tmp", "original", "tmp", "original",
                                                        "tmp", "original", "original"])
            adv_tottototot = self.calculate_policy_adv(i,
                                                       ["tmp", "original", "tmp", "tmp", "original", "tmp", "original",
                                                        "tmp", "original", "tmp"])
            adv_tottototto = self.calculate_policy_adv(i,
                                                       ["tmp", "original", "tmp", "tmp", "original", "tmp", "original",
                                                        "tmp", "tmp", "original"])
            adv_tottotottt = self.calculate_policy_adv(i,
                                                       ["tmp", "original", "tmp", "tmp", "original", "tmp", "original",
                                                        "tmp", "tmp", "tmp"])
            adv_tottottooo = self.calculate_policy_adv(i, ["tmp", "original", "tmp", "tmp", "original", "tmp", "tmp",
                                                           "original", "original", "original"])
            adv_tottottoot = self.calculate_policy_adv(i, ["tmp", "original", "tmp", "tmp", "original", "tmp", "tmp",
                                                           "original", "original", "tmp"])
            adv_tottottoto = self.calculate_policy_adv(i, ["tmp", "original", "tmp", "tmp", "original", "tmp", "tmp",
                                                           "original", "tmp", "original"])
            adv_tottottott = self.calculate_policy_adv(i, ["tmp", "original", "tmp", "tmp", "original", "tmp", "tmp",
                                                           "original", "tmp", "tmp"])
            adv_tottotttoo = self.calculate_policy_adv(i, ["tmp", "original", "tmp", "tmp", "original", "tmp", "tmp",
                                                           "tmp", "original", "original"])
            adv_tottotttot = self.calculate_policy_adv(i, ["tmp", "original", "tmp", "tmp", "original", "tmp", "tmp",
                                                           "tmp", "original", "tmp"])
            adv_tottotttto = self.calculate_policy_adv(i, ["tmp", "original", "tmp", "tmp", "original", "tmp", "tmp",
                                                           "tmp", "tmp", "original"])
            adv_tottottttt = self.calculate_policy_adv(i, ["tmp", "original", "tmp", "tmp", "original", "tmp", "tmp",
                                                           "tmp", "tmp", "tmp"])
            adv_totttooooo = self.calculate_policy_adv(i,
                                                       ["tmp", "original", "tmp", "tmp", "tmp", "original", "original",
                                                        "original", "original", "original"])
            adv_totttoooot = self.calculate_policy_adv(i,
                                                       ["tmp", "original", "tmp", "tmp", "tmp", "original", "original",
                                                        "original", "original", "tmp"])
            adv_totttoooto = self.calculate_policy_adv(i,
                                                       ["tmp", "original", "tmp", "tmp", "tmp", "original", "original",
                                                        "original", "tmp", "original"])
            adv_totttooott = self.calculate_policy_adv(i,
                                                       ["tmp", "original", "tmp", "tmp", "tmp", "original", "original",
                                                        "original", "tmp", "tmp"])
            adv_totttootoo = self.calculate_policy_adv(i,
                                                       ["tmp", "original", "tmp", "tmp", "tmp", "original", "original",
                                                        "tmp", "original", "original"])
            adv_totttootot = self.calculate_policy_adv(i,
                                                       ["tmp", "original", "tmp", "tmp", "tmp", "original", "original",
                                                        "tmp", "original", "tmp"])
            adv_totttootto = self.calculate_policy_adv(i,
                                                       ["tmp", "original", "tmp", "tmp", "tmp", "original", "original",
                                                        "tmp", "tmp", "original"])
            adv_totttoottt = self.calculate_policy_adv(i,
                                                       ["tmp", "original", "tmp", "tmp", "tmp", "original", "original",
                                                        "tmp", "tmp", "tmp"])
            adv_totttotooo = self.calculate_policy_adv(i, ["tmp", "original", "tmp", "tmp", "tmp", "original", "tmp",
                                                           "original", "original", "original"])
            adv_totttotoot = self.calculate_policy_adv(i, ["tmp", "original", "tmp", "tmp", "tmp", "original", "tmp",
                                                           "original", "original", "tmp"])
            adv_totttototo = self.calculate_policy_adv(i, ["tmp", "original", "tmp", "tmp", "tmp", "original", "tmp",
                                                           "original", "tmp", "original"])
            adv_totttotott = self.calculate_policy_adv(i, ["tmp", "original", "tmp", "tmp", "tmp", "original", "tmp",
                                                           "original", "tmp", "tmp"])
            adv_totttottoo = self.calculate_policy_adv(i, ["tmp", "original", "tmp", "tmp", "tmp", "original", "tmp",
                                                           "tmp", "original", "original"])
            adv_totttottot = self.calculate_policy_adv(i, ["tmp", "original", "tmp", "tmp", "tmp", "original", "tmp",
                                                           "tmp", "original", "tmp"])
            adv_totttottto = self.calculate_policy_adv(i, ["tmp", "original", "tmp", "tmp", "tmp", "original", "tmp",
                                                           "tmp", "tmp", "original"])
            adv_totttotttt = self.calculate_policy_adv(i, ["tmp", "original", "tmp", "tmp", "tmp", "original", "tmp",
                                                           "tmp", "tmp", "tmp"])
            adv_tottttoooo = self.calculate_policy_adv(i, ["tmp", "original", "tmp", "tmp", "tmp", "tmp", "original",
                                                           "original", "original", "original"])
            adv_tottttooot = self.calculate_policy_adv(i, ["tmp", "original", "tmp", "tmp", "tmp", "tmp", "original",
                                                           "original", "original", "tmp"])
            adv_tottttooto = self.calculate_policy_adv(i, ["tmp", "original", "tmp", "tmp", "tmp", "tmp", "original",
                                                           "original", "tmp", "original"])
            adv_tottttoott = self.calculate_policy_adv(i, ["tmp", "original", "tmp", "tmp", "tmp", "tmp", "original",
                                                           "original", "tmp", "tmp"])
            adv_tottttotoo = self.calculate_policy_adv(i, ["tmp", "original", "tmp", "tmp", "tmp", "tmp", "original",
                                                           "tmp", "original", "original"])
            adv_tottttotot = self.calculate_policy_adv(i, ["tmp", "original", "tmp", "tmp", "tmp", "tmp", "original",
                                                           "tmp", "original", "tmp"])
            adv_tottttotto = self.calculate_policy_adv(i, ["tmp", "original", "tmp", "tmp", "tmp", "tmp", "original",
                                                           "tmp", "tmp", "original"])
            adv_tottttottt = self.calculate_policy_adv(i, ["tmp", "original", "tmp", "tmp", "tmp", "tmp", "original",
                                                           "tmp", "tmp", "tmp"])
            adv_totttttooo = self.calculate_policy_adv(i, ["tmp", "original", "tmp", "tmp", "tmp", "tmp", "tmp",
                                                           "original", "original", "original"])
            adv_totttttoot = self.calculate_policy_adv(i, ["tmp", "original", "tmp", "tmp", "tmp", "tmp", "tmp",
                                                           "original", "original", "tmp"])
            adv_totttttoto = self.calculate_policy_adv(i, ["tmp", "original", "tmp", "tmp", "tmp", "tmp", "tmp",
                                                           "original", "tmp", "original"])
            adv_totttttott = self.calculate_policy_adv(i, ["tmp", "original", "tmp", "tmp", "tmp", "tmp", "tmp",
                                                           "original", "tmp", "tmp"])
            adv_tottttttoo = self.calculate_policy_adv(i, ["tmp", "original", "tmp", "tmp", "tmp", "tmp", "tmp", "tmp",
                                                           "original", "original"])
            adv_tottttttot = self.calculate_policy_adv(i, ["tmp", "original", "tmp", "tmp", "tmp", "tmp", "tmp", "tmp",
                                                           "original", "tmp"])
            adv_tottttttto = self.calculate_policy_adv(i, ["tmp", "original", "tmp", "tmp", "tmp", "tmp", "tmp", "tmp",
                                                           "tmp", "original"])
            adv_totttttttt = self.calculate_policy_adv(i, ["tmp", "original", "tmp", "tmp", "tmp", "tmp", "tmp", "tmp",
                                                           "tmp", "tmp"])
            adv_ttoooooooo = self.calculate_policy_adv(i, ["tmp", "tmp", "original", "original", "original", "original",
                                                           "original", "original", "original", "original"])
            adv_ttooooooot = self.calculate_policy_adv(i, ["tmp", "tmp", "original", "original", "original", "original",
                                                           "original", "original", "original", "tmp"])
            adv_ttooooooto = self.calculate_policy_adv(i, ["tmp", "tmp", "original", "original", "original", "original",
                                                           "original", "original", "tmp", "original"])
            adv_ttoooooott = self.calculate_policy_adv(i, ["tmp", "tmp", "original", "original", "original", "original",
                                                           "original", "original", "tmp", "tmp"])
            adv_ttoooootoo = self.calculate_policy_adv(i, ["tmp", "tmp", "original", "original", "original", "original",
                                                           "original", "tmp", "original", "original"])
            adv_ttoooootot = self.calculate_policy_adv(i, ["tmp", "tmp", "original", "original", "original", "original",
                                                           "original", "tmp", "original", "tmp"])
            adv_ttoooootto = self.calculate_policy_adv(i, ["tmp", "tmp", "original", "original", "original", "original",
                                                           "original", "tmp", "tmp", "original"])
            adv_ttooooottt = self.calculate_policy_adv(i, ["tmp", "tmp", "original", "original", "original", "original",
                                                           "original", "tmp", "tmp", "tmp"])
            adv_ttooootooo = self.calculate_policy_adv(i, ["tmp", "tmp", "original", "original", "original", "original",
                                                           "tmp", "original", "original", "original"])
            adv_ttooootoot = self.calculate_policy_adv(i, ["tmp", "tmp", "original", "original", "original", "original",
                                                           "tmp", "original", "original", "tmp"])
            adv_ttoooototo = self.calculate_policy_adv(i, ["tmp", "tmp", "original", "original", "original", "original",
                                                           "tmp", "original", "tmp", "original"])
            adv_ttooootott = self.calculate_policy_adv(i, ["tmp", "tmp", "original", "original", "original", "original",
                                                           "tmp", "original", "tmp", "tmp"])
            adv_ttoooottoo = self.calculate_policy_adv(i, ["tmp", "tmp", "original", "original", "original", "original",
                                                           "tmp", "tmp", "original", "original"])
            adv_ttoooottot = self.calculate_policy_adv(i, ["tmp", "tmp", "original", "original", "original", "original",
                                                           "tmp", "tmp", "original", "tmp"])
            adv_ttoooottto = self.calculate_policy_adv(i, ["tmp", "tmp", "original", "original", "original", "original",
                                                           "tmp", "tmp", "tmp", "original"])
            adv_ttooootttt = self.calculate_policy_adv(i, ["tmp", "tmp", "original", "original", "original", "original",
                                                           "tmp", "tmp", "tmp", "tmp"])
            adv_ttoootoooo = self.calculate_policy_adv(i, ["tmp", "tmp", "original", "original", "original", "tmp",
                                                           "original", "original", "original", "original"])
            adv_ttoootooot = self.calculate_policy_adv(i, ["tmp", "tmp", "original", "original", "original", "tmp",
                                                           "original", "original", "original", "tmp"])
            adv_ttoootooto = self.calculate_policy_adv(i, ["tmp", "tmp", "original", "original", "original", "tmp",
                                                           "original", "original", "tmp", "original"])
            adv_ttoootoott = self.calculate_policy_adv(i, ["tmp", "tmp", "original", "original", "original", "tmp",
                                                           "original", "original", "tmp", "tmp"])
            adv_ttooototoo = self.calculate_policy_adv(i, ["tmp", "tmp", "original", "original", "original", "tmp",
                                                           "original", "tmp", "original", "original"])
            adv_ttooototot = self.calculate_policy_adv(i, ["tmp", "tmp", "original", "original", "original", "tmp",
                                                           "original", "tmp", "original", "tmp"])
            adv_ttooototto = self.calculate_policy_adv(i, ["tmp", "tmp", "original", "original", "original", "tmp",
                                                           "original", "tmp", "tmp", "original"])
            adv_ttoootottt = self.calculate_policy_adv(i, ["tmp", "tmp", "original", "original", "original", "tmp",
                                                           "original", "tmp", "tmp", "tmp"])
            adv_ttooottooo = self.calculate_policy_adv(i,
                                                       ["tmp", "tmp", "original", "original", "original", "tmp", "tmp",
                                                        "original", "original", "original"])
            adv_ttooottoot = self.calculate_policy_adv(i,
                                                       ["tmp", "tmp", "original", "original", "original", "tmp", "tmp",
                                                        "original", "original", "tmp"])
            adv_ttooottoto = self.calculate_policy_adv(i,
                                                       ["tmp", "tmp", "original", "original", "original", "tmp", "tmp",
                                                        "original", "tmp", "original"])
            adv_ttooottott = self.calculate_policy_adv(i,
                                                       ["tmp", "tmp", "original", "original", "original", "tmp", "tmp",
                                                        "original", "tmp", "tmp"])
            adv_ttoootttoo = self.calculate_policy_adv(i,
                                                       ["tmp", "tmp", "original", "original", "original", "tmp", "tmp",
                                                        "tmp", "original", "original"])
            adv_ttoootttot = self.calculate_policy_adv(i,
                                                       ["tmp", "tmp", "original", "original", "original", "tmp", "tmp",
                                                        "tmp", "original", "tmp"])
            adv_ttoootttto = self.calculate_policy_adv(i,
                                                       ["tmp", "tmp", "original", "original", "original", "tmp", "tmp",
                                                        "tmp", "tmp", "original"])
            adv_ttooottttt = self.calculate_policy_adv(i,
                                                       ["tmp", "tmp", "original", "original", "original", "tmp", "tmp",
                                                        "tmp", "tmp", "tmp"])
            adv_ttootooooo = self.calculate_policy_adv(i, ["tmp", "tmp", "original", "original", "tmp", "original",
                                                           "original", "original", "original", "original"])
            adv_ttootoooot = self.calculate_policy_adv(i, ["tmp", "tmp", "original", "original", "tmp", "original",
                                                           "original", "original", "original", "tmp"])
            adv_ttootoooto = self.calculate_policy_adv(i, ["tmp", "tmp", "original", "original", "tmp", "original",
                                                           "original", "original", "tmp", "original"])
            adv_ttootooott = self.calculate_policy_adv(i, ["tmp", "tmp", "original", "original", "tmp", "original",
                                                           "original", "original", "tmp", "tmp"])
            adv_ttootootoo = self.calculate_policy_adv(i, ["tmp", "tmp", "original", "original", "tmp", "original",
                                                           "original", "tmp", "original", "original"])
            adv_ttootootot = self.calculate_policy_adv(i, ["tmp", "tmp", "original", "original", "tmp", "original",
                                                           "original", "tmp", "original", "tmp"])
            adv_ttootootto = self.calculate_policy_adv(i, ["tmp", "tmp", "original", "original", "tmp", "original",
                                                           "original", "tmp", "tmp", "original"])
            adv_ttootoottt = self.calculate_policy_adv(i, ["tmp", "tmp", "original", "original", "tmp", "original",
                                                           "original", "tmp", "tmp", "tmp"])
            adv_ttoototooo = self.calculate_policy_adv(i,
                                                       ["tmp", "tmp", "original", "original", "tmp", "original", "tmp",
                                                        "original", "original", "original"])
            adv_ttoototoot = self.calculate_policy_adv(i,
                                                       ["tmp", "tmp", "original", "original", "tmp", "original", "tmp",
                                                        "original", "original", "tmp"])
            adv_ttootototo = self.calculate_policy_adv(i,
                                                       ["tmp", "tmp", "original", "original", "tmp", "original", "tmp",
                                                        "original", "tmp", "original"])
            adv_ttoototott = self.calculate_policy_adv(i,
                                                       ["tmp", "tmp", "original", "original", "tmp", "original", "tmp",
                                                        "original", "tmp", "tmp"])
            adv_ttootottoo = self.calculate_policy_adv(i,
                                                       ["tmp", "tmp", "original", "original", "tmp", "original", "tmp",
                                                        "tmp", "original", "original"])
            adv_ttootottot = self.calculate_policy_adv(i,
                                                       ["tmp", "tmp", "original", "original", "tmp", "original", "tmp",
                                                        "tmp", "original", "tmp"])
            adv_ttootottto = self.calculate_policy_adv(i,
                                                       ["tmp", "tmp", "original", "original", "tmp", "original", "tmp",
                                                        "tmp", "tmp", "original"])
            adv_ttoototttt = self.calculate_policy_adv(i,
                                                       ["tmp", "tmp", "original", "original", "tmp", "original", "tmp",
                                                        "tmp", "tmp", "tmp"])
            adv_ttoottoooo = self.calculate_policy_adv(i,
                                                       ["tmp", "tmp", "original", "original", "tmp", "tmp", "original",
                                                        "original", "original", "original"])
            adv_ttoottooot = self.calculate_policy_adv(i,
                                                       ["tmp", "tmp", "original", "original", "tmp", "tmp", "original",
                                                        "original", "original", "tmp"])
            adv_ttoottooto = self.calculate_policy_adv(i,
                                                       ["tmp", "tmp", "original", "original", "tmp", "tmp", "original",
                                                        "original", "tmp", "original"])
            adv_ttoottoott = self.calculate_policy_adv(i,
                                                       ["tmp", "tmp", "original", "original", "tmp", "tmp", "original",
                                                        "original", "tmp", "tmp"])
            adv_ttoottotoo = self.calculate_policy_adv(i,
                                                       ["tmp", "tmp", "original", "original", "tmp", "tmp", "original",
                                                        "tmp", "original", "original"])
            adv_ttoottotot = self.calculate_policy_adv(i,
                                                       ["tmp", "tmp", "original", "original", "tmp", "tmp", "original",
                                                        "tmp", "original", "tmp"])
            adv_ttoottotto = self.calculate_policy_adv(i,
                                                       ["tmp", "tmp", "original", "original", "tmp", "tmp", "original",
                                                        "tmp", "tmp", "original"])
            adv_ttoottottt = self.calculate_policy_adv(i,
                                                       ["tmp", "tmp", "original", "original", "tmp", "tmp", "original",
                                                        "tmp", "tmp", "tmp"])
            adv_ttootttooo = self.calculate_policy_adv(i, ["tmp", "tmp", "original", "original", "tmp", "tmp", "tmp",
                                                           "original", "original", "original"])
            adv_ttootttoot = self.calculate_policy_adv(i, ["tmp", "tmp", "original", "original", "tmp", "tmp", "tmp",
                                                           "original", "original", "tmp"])
            adv_ttootttoto = self.calculate_policy_adv(i, ["tmp", "tmp", "original", "original", "tmp", "tmp", "tmp",
                                                           "original", "tmp", "original"])
            adv_ttootttott = self.calculate_policy_adv(i, ["tmp", "tmp", "original", "original", "tmp", "tmp", "tmp",
                                                           "original", "tmp", "tmp"])
            adv_ttoottttoo = self.calculate_policy_adv(i, ["tmp", "tmp", "original", "original", "tmp", "tmp", "tmp",
                                                           "tmp", "original", "original"])
            adv_ttoottttot = self.calculate_policy_adv(i, ["tmp", "tmp", "original", "original", "tmp", "tmp", "tmp",
                                                           "tmp", "original", "tmp"])
            adv_ttoottttto = self.calculate_policy_adv(i, ["tmp", "tmp", "original", "original", "tmp", "tmp", "tmp",
                                                           "tmp", "tmp", "original"])
            adv_ttootttttt = self.calculate_policy_adv(i, ["tmp", "tmp", "original", "original", "tmp", "tmp", "tmp",
                                                           "tmp", "tmp", "tmp"])
            adv_ttotoooooo = self.calculate_policy_adv(i, ["tmp", "tmp", "original", "tmp", "original", "original",
                                                           "original", "original", "original", "original"])
            adv_ttotooooot = self.calculate_policy_adv(i, ["tmp", "tmp", "original", "tmp", "original", "original",
                                                           "original", "original", "original", "tmp"])
            adv_ttotooooto = self.calculate_policy_adv(i, ["tmp", "tmp", "original", "tmp", "original", "original",
                                                           "original", "original", "tmp", "original"])
            adv_ttotoooott = self.calculate_policy_adv(i, ["tmp", "tmp", "original", "tmp", "original", "original",
                                                           "original", "original", "tmp", "tmp"])
            adv_ttotoootoo = self.calculate_policy_adv(i, ["tmp", "tmp", "original", "tmp", "original", "original",
                                                           "original", "tmp", "original", "original"])
            adv_ttotoootot = self.calculate_policy_adv(i, ["tmp", "tmp", "original", "tmp", "original", "original",
                                                           "original", "tmp", "original", "tmp"])
            adv_ttotoootto = self.calculate_policy_adv(i, ["tmp", "tmp", "original", "tmp", "original", "original",
                                                           "original", "tmp", "tmp", "original"])
            adv_ttotooottt = self.calculate_policy_adv(i, ["tmp", "tmp", "original", "tmp", "original", "original",
                                                           "original", "tmp", "tmp", "tmp"])
            adv_ttotootooo = self.calculate_policy_adv(i,
                                                       ["tmp", "tmp", "original", "tmp", "original", "original", "tmp",
                                                        "original", "original", "original"])
            adv_ttotootoot = self.calculate_policy_adv(i,
                                                       ["tmp", "tmp", "original", "tmp", "original", "original", "tmp",
                                                        "original", "original", "tmp"])
            adv_ttotoototo = self.calculate_policy_adv(i,
                                                       ["tmp", "tmp", "original", "tmp", "original", "original", "tmp",
                                                        "original", "tmp", "original"])
            adv_ttotootott = self.calculate_policy_adv(i,
                                                       ["tmp", "tmp", "original", "tmp", "original", "original", "tmp",
                                                        "original", "tmp", "tmp"])
            adv_ttotoottoo = self.calculate_policy_adv(i,
                                                       ["tmp", "tmp", "original", "tmp", "original", "original", "tmp",
                                                        "tmp", "original", "original"])
            adv_ttotoottot = self.calculate_policy_adv(i,
                                                       ["tmp", "tmp", "original", "tmp", "original", "original", "tmp",
                                                        "tmp", "original", "tmp"])
            adv_ttotoottto = self.calculate_policy_adv(i,
                                                       ["tmp", "tmp", "original", "tmp", "original", "original", "tmp",
                                                        "tmp", "tmp", "original"])
            adv_ttotootttt = self.calculate_policy_adv(i,
                                                       ["tmp", "tmp", "original", "tmp", "original", "original", "tmp",
                                                        "tmp", "tmp", "tmp"])
            adv_ttototoooo = self.calculate_policy_adv(i,
                                                       ["tmp", "tmp", "original", "tmp", "original", "tmp", "original",
                                                        "original", "original", "original"])
            adv_ttototooot = self.calculate_policy_adv(i,
                                                       ["tmp", "tmp", "original", "tmp", "original", "tmp", "original",
                                                        "original", "original", "tmp"])
            adv_ttototooto = self.calculate_policy_adv(i,
                                                       ["tmp", "tmp", "original", "tmp", "original", "tmp", "original",
                                                        "original", "tmp", "original"])
            adv_ttototoott = self.calculate_policy_adv(i,
                                                       ["tmp", "tmp", "original", "tmp", "original", "tmp", "original",
                                                        "original", "tmp", "tmp"])
            adv_ttotototoo = self.calculate_policy_adv(i,
                                                       ["tmp", "tmp", "original", "tmp", "original", "tmp", "original",
                                                        "tmp", "original", "original"])
            adv_ttotototot = self.calculate_policy_adv(i,
                                                       ["tmp", "tmp", "original", "tmp", "original", "tmp", "original",
                                                        "tmp", "original", "tmp"])
            adv_ttotototto = self.calculate_policy_adv(i,
                                                       ["tmp", "tmp", "original", "tmp", "original", "tmp", "original",
                                                        "tmp", "tmp", "original"])
            adv_ttototottt = self.calculate_policy_adv(i,
                                                       ["tmp", "tmp", "original", "tmp", "original", "tmp", "original",
                                                        "tmp", "tmp", "tmp"])
            adv_ttotottooo = self.calculate_policy_adv(i, ["tmp", "tmp", "original", "tmp", "original", "tmp", "tmp",
                                                           "original", "original", "original"])
            adv_ttotottoot = self.calculate_policy_adv(i, ["tmp", "tmp", "original", "tmp", "original", "tmp", "tmp",
                                                           "original", "original", "tmp"])
            adv_ttotottoto = self.calculate_policy_adv(i, ["tmp", "tmp", "original", "tmp", "original", "tmp", "tmp",
                                                           "original", "tmp", "original"])
            adv_ttotottott = self.calculate_policy_adv(i, ["tmp", "tmp", "original", "tmp", "original", "tmp", "tmp",
                                                           "original", "tmp", "tmp"])
            adv_ttototttoo = self.calculate_policy_adv(i, ["tmp", "tmp", "original", "tmp", "original", "tmp", "tmp",
                                                           "tmp", "original", "original"])
            adv_ttototttot = self.calculate_policy_adv(i, ["tmp", "tmp", "original", "tmp", "original", "tmp", "tmp",
                                                           "tmp", "original", "tmp"])
            adv_ttototttto = self.calculate_policy_adv(i, ["tmp", "tmp", "original", "tmp", "original", "tmp", "tmp",
                                                           "tmp", "tmp", "original"])
            adv_ttotottttt = self.calculate_policy_adv(i, ["tmp", "tmp", "original", "tmp", "original", "tmp", "tmp",
                                                           "tmp", "tmp", "tmp"])
            adv_ttottooooo = self.calculate_policy_adv(i,
                                                       ["tmp", "tmp", "original", "tmp", "tmp", "original", "original",
                                                        "original", "original", "original"])
            adv_ttottoooot = self.calculate_policy_adv(i,
                                                       ["tmp", "tmp", "original", "tmp", "tmp", "original", "original",
                                                        "original", "original", "tmp"])
            adv_ttottoooto = self.calculate_policy_adv(i,
                                                       ["tmp", "tmp", "original", "tmp", "tmp", "original", "original",
                                                        "original", "tmp", "original"])
            adv_ttottooott = self.calculate_policy_adv(i,
                                                       ["tmp", "tmp", "original", "tmp", "tmp", "original", "original",
                                                        "original", "tmp", "tmp"])
            adv_ttottootoo = self.calculate_policy_adv(i,
                                                       ["tmp", "tmp", "original", "tmp", "tmp", "original", "original",
                                                        "tmp", "original", "original"])
            adv_ttottootot = self.calculate_policy_adv(i,
                                                       ["tmp", "tmp", "original", "tmp", "tmp", "original", "original",
                                                        "tmp", "original", "tmp"])
            adv_ttottootto = self.calculate_policy_adv(i,
                                                       ["tmp", "tmp", "original", "tmp", "tmp", "original", "original",
                                                        "tmp", "tmp", "original"])
            adv_ttottoottt = self.calculate_policy_adv(i,
                                                       ["tmp", "tmp", "original", "tmp", "tmp", "original", "original",
                                                        "tmp", "tmp", "tmp"])
            adv_ttottotooo = self.calculate_policy_adv(i, ["tmp", "tmp", "original", "tmp", "tmp", "original", "tmp",
                                                           "original", "original", "original"])
            adv_ttottotoot = self.calculate_policy_adv(i, ["tmp", "tmp", "original", "tmp", "tmp", "original", "tmp",
                                                           "original", "original", "tmp"])
            adv_ttottototo = self.calculate_policy_adv(i, ["tmp", "tmp", "original", "tmp", "tmp", "original", "tmp",
                                                           "original", "tmp", "original"])
            adv_ttottotott = self.calculate_policy_adv(i, ["tmp", "tmp", "original", "tmp", "tmp", "original", "tmp",
                                                           "original", "tmp", "tmp"])
            adv_ttottottoo = self.calculate_policy_adv(i, ["tmp", "tmp", "original", "tmp", "tmp", "original", "tmp",
                                                           "tmp", "original", "original"])
            adv_ttottottot = self.calculate_policy_adv(i, ["tmp", "tmp", "original", "tmp", "tmp", "original", "tmp",
                                                           "tmp", "original", "tmp"])
            adv_ttottottto = self.calculate_policy_adv(i, ["tmp", "tmp", "original", "tmp", "tmp", "original", "tmp",
                                                           "tmp", "tmp", "original"])
            adv_ttottotttt = self.calculate_policy_adv(i, ["tmp", "tmp", "original", "tmp", "tmp", "original", "tmp",
                                                           "tmp", "tmp", "tmp"])
            adv_ttotttoooo = self.calculate_policy_adv(i, ["tmp", "tmp", "original", "tmp", "tmp", "tmp", "original",
                                                           "original", "original", "original"])
            adv_ttotttooot = self.calculate_policy_adv(i, ["tmp", "tmp", "original", "tmp", "tmp", "tmp", "original",
                                                           "original", "original", "tmp"])
            adv_ttotttooto = self.calculate_policy_adv(i, ["tmp", "tmp", "original", "tmp", "tmp", "tmp", "original",
                                                           "original", "tmp", "original"])
            adv_ttotttoott = self.calculate_policy_adv(i, ["tmp", "tmp", "original", "tmp", "tmp", "tmp", "original",
                                                           "original", "tmp", "tmp"])
            adv_ttotttotoo = self.calculate_policy_adv(i, ["tmp", "tmp", "original", "tmp", "tmp", "tmp", "original",
                                                           "tmp", "original", "original"])
            adv_ttotttotot = self.calculate_policy_adv(i, ["tmp", "tmp", "original", "tmp", "tmp", "tmp", "original",
                                                           "tmp", "original", "tmp"])
            adv_ttotttotto = self.calculate_policy_adv(i, ["tmp", "tmp", "original", "tmp", "tmp", "tmp", "original",
                                                           "tmp", "tmp", "original"])
            adv_ttotttottt = self.calculate_policy_adv(i, ["tmp", "tmp", "original", "tmp", "tmp", "tmp", "original",
                                                           "tmp", "tmp", "tmp"])
            adv_ttottttooo = self.calculate_policy_adv(i, ["tmp", "tmp", "original", "tmp", "tmp", "tmp", "tmp",
                                                           "original", "original", "original"])
            adv_ttottttoot = self.calculate_policy_adv(i, ["tmp", "tmp", "original", "tmp", "tmp", "tmp", "tmp",
                                                           "original", "original", "tmp"])
            adv_ttottttoto = self.calculate_policy_adv(i, ["tmp", "tmp", "original", "tmp", "tmp", "tmp", "tmp",
                                                           "original", "tmp", "original"])
            adv_ttottttott = self.calculate_policy_adv(i, ["tmp", "tmp", "original", "tmp", "tmp", "tmp", "tmp",
                                                           "original", "tmp", "tmp"])
            adv_ttotttttoo = self.calculate_policy_adv(i, ["tmp", "tmp", "original", "tmp", "tmp", "tmp", "tmp", "tmp",
                                                           "original", "original"])
            adv_ttotttttot = self.calculate_policy_adv(i, ["tmp", "tmp", "original", "tmp", "tmp", "tmp", "tmp", "tmp",
                                                           "original", "tmp"])
            adv_ttotttttto = self.calculate_policy_adv(i, ["tmp", "tmp", "original", "tmp", "tmp", "tmp", "tmp", "tmp",
                                                           "tmp", "original"])
            adv_ttottttttt = self.calculate_policy_adv(i, ["tmp", "tmp", "original", "tmp", "tmp", "tmp", "tmp", "tmp",
                                                           "tmp", "tmp"])
            adv_tttooooooo = self.calculate_policy_adv(i, ["tmp", "tmp", "tmp", "original", "original", "original",
                                                           "original", "original", "original", "original"])
            adv_tttoooooot = self.calculate_policy_adv(i, ["tmp", "tmp", "tmp", "original", "original", "original",
                                                           "original", "original", "original", "tmp"])
            adv_tttoooooto = self.calculate_policy_adv(i, ["tmp", "tmp", "tmp", "original", "original", "original",
                                                           "original", "original", "tmp", "original"])
            adv_tttooooott = self.calculate_policy_adv(i, ["tmp", "tmp", "tmp", "original", "original", "original",
                                                           "original", "original", "tmp", "tmp"])
            adv_tttooootoo = self.calculate_policy_adv(i, ["tmp", "tmp", "tmp", "original", "original", "original",
                                                           "original", "tmp", "original", "original"])
            adv_tttooootot = self.calculate_policy_adv(i, ["tmp", "tmp", "tmp", "original", "original", "original",
                                                           "original", "tmp", "original", "tmp"])
            adv_tttooootto = self.calculate_policy_adv(i, ["tmp", "tmp", "tmp", "original", "original", "original",
                                                           "original", "tmp", "tmp", "original"])
            adv_tttoooottt = self.calculate_policy_adv(i, ["tmp", "tmp", "tmp", "original", "original", "original",
                                                           "original", "tmp", "tmp", "tmp"])
            adv_tttoootooo = self.calculate_policy_adv(i,
                                                       ["tmp", "tmp", "tmp", "original", "original", "original", "tmp",
                                                        "original", "original", "original"])
            adv_tttoootoot = self.calculate_policy_adv(i,
                                                       ["tmp", "tmp", "tmp", "original", "original", "original", "tmp",
                                                        "original", "original", "tmp"])
            adv_tttooototo = self.calculate_policy_adv(i,
                                                       ["tmp", "tmp", "tmp", "original", "original", "original", "tmp",
                                                        "original", "tmp", "original"])
            adv_tttoootott = self.calculate_policy_adv(i,
                                                       ["tmp", "tmp", "tmp", "original", "original", "original", "tmp",
                                                        "original", "tmp", "tmp"])
            adv_tttooottoo = self.calculate_policy_adv(i,
                                                       ["tmp", "tmp", "tmp", "original", "original", "original", "tmp",
                                                        "tmp", "original", "original"])
            adv_tttooottot = self.calculate_policy_adv(i,
                                                       ["tmp", "tmp", "tmp", "original", "original", "original", "tmp",
                                                        "tmp", "original", "tmp"])
            adv_tttooottto = self.calculate_policy_adv(i,
                                                       ["tmp", "tmp", "tmp", "original", "original", "original", "tmp",
                                                        "tmp", "tmp", "original"])
            adv_tttoootttt = self.calculate_policy_adv(i,
                                                       ["tmp", "tmp", "tmp", "original", "original", "original", "tmp",
                                                        "tmp", "tmp", "tmp"])
            adv_tttootoooo = self.calculate_policy_adv(i,
                                                       ["tmp", "tmp", "tmp", "original", "original", "tmp", "original",
                                                        "original", "original", "original"])
            adv_tttootooot = self.calculate_policy_adv(i,
                                                       ["tmp", "tmp", "tmp", "original", "original", "tmp", "original",
                                                        "original", "original", "tmp"])
            adv_tttootooto = self.calculate_policy_adv(i,
                                                       ["tmp", "tmp", "tmp", "original", "original", "tmp", "original",
                                                        "original", "tmp", "original"])
            adv_tttootoott = self.calculate_policy_adv(i,
                                                       ["tmp", "tmp", "tmp", "original", "original", "tmp", "original",
                                                        "original", "tmp", "tmp"])
            adv_tttoototoo = self.calculate_policy_adv(i,
                                                       ["tmp", "tmp", "tmp", "original", "original", "tmp", "original",
                                                        "tmp", "original", "original"])
            adv_tttoototot = self.calculate_policy_adv(i,
                                                       ["tmp", "tmp", "tmp", "original", "original", "tmp", "original",
                                                        "tmp", "original", "tmp"])
            adv_tttoototto = self.calculate_policy_adv(i,
                                                       ["tmp", "tmp", "tmp", "original", "original", "tmp", "original",
                                                        "tmp", "tmp", "original"])
            adv_tttootottt = self.calculate_policy_adv(i,
                                                       ["tmp", "tmp", "tmp", "original", "original", "tmp", "original",
                                                        "tmp", "tmp", "tmp"])
            adv_tttoottooo = self.calculate_policy_adv(i, ["tmp", "tmp", "tmp", "original", "original", "tmp", "tmp",
                                                           "original", "original", "original"])
            adv_tttoottoot = self.calculate_policy_adv(i, ["tmp", "tmp", "tmp", "original", "original", "tmp", "tmp",
                                                           "original", "original", "tmp"])
            adv_tttoottoto = self.calculate_policy_adv(i, ["tmp", "tmp", "tmp", "original", "original", "tmp", "tmp",
                                                           "original", "tmp", "original"])
            adv_tttoottott = self.calculate_policy_adv(i, ["tmp", "tmp", "tmp", "original", "original", "tmp", "tmp",
                                                           "original", "tmp", "tmp"])
            adv_tttootttoo = self.calculate_policy_adv(i, ["tmp", "tmp", "tmp", "original", "original", "tmp", "tmp",
                                                           "tmp", "original", "original"])
            adv_tttootttot = self.calculate_policy_adv(i, ["tmp", "tmp", "tmp", "original", "original", "tmp", "tmp",
                                                           "tmp", "original", "tmp"])
            adv_tttootttto = self.calculate_policy_adv(i, ["tmp", "tmp", "tmp", "original", "original", "tmp", "tmp",
                                                           "tmp", "tmp", "original"])
            adv_tttoottttt = self.calculate_policy_adv(i, ["tmp", "tmp", "tmp", "original", "original", "tmp", "tmp",
                                                           "tmp", "tmp", "tmp"])
            adv_tttotooooo = self.calculate_policy_adv(i,
                                                       ["tmp", "tmp", "tmp", "original", "tmp", "original", "original",
                                                        "original", "original", "original"])
            adv_tttotoooot = self.calculate_policy_adv(i,
                                                       ["tmp", "tmp", "tmp", "original", "tmp", "original", "original",
                                                        "original", "original", "tmp"])
            adv_tttotoooto = self.calculate_policy_adv(i,
                                                       ["tmp", "tmp", "tmp", "original", "tmp", "original", "original",
                                                        "original", "tmp", "original"])
            adv_tttotooott = self.calculate_policy_adv(i,
                                                       ["tmp", "tmp", "tmp", "original", "tmp", "original", "original",
                                                        "original", "tmp", "tmp"])
            adv_tttotootoo = self.calculate_policy_adv(i,
                                                       ["tmp", "tmp", "tmp", "original", "tmp", "original", "original",
                                                        "tmp", "original", "original"])
            adv_tttotootot = self.calculate_policy_adv(i,
                                                       ["tmp", "tmp", "tmp", "original", "tmp", "original", "original",
                                                        "tmp", "original", "tmp"])
            adv_tttotootto = self.calculate_policy_adv(i,
                                                       ["tmp", "tmp", "tmp", "original", "tmp", "original", "original",
                                                        "tmp", "tmp", "original"])
            adv_tttotoottt = self.calculate_policy_adv(i,
                                                       ["tmp", "tmp", "tmp", "original", "tmp", "original", "original",
                                                        "tmp", "tmp", "tmp"])
            adv_tttototooo = self.calculate_policy_adv(i, ["tmp", "tmp", "tmp", "original", "tmp", "original", "tmp",
                                                           "original", "original", "original"])
            adv_tttototoot = self.calculate_policy_adv(i, ["tmp", "tmp", "tmp", "original", "tmp", "original", "tmp",
                                                           "original", "original", "tmp"])
            adv_tttotototo = self.calculate_policy_adv(i, ["tmp", "tmp", "tmp", "original", "tmp", "original", "tmp",
                                                           "original", "tmp", "original"])
            adv_tttototott = self.calculate_policy_adv(i, ["tmp", "tmp", "tmp", "original", "tmp", "original", "tmp",
                                                           "original", "tmp", "tmp"])
            adv_tttotottoo = self.calculate_policy_adv(i, ["tmp", "tmp", "tmp", "original", "tmp", "original", "tmp",
                                                           "tmp", "original", "original"])
            adv_tttotottot = self.calculate_policy_adv(i, ["tmp", "tmp", "tmp", "original", "tmp", "original", "tmp",
                                                           "tmp", "original", "tmp"])
            adv_tttotottto = self.calculate_policy_adv(i, ["tmp", "tmp", "tmp", "original", "tmp", "original", "tmp",
                                                           "tmp", "tmp", "original"])
            adv_tttototttt = self.calculate_policy_adv(i, ["tmp", "tmp", "tmp", "original", "tmp", "original", "tmp",
                                                           "tmp", "tmp", "tmp"])
            adv_tttottoooo = self.calculate_policy_adv(i, ["tmp", "tmp", "tmp", "original", "tmp", "tmp", "original",
                                                           "original", "original", "original"])
            adv_tttottooot = self.calculate_policy_adv(i, ["tmp", "tmp", "tmp", "original", "tmp", "tmp", "original",
                                                           "original", "original", "tmp"])
            adv_tttottooto = self.calculate_policy_adv(i, ["tmp", "tmp", "tmp", "original", "tmp", "tmp", "original",
                                                           "original", "tmp", "original"])
            adv_tttottoott = self.calculate_policy_adv(i, ["tmp", "tmp", "tmp", "original", "tmp", "tmp", "original",
                                                           "original", "tmp", "tmp"])
            adv_tttottotoo = self.calculate_policy_adv(i, ["tmp", "tmp", "tmp", "original", "tmp", "tmp", "original",
                                                           "tmp", "original", "original"])
            adv_tttottotot = self.calculate_policy_adv(i, ["tmp", "tmp", "tmp", "original", "tmp", "tmp", "original",
                                                           "tmp", "original", "tmp"])
            adv_tttottotto = self.calculate_policy_adv(i, ["tmp", "tmp", "tmp", "original", "tmp", "tmp", "original",
                                                           "tmp", "tmp", "original"])
            adv_tttottottt = self.calculate_policy_adv(i, ["tmp", "tmp", "tmp", "original", "tmp", "tmp", "original",
                                                           "tmp", "tmp", "tmp"])
            adv_tttotttooo = self.calculate_policy_adv(i, ["tmp", "tmp", "tmp", "original", "tmp", "tmp", "tmp",
                                                           "original", "original", "original"])
            adv_tttotttoot = self.calculate_policy_adv(i, ["tmp", "tmp", "tmp", "original", "tmp", "tmp", "tmp",
                                                           "original", "original", "tmp"])
            adv_tttotttoto = self.calculate_policy_adv(i, ["tmp", "tmp", "tmp", "original", "tmp", "tmp", "tmp",
                                                           "original", "tmp", "original"])
            adv_tttotttott = self.calculate_policy_adv(i, ["tmp", "tmp", "tmp", "original", "tmp", "tmp", "tmp",
                                                           "original", "tmp", "tmp"])
            adv_tttottttoo = self.calculate_policy_adv(i, ["tmp", "tmp", "tmp", "original", "tmp", "tmp", "tmp", "tmp",
                                                           "original", "original"])
            adv_tttottttot = self.calculate_policy_adv(i, ["tmp", "tmp", "tmp", "original", "tmp", "tmp", "tmp", "tmp",
                                                           "original", "tmp"])
            adv_tttottttto = self.calculate_policy_adv(i, ["tmp", "tmp", "tmp", "original", "tmp", "tmp", "tmp", "tmp",
                                                           "tmp", "original"])
            adv_tttotttttt = self.calculate_policy_adv(i, ["tmp", "tmp", "tmp", "original", "tmp", "tmp", "tmp", "tmp",
                                                           "tmp", "tmp"])
            adv_ttttoooooo = self.calculate_policy_adv(i,
                                                       ["tmp", "tmp", "tmp", "tmp", "original", "original", "original",
                                                        "original", "original", "original"])
            adv_ttttooooot = self.calculate_policy_adv(i,
                                                       ["tmp", "tmp", "tmp", "tmp", "original", "original", "original",
                                                        "original", "original", "tmp"])
            adv_ttttooooto = self.calculate_policy_adv(i,
                                                       ["tmp", "tmp", "tmp", "tmp", "original", "original", "original",
                                                        "original", "tmp", "original"])
            adv_ttttoooott = self.calculate_policy_adv(i,
                                                       ["tmp", "tmp", "tmp", "tmp", "original", "original", "original",
                                                        "original", "tmp", "tmp"])
            adv_ttttoootoo = self.calculate_policy_adv(i,
                                                       ["tmp", "tmp", "tmp", "tmp", "original", "original", "original",
                                                        "tmp", "original", "original"])
            adv_ttttoootot = self.calculate_policy_adv(i,
                                                       ["tmp", "tmp", "tmp", "tmp", "original", "original", "original",
                                                        "tmp", "original", "tmp"])
            adv_ttttoootto = self.calculate_policy_adv(i,
                                                       ["tmp", "tmp", "tmp", "tmp", "original", "original", "original",
                                                        "tmp", "tmp", "original"])
            adv_ttttooottt = self.calculate_policy_adv(i,
                                                       ["tmp", "tmp", "tmp", "tmp", "original", "original", "original",
                                                        "tmp", "tmp", "tmp"])
            adv_ttttootooo = self.calculate_policy_adv(i, ["tmp", "tmp", "tmp", "tmp", "original", "original", "tmp",
                                                           "original", "original", "original"])
            adv_ttttootoot = self.calculate_policy_adv(i, ["tmp", "tmp", "tmp", "tmp", "original", "original", "tmp",
                                                           "original", "original", "tmp"])
            adv_ttttoototo = self.calculate_policy_adv(i, ["tmp", "tmp", "tmp", "tmp", "original", "original", "tmp",
                                                           "original", "tmp", "original"])
            adv_ttttootott = self.calculate_policy_adv(i, ["tmp", "tmp", "tmp", "tmp", "original", "original", "tmp",
                                                           "original", "tmp", "tmp"])
            adv_ttttoottoo = self.calculate_policy_adv(i, ["tmp", "tmp", "tmp", "tmp", "original", "original", "tmp",
                                                           "tmp", "original", "original"])
            adv_ttttoottot = self.calculate_policy_adv(i, ["tmp", "tmp", "tmp", "tmp", "original", "original", "tmp",
                                                           "tmp", "original", "tmp"])
            adv_ttttoottto = self.calculate_policy_adv(i, ["tmp", "tmp", "tmp", "tmp", "original", "original", "tmp",
                                                           "tmp", "tmp", "original"])
            adv_ttttootttt = self.calculate_policy_adv(i, ["tmp", "tmp", "tmp", "tmp", "original", "original", "tmp",
                                                           "tmp", "tmp", "tmp"])
            adv_ttttotoooo = self.calculate_policy_adv(i, ["tmp", "tmp", "tmp", "tmp", "original", "tmp", "original",
                                                           "original", "original", "original"])
            adv_ttttotooot = self.calculate_policy_adv(i, ["tmp", "tmp", "tmp", "tmp", "original", "tmp", "original",
                                                           "original", "original", "tmp"])
            adv_ttttotooto = self.calculate_policy_adv(i, ["tmp", "tmp", "tmp", "tmp", "original", "tmp", "original",
                                                           "original", "tmp", "original"])
            adv_ttttotoott = self.calculate_policy_adv(i, ["tmp", "tmp", "tmp", "tmp", "original", "tmp", "original",
                                                           "original", "tmp", "tmp"])
            adv_ttttototoo = self.calculate_policy_adv(i, ["tmp", "tmp", "tmp", "tmp", "original", "tmp", "original",
                                                           "tmp", "original", "original"])
            adv_ttttototot = self.calculate_policy_adv(i, ["tmp", "tmp", "tmp", "tmp", "original", "tmp", "original",
                                                           "tmp", "original", "tmp"])
            adv_ttttototto = self.calculate_policy_adv(i, ["tmp", "tmp", "tmp", "tmp", "original", "tmp", "original",
                                                           "tmp", "tmp", "original"])
            adv_ttttotottt = self.calculate_policy_adv(i, ["tmp", "tmp", "tmp", "tmp", "original", "tmp", "original",
                                                           "tmp", "tmp", "tmp"])
            adv_ttttottooo = self.calculate_policy_adv(i, ["tmp", "tmp", "tmp", "tmp", "original", "tmp", "tmp",
                                                           "original", "original", "original"])
            adv_ttttottoot = self.calculate_policy_adv(i, ["tmp", "tmp", "tmp", "tmp", "original", "tmp", "tmp",
                                                           "original", "original", "tmp"])
            adv_ttttottoto = self.calculate_policy_adv(i, ["tmp", "tmp", "tmp", "tmp", "original", "tmp", "tmp",
                                                           "original", "tmp", "original"])
            adv_ttttottott = self.calculate_policy_adv(i, ["tmp", "tmp", "tmp", "tmp", "original", "tmp", "tmp",
                                                           "original", "tmp", "tmp"])
            adv_ttttotttoo = self.calculate_policy_adv(i, ["tmp", "tmp", "tmp", "tmp", "original", "tmp", "tmp", "tmp",
                                                           "original", "original"])
            adv_ttttotttot = self.calculate_policy_adv(i, ["tmp", "tmp", "tmp", "tmp", "original", "tmp", "tmp", "tmp",
                                                           "original", "tmp"])
            adv_ttttotttto = self.calculate_policy_adv(i, ["tmp", "tmp", "tmp", "tmp", "original", "tmp", "tmp", "tmp",
                                                           "tmp", "original"])
            adv_ttttottttt = self.calculate_policy_adv(i, ["tmp", "tmp", "tmp", "tmp", "original", "tmp", "tmp", "tmp",
                                                           "tmp", "tmp"])
            adv_tttttooooo = self.calculate_policy_adv(i, ["tmp", "tmp", "tmp", "tmp", "tmp", "original", "original",
                                                           "original", "original", "original"])
            adv_tttttoooot = self.calculate_policy_adv(i, ["tmp", "tmp", "tmp", "tmp", "tmp", "original", "original",
                                                           "original", "original", "tmp"])
            adv_tttttoooto = self.calculate_policy_adv(i, ["tmp", "tmp", "tmp", "tmp", "tmp", "original", "original",
                                                           "original", "tmp", "original"])
            adv_tttttooott = self.calculate_policy_adv(i, ["tmp", "tmp", "tmp", "tmp", "tmp", "original", "original",
                                                           "original", "tmp", "tmp"])
            adv_tttttootoo = self.calculate_policy_adv(i, ["tmp", "tmp", "tmp", "tmp", "tmp", "original", "original",
                                                           "tmp", "original", "original"])
            adv_tttttootot = self.calculate_policy_adv(i, ["tmp", "tmp", "tmp", "tmp", "tmp", "original", "original",
                                                           "tmp", "original", "tmp"])
            adv_tttttootto = self.calculate_policy_adv(i, ["tmp", "tmp", "tmp", "tmp", "tmp", "original", "original",
                                                           "tmp", "tmp", "original"])
            adv_tttttoottt = self.calculate_policy_adv(i, ["tmp", "tmp", "tmp", "tmp", "tmp", "original", "original",
                                                           "tmp", "tmp", "tmp"])
            adv_tttttotooo = self.calculate_policy_adv(i, ["tmp", "tmp", "tmp", "tmp", "tmp", "original", "tmp",
                                                           "original", "original", "original"])
            adv_tttttotoot = self.calculate_policy_adv(i, ["tmp", "tmp", "tmp", "tmp", "tmp", "original", "tmp",
                                                           "original", "original", "tmp"])
            adv_tttttototo = self.calculate_policy_adv(i, ["tmp", "tmp", "tmp", "tmp", "tmp", "original", "tmp",
                                                           "original", "tmp", "original"])
            adv_tttttotott = self.calculate_policy_adv(i, ["tmp", "tmp", "tmp", "tmp", "tmp", "original", "tmp",
                                                           "original", "tmp", "tmp"])
            adv_tttttottoo = self.calculate_policy_adv(i, ["tmp", "tmp", "tmp", "tmp", "tmp", "original", "tmp", "tmp",
                                                           "original", "original"])
            adv_tttttottot = self.calculate_policy_adv(i, ["tmp", "tmp", "tmp", "tmp", "tmp", "original", "tmp", "tmp",
                                                           "original", "tmp"])
            adv_tttttottto = self.calculate_policy_adv(i, ["tmp", "tmp", "tmp", "tmp", "tmp", "original", "tmp", "tmp",
                                                           "tmp", "original"])
            adv_tttttotttt = self.calculate_policy_adv(i, ["tmp", "tmp", "tmp", "tmp", "tmp", "original", "tmp", "tmp",
                                                           "tmp", "tmp"])
            adv_ttttttoooo = self.calculate_policy_adv(i, ["tmp", "tmp", "tmp", "tmp", "tmp", "tmp", "original",
                                                           "original", "original", "original"])
            adv_ttttttooot = self.calculate_policy_adv(i, ["tmp", "tmp", "tmp", "tmp", "tmp", "tmp", "original",
                                                           "original", "original", "tmp"])
            adv_ttttttooto = self.calculate_policy_adv(i, ["tmp", "tmp", "tmp", "tmp", "tmp", "tmp", "original",
                                                           "original", "tmp", "original"])
            adv_ttttttoott = self.calculate_policy_adv(i, ["tmp", "tmp", "tmp", "tmp", "tmp", "tmp", "original",
                                                           "original", "tmp", "tmp"])
            adv_ttttttotoo = self.calculate_policy_adv(i, ["tmp", "tmp", "tmp", "tmp", "tmp", "tmp", "original", "tmp",
                                                           "original", "original"])
            adv_ttttttotot = self.calculate_policy_adv(i, ["tmp", "tmp", "tmp", "tmp", "tmp", "tmp", "original", "tmp",
                                                           "original", "tmp"])
            adv_ttttttotto = self.calculate_policy_adv(i, ["tmp", "tmp", "tmp", "tmp", "tmp", "tmp", "original", "tmp",
                                                           "tmp", "original"])
            adv_ttttttottt = self.calculate_policy_adv(i, ["tmp", "tmp", "tmp", "tmp", "tmp", "tmp", "original", "tmp",
                                                           "tmp", "tmp"])
            adv_tttttttooo = self.calculate_policy_adv(i, ["tmp", "tmp", "tmp", "tmp", "tmp", "tmp", "tmp", "original",
                                                           "original", "original"])
            adv_tttttttoot = self.calculate_policy_adv(i, ["tmp", "tmp", "tmp", "tmp", "tmp", "tmp", "tmp", "original",
                                                           "original", "tmp"])
            adv_tttttttoto = self.calculate_policy_adv(i, ["tmp", "tmp", "tmp", "tmp", "tmp", "tmp", "tmp", "original",
                                                           "tmp", "original"])
            adv_tttttttott = self.calculate_policy_adv(i, ["tmp", "tmp", "tmp", "tmp", "tmp", "tmp", "tmp", "original",
                                                           "tmp", "tmp"])
            adv_ttttttttoo = self.calculate_policy_adv(i, ["tmp", "tmp", "tmp", "tmp", "tmp", "tmp", "tmp", "tmp",
                                                           "original", "original"])
            adv_ttttttttot = self.calculate_policy_adv(i, ["tmp", "tmp", "tmp", "tmp", "tmp", "tmp", "tmp", "tmp",
                                                           "original", "tmp"])
            adv_ttttttttto = self.calculate_policy_adv(i,
                                                       ["tmp", "tmp", "tmp", "tmp", "tmp", "tmp", "tmp", "tmp", "tmp",
                                                        "original"])
            adv_tttttttttt = self.calculate_policy_adv(i,
                                                       ["tmp", "tmp", "tmp", "tmp", "tmp", "tmp", "tmp", "tmp", "tmp",
                                                        "tmp"])

            A = np.array([[[[[[[[[[0, adv_ooooooooot], [adv_ooooooooto, adv_oooooooott]],
                                 [[adv_oooooootoo, adv_oooooootot], [adv_oooooootto, adv_ooooooottt]]],
                                [[[adv_ooooootooo, adv_ooooootoot], [adv_oooooototo, adv_ooooootott]],
                                 [[adv_oooooottoo, adv_oooooottot], [adv_oooooottto, adv_ooooootttt]]]], [
                                   [[[adv_oooootoooo, adv_oooootooot], [adv_oooootooto, adv_oooootoott]],
                                    [[adv_ooooototoo, adv_ooooototot], [adv_ooooototto, adv_oooootottt]]],
                                   [[[adv_ooooottooo, adv_ooooottoot], [adv_ooooottoto, adv_ooooottott]],
                                    [[adv_oooootttoo, adv_oooootttot], [adv_oooootttto, adv_ooooottttt]]]]], [[[[[
                adv_ooootooooo,
                adv_ooootoooot],
                [
                    adv_ooootoooto,
                    adv_ooootooott]],
                [[
                    adv_ooootootoo,
                    adv_ooootootot],
                    [
                        adv_ooootootto,
                        adv_ooootoottt]]],
                [[[
                    adv_oooototooo,
                    adv_oooototoot],
                    [
                        adv_ooootototo,
                        adv_oooototott]],
                    [[
                        adv_ooootottoo,
                        adv_ooootottot],
                        [
                            adv_ooootottto,
                            adv_oooototttt]]]],
                                  [[[[
                                      adv_oooottoooo,
                                      adv_oooottooot],
                                      [
                                          adv_oooottooto,
                                          adv_oooottoott]],
                                      [[
                                          adv_oooottotoo,
                                          adv_oooottotot],
                                          [
                                              adv_oooottotto,
                                              adv_oooottottt]]],
                                      [[[
                                          adv_ooootttooo,
                                          adv_ooootttoot],
                                          [
                                              adv_ooootttoto,
                                              adv_ooootttott]],
                                          [[
                                              adv_oooottttoo,
                                              adv_oooottttot],
                                              [
                                                  adv_oooottttto,
                                                  adv_ooootttttt]]]]]],
                             [[[[[[adv_oootoooooo, adv_oootooooot], [adv_oootooooto, adv_oootoooott]],
                                 [[adv_oootoootoo, adv_oootoootot], [adv_oootoootto, adv_oootooottt]]],
                                [[[adv_oootootooo, adv_oootootoot], [adv_oootoototo, adv_oootootott]],
                                 [[adv_oootoottoo, adv_oootoottot], [adv_oootoottto, adv_oootootttt]]]], [
                                   [[[adv_ooototoooo, adv_ooototooot], [adv_ooototooto, adv_ooototoott]],
                                    [[adv_oootototoo, adv_oootototot], [adv_oootototto, adv_ooototottt]]],
                                   [[[adv_oootottooo, adv_oootottoot], [adv_oootottoto, adv_oootottott]],
                                    [[adv_ooototttoo, adv_ooototttot], [adv_ooototttto, adv_oootottttt]]]]], [[[[[
                                 adv_ooottooooo,
                                 adv_ooottoooot],
                                 [
                                     adv_ooottoooto,
                                     adv_ooottooott]],
                                 [[
                                     adv_ooottootoo,
                                     adv_ooottootot],
                                     [
                                         adv_ooottootto,
                                         adv_ooottoottt]]],
                                 [[[
                                     adv_ooottotooo,
                                     adv_ooottotoot],
                                     [
                                         adv_ooottototo,
                                         adv_ooottotott]],
                                     [[
                                         adv_ooottottoo,
                                         adv_ooottottot],
                                         [
                                             adv_ooottottto,
                                             adv_ooottotttt]]]],
                                  [[[[
                                      adv_oootttoooo,
                                      adv_oootttooot],
                                      [
                                          adv_oootttooto,
                                          adv_oootttoott]],
                                      [[
                                          adv_oootttotoo,
                                          adv_oootttotot],
                                          [
                                              adv_oootttotto,
                                              adv_oootttottt]]],
                                      [[[
                                          adv_ooottttooo,
                                          adv_ooottttoot],
                                          [
                                              adv_ooottttoto,
                                              adv_ooottttott]],
                                          [[
                                              adv_oootttttoo,
                                              adv_oootttttot],
                                              [
                                                  adv_oootttttto,
                                                  adv_ooottttttt]]]]]]],
                            [[[[[[[adv_ootooooooo, adv_ootoooooot], [adv_ootoooooto, adv_ootooooott]],
                                 [[adv_ootooootoo, adv_ootooootot], [adv_ootooootto, adv_ootoooottt]]],
                                [[[adv_ootoootooo, adv_ootoootoot], [adv_ootooototo, adv_ootoootott]],
                                 [[adv_ootooottoo, adv_ootooottot], [adv_ootooottto, adv_ootoootttt]]]], [
                                   [[[adv_ootootoooo, adv_ootootooot], [adv_ootootooto, adv_ootootoott]],
                                    [[adv_ootoototoo, adv_ootoototot], [adv_ootoototto, adv_ootootottt]]],
                                   [[[adv_ootoottooo, adv_ootoottoot], [adv_ootoottoto, adv_ootoottott]],
                                    [[adv_ootootttoo, adv_ootootttot], [adv_ootootttto, adv_ootoottttt]]]]], [[[[[
                                adv_oototooooo,
                                adv_oototoooot],
                                [
                                    adv_oototoooto,
                                    adv_oototooott]],
                                [[
                                    adv_oototootoo,
                                    adv_oototootot],
                                    [
                                        adv_oototootto,
                                        adv_oototoottt]]],
                                [[[
                                    adv_ootototooo,
                                    adv_ootototoot],
                                    [
                                        adv_oototototo,
                                        adv_ootototott]],
                                    [[
                                        adv_oototottoo,
                                        adv_oototottot],
                                        [
                                            adv_oototottto,
                                            adv_ootototttt]]]],
                                  [[[[
                                      adv_ootottoooo,
                                      adv_ootottooot],
                                      [
                                          adv_ootottooto,
                                          adv_ootottoott]],
                                      [[
                                          adv_ootottotoo,
                                          adv_ootottotot],
                                          [
                                              adv_ootottotto,
                                              adv_ootottottt]]],
                                      [[[
                                          adv_oototttooo,
                                          adv_oototttoot],
                                          [
                                              adv_oototttoto,
                                              adv_oototttott]],
                                          [[
                                              adv_ootottttoo,
                                              adv_ootottttot],
                                              [
                                                  adv_ootottttto,
                                                  adv_oototttttt]]]]]],
                             [[[[[[adv_oottoooooo, adv_oottooooot], [adv_oottooooto, adv_oottoooott]],
                                 [[adv_oottoootoo, adv_oottoootot], [adv_oottoootto, adv_oottooottt]]],
                                [[[adv_oottootooo, adv_oottootoot], [adv_oottoototo, adv_oottootott]],
                                 [[adv_oottoottoo, adv_oottoottot], [adv_oottoottto, adv_oottootttt]]]], [
                                   [[[adv_oottotoooo, adv_oottotooot], [adv_oottotooto, adv_oottotoott]],
                                    [[adv_oottototoo, adv_oottototot], [adv_oottototto, adv_oottotottt]]],
                                   [[[adv_oottottooo, adv_oottottoot], [adv_oottottoto, adv_oottottott]],
                                    [[adv_oottotttoo, adv_oottotttot], [adv_oottotttto, adv_oottottttt]]]]], [[[[[
                                 adv_ootttooooo,
                                 adv_ootttoooot],
                                 [
                                     adv_ootttoooto,
                                     adv_ootttooott]],
                                 [[
                                     adv_ootttootoo,
                                     adv_ootttootot],
                                     [
                                         adv_ootttootto,
                                         adv_ootttoottt]]],
                                 [[[
                                     adv_ootttotooo,
                                     adv_ootttotoot],
                                     [
                                         adv_ootttototo,
                                         adv_ootttotott]],
                                     [[
                                         adv_ootttottoo,
                                         adv_ootttottot],
                                         [
                                             adv_ootttottto,
                                             adv_ootttotttt]]]],
                                  [[[[
                                      adv_oottttoooo,
                                      adv_oottttooot],
                                      [
                                          adv_oottttooto,
                                          adv_oottttoott]],
                                      [[
                                          adv_oottttotoo,
                                          adv_oottttotot],
                                          [
                                              adv_oottttotto,
                                              adv_oottttottt]]],
                                      [[[
                                          adv_ootttttooo,
                                          adv_ootttttoot],
                                          [
                                              adv_ootttttoto,
                                              adv_ootttttott]],
                                          [[
                                              adv_oottttttoo,
                                              adv_oottttttot],
                                              [
                                                  adv_oottttttto,
                                                  adv_ootttttttt]]]]]]]],
                           [[[[[[[[adv_otoooooooo, adv_otooooooot], [adv_otooooooto, adv_otoooooott]],
                                 [[adv_otoooootoo, adv_otoooootot], [adv_otoooootto, adv_otooooottt]]],
                                [[[adv_otooootooo, adv_otooootoot], [adv_otoooototo, adv_otooootott]],
                                 [[adv_otoooottoo, adv_otoooottot], [adv_otoooottto, adv_otooootttt]]]], [
                                   [[[adv_otoootoooo, adv_otoootooot], [adv_otoootooto, adv_otoootoott]],
                                    [[adv_otooototoo, adv_otooototot], [adv_otooototto, adv_otoootottt]]],
                                   [[[adv_otooottooo, adv_otooottoot], [adv_otooottoto, adv_otooottott]],
                                    [[adv_otoootttoo, adv_otoootttot], [adv_otoootttto, adv_otooottttt]]]]], [[[[[
                               adv_otootooooo,
                               adv_otootoooot],
                               [
                                   adv_otootoooto,
                                   adv_otootooott]],
                               [[
                                   adv_otootootoo,
                                   adv_otootootot],
                                   [
                                       adv_otootootto,
                                       adv_otootoottt]]],
                               [[[
                                   adv_otoototooo,
                                   adv_otoototoot],
                                   [
                                       adv_otootototo,
                                       adv_otoototott]],
                                   [[
                                       adv_otootottoo,
                                       adv_otootottot],
                                       [
                                           adv_otootottto,
                                           adv_otoototttt]]]],
                                  [[[[
                                      adv_otoottoooo,
                                      adv_otoottooot],
                                      [
                                          adv_otoottooto,
                                          adv_otoottoott]],
                                      [[
                                          adv_otoottotoo,
                                          adv_otoottotot],
                                          [
                                              adv_otoottotto,
                                              adv_otoottottt]]],
                                      [[[
                                          adv_otootttooo,
                                          adv_otootttoot],
                                          [
                                              adv_otootttoto,
                                              adv_otootttott]],
                                          [[
                                              adv_otoottttoo,
                                              adv_otoottttot],
                                              [
                                                  adv_otoottttto,
                                                  adv_otootttttt]]]]]],
                             [[[[[[adv_ototoooooo, adv_ototooooot], [adv_ototooooto, adv_ototoooott]],
                                 [[adv_ototoootoo, adv_ototoootot], [adv_ototoootto, adv_ototooottt]]],
                                [[[adv_ototootooo, adv_ototootoot], [adv_ototoototo, adv_ototootott]],
                                 [[adv_ototoottoo, adv_ototoottot], [adv_ototoottto, adv_ototootttt]]]], [
                                   [[[adv_otototoooo, adv_otototooot], [adv_otototooto, adv_otototoott]],
                                    [[adv_ototototoo, adv_ototototot], [adv_ototototto, adv_otototottt]]],
                                   [[[adv_ototottooo, adv_ototottoot], [adv_ototottoto, adv_ototottott]],
                                    [[adv_otototttoo, adv_otototttot], [adv_otototttto, adv_ototottttt]]]]], [[[[[
                                 adv_otottooooo,
                                 adv_otottoooot],
                                 [
                                     adv_otottoooto,
                                     adv_otottooott]],
                                 [[
                                     adv_otottootoo,
                                     adv_otottootot],
                                     [
                                         adv_otottootto,
                                         adv_otottoottt]]],
                                 [[[
                                     adv_otottotooo,
                                     adv_otottotoot],
                                     [
                                         adv_otottototo,
                                         adv_otottotott]],
                                     [[
                                         adv_otottottoo,
                                         adv_otottottot],
                                         [
                                             adv_otottottto,
                                             adv_otottotttt]]]],
                                  [[[[
                                      adv_ototttoooo,
                                      adv_ototttooot],
                                      [
                                          adv_ototttooto,
                                          adv_ototttoott]],
                                      [[
                                          adv_ototttotoo,
                                          adv_ototttotot],
                                          [
                                              adv_ototttotto,
                                              adv_ototttottt]]],
                                      [[[
                                          adv_otottttooo,
                                          adv_otottttoot],
                                          [
                                              adv_otottttoto,
                                              adv_otottttott]],
                                          [[
                                              adv_ototttttoo,
                                              adv_ototttttot],
                                              [
                                                  adv_ototttttto,
                                                  adv_otottttttt]]]]]]],
                            [[[[[[[adv_ottooooooo, adv_ottoooooot], [adv_ottoooooto, adv_ottooooott]],
                                 [[adv_ottooootoo, adv_ottooootot], [adv_ottooootto, adv_ottoooottt]]],
                                [[[adv_ottoootooo, adv_ottoootoot], [adv_ottooototo, adv_ottoootott]],
                                 [[adv_ottooottoo, adv_ottooottot], [adv_ottooottto, adv_ottoootttt]]]], [
                                   [[[adv_ottootoooo, adv_ottootooot], [adv_ottootooto, adv_ottootoott]],
                                    [[adv_ottoototoo, adv_ottoototot], [adv_ottoototto, adv_ottootottt]]],
                                   [[[adv_ottoottooo, adv_ottoottoot], [adv_ottoottoto, adv_ottoottott]],
                                    [[adv_ottootttoo, adv_ottootttot], [adv_ottootttto, adv_ottoottttt]]]]], [[[[[
                                adv_ottotooooo,
                                adv_ottotoooot],
                                [
                                    adv_ottotoooto,
                                    adv_ottotooott]],
                                [[
                                    adv_ottotootoo,
                                    adv_ottotootot],
                                    [
                                        adv_ottotootto,
                                        adv_ottotoottt]]],
                                [[[
                                    adv_ottototooo,
                                    adv_ottototoot],
                                    [
                                        adv_ottotototo,
                                        adv_ottototott]],
                                    [[
                                        adv_ottotottoo,
                                        adv_ottotottot],
                                        [
                                            adv_ottotottto,
                                            adv_ottototttt]]]],
                                  [[[[
                                      adv_ottottoooo,
                                      adv_ottottooot],
                                      [
                                          adv_ottottooto,
                                          adv_ottottoott]],
                                      [[
                                          adv_ottottotoo,
                                          adv_ottottotot],
                                          [
                                              adv_ottottotto,
                                              adv_ottottottt]]],
                                      [[[
                                          adv_ottotttooo,
                                          adv_ottotttoot],
                                          [
                                              adv_ottotttoto,
                                              adv_ottotttott]],
                                          [[
                                              adv_ottottttoo,
                                              adv_ottottttot],
                                              [
                                                  adv_ottottttto,
                                                  adv_ottotttttt]]]]]],
                             [[[[[[adv_otttoooooo, adv_otttooooot], [adv_otttooooto, adv_otttoooott]],
                                 [[adv_otttoootoo, adv_otttoootot], [adv_otttoootto, adv_otttooottt]]],
                                [[[adv_otttootooo, adv_otttootoot], [adv_otttoototo, adv_otttootott]],
                                 [[adv_otttoottoo, adv_otttoottot], [adv_otttoottto, adv_otttootttt]]]], [
                                   [[[adv_otttotoooo, adv_otttotooot], [adv_otttotooto, adv_otttotoott]],
                                    [[adv_otttototoo, adv_otttototot], [adv_otttototto, adv_otttotottt]]],
                                   [[[adv_otttottooo, adv_otttottoot], [adv_otttottoto, adv_otttottott]],
                                    [[adv_otttotttoo, adv_otttotttot], [adv_otttotttto, adv_otttottttt]]]]], [[[[[
                                 adv_ottttooooo,
                                 adv_ottttoooot],
                                 [
                                     adv_ottttoooto,
                                     adv_ottttooott]],
                                 [[
                                     adv_ottttootoo,
                                     adv_ottttootot],
                                     [
                                         adv_ottttootto,
                                         adv_ottttoottt]]],
                                 [[[
                                     adv_ottttotooo,
                                     adv_ottttotoot],
                                     [
                                         adv_ottttototo,
                                         adv_ottttotott]],
                                     [[
                                         adv_ottttottoo,
                                         adv_ottttottot],
                                         [
                                             adv_ottttottto,
                                             adv_ottttotttt]]]],
                                  [[[[
                                      adv_otttttoooo,
                                      adv_otttttooot],
                                      [
                                          adv_otttttooto,
                                          adv_otttttoott]],
                                      [[
                                          adv_otttttotoo,
                                          adv_otttttotot],
                                          [
                                              adv_otttttotto,
                                              adv_otttttottt]]],
                                      [[[
                                          adv_ottttttooo,
                                          adv_ottttttoot],
                                          [
                                              adv_ottttttoto,
                                              adv_ottttttott]],
                                          [[
                                              adv_otttttttoo,
                                              adv_otttttttot],
                                              [
                                                  adv_otttttttto,
                                                  adv_ottttttttt]]]]]]]]],
                          [[[[[[[[[adv_tooooooooo, adv_toooooooot], [adv_toooooooto, adv_tooooooott]],
                                 [[adv_tooooootoo, adv_tooooootot], [adv_tooooootto, adv_toooooottt]]],
                                [[[adv_toooootooo, adv_toooootoot], [adv_tooooototo, adv_toooootott]],
                                 [[adv_tooooottoo, adv_tooooottot], [adv_tooooottto, adv_toooootttt]]]], [
                                   [[[adv_tooootoooo, adv_tooootooot], [adv_tooootooto, adv_tooootoott]],
                                    [[adv_toooototoo, adv_toooototot], [adv_toooototto, adv_tooootottt]]],
                                   [[[adv_toooottooo, adv_toooottoot], [adv_toooottoto, adv_toooottott]],
                                    [[adv_tooootttoo, adv_tooootttot], [adv_tooootttto, adv_toooottttt]]]]], [[[[[
                              adv_toootooooo,
                              adv_toootoooot],
                              [
                                  adv_toootoooto,
                                  adv_toootooott]],
                              [[
                                  adv_toootootoo,
                                  adv_toootootot],
                                  [
                                      adv_toootootto,
                                      adv_toootoottt]]],
                              [[[
                                  adv_tooototooo,
                                  adv_tooototoot],
                                  [
                                      adv_toootototo,
                                      adv_tooototott]],
                                  [[
                                      adv_toootottoo,
                                      adv_toootottot],
                                      [
                                          adv_toootottto,
                                          adv_tooototttt]]]],
                                  [[[[
                                      adv_tooottoooo,
                                      adv_tooottooot],
                                      [
                                          adv_tooottooto,
                                          adv_tooottoott]],
                                      [[
                                          adv_tooottotoo,
                                          adv_tooottotot],
                                          [
                                              adv_tooottotto,
                                              adv_tooottottt]]],
                                      [[[
                                          adv_toootttooo,
                                          adv_toootttoot],
                                          [
                                              adv_toootttoto,
                                              adv_toootttott]],
                                          [[
                                              adv_tooottttoo,
                                              adv_tooottttot],
                                              [
                                                  adv_tooottttto,
                                                  adv_toootttttt]]]]]],
                             [[[[[[adv_tootoooooo, adv_tootooooot], [adv_tootooooto, adv_tootoooott]],
                                 [[adv_tootoootoo, adv_tootoootot], [adv_tootoootto, adv_tootooottt]]],
                                [[[adv_tootootooo, adv_tootootoot], [adv_tootoototo, adv_tootootott]],
                                 [[adv_tootoottoo, adv_tootoottot], [adv_tootoottto, adv_tootootttt]]]], [
                                   [[[adv_toototoooo, adv_toototooot], [adv_toototooto, adv_toototoott]],
                                    [[adv_tootototoo, adv_tootototot], [adv_tootototto, adv_toototottt]]],
                                   [[[adv_tootottooo, adv_tootottoot], [adv_tootottoto, adv_tootottott]],
                                    [[adv_toototttoo, adv_toototttot], [adv_toototttto, adv_tootottttt]]]]], [[[[[
                                 adv_toottooooo,
                                 adv_toottoooot],
                                 [
                                     adv_toottoooto,
                                     adv_toottooott]],
                                 [[
                                     adv_toottootoo,
                                     adv_toottootot],
                                     [
                                         adv_toottootto,
                                         adv_toottoottt]]],
                                 [[[
                                     adv_toottotooo,
                                     adv_toottotoot],
                                     [
                                         adv_toottototo,
                                         adv_toottotott]],
                                     [[
                                         adv_toottottoo,
                                         adv_toottottot],
                                         [
                                             adv_toottottto,
                                             adv_toottotttt]]]],
                                  [[[[
                                      adv_tootttoooo,
                                      adv_tootttooot],
                                      [
                                          adv_tootttooto,
                                          adv_tootttoott]],
                                      [[
                                          adv_tootttotoo,
                                          adv_tootttotot],
                                          [
                                              adv_tootttotto,
                                              adv_tootttottt]]],
                                      [[[
                                          adv_toottttooo,
                                          adv_toottttoot],
                                          [
                                              adv_toottttoto,
                                              adv_toottttott]],
                                          [[
                                              adv_tootttttoo,
                                              adv_tootttttot],
                                              [
                                                  adv_tootttttto,
                                                  adv_toottttttt]]]]]]],
                            [[[[[[[adv_totooooooo, adv_totoooooot], [adv_totoooooto, adv_totooooott]],
                                 [[adv_totooootoo, adv_totooootot], [adv_totooootto, adv_totoooottt]]],
                                [[[adv_totoootooo, adv_totoootoot], [adv_totooototo, adv_totoootott]],
                                 [[adv_totooottoo, adv_totooottot], [adv_totooottto, adv_totoootttt]]]], [
                                   [[[adv_totootoooo, adv_totootooot], [adv_totootooto, adv_totootoott]],
                                    [[adv_totoototoo, adv_totoototot], [adv_totoototto, adv_totootottt]]],
                                   [[[adv_totoottooo, adv_totoottoot], [adv_totoottoto, adv_totoottott]],
                                    [[adv_totootttoo, adv_totootttot], [adv_totootttto, adv_totoottttt]]]]], [[[[[
                                adv_tototooooo,
                                adv_tototoooot],
                                [
                                    adv_tototoooto,
                                    adv_tototooott]],
                                [[
                                    adv_tototootoo,
                                    adv_tototootot],
                                    [
                                        adv_tototootto,
                                        adv_tototoottt]]],
                                [[[
                                    adv_totototooo,
                                    adv_totototoot],
                                    [
                                        adv_tototototo,
                                        adv_totototott]],
                                    [[
                                        adv_tototottoo,
                                        adv_tototottot],
                                        [
                                            adv_tototottto,
                                            adv_totototttt]]]],
                                  [[[[
                                      adv_totottoooo,
                                      adv_totottooot],
                                      [
                                          adv_totottooto,
                                          adv_totottoott]],
                                      [[
                                          adv_totottotoo,
                                          adv_totottotot],
                                          [
                                              adv_totottotto,
                                              adv_totottottt]]],
                                      [[[
                                          adv_tototttooo,
                                          adv_tototttoot],
                                          [
                                              adv_tototttoto,
                                              adv_tototttott]],
                                          [[
                                              adv_totottttoo,
                                              adv_totottttot],
                                              [
                                                  adv_totottttto,
                                                  adv_tototttttt]]]]]],
                             [[[[[[adv_tottoooooo, adv_tottooooot], [adv_tottooooto, adv_tottoooott]],
                                 [[adv_tottoootoo, adv_tottoootot], [adv_tottoootto, adv_tottooottt]]],
                                [[[adv_tottootooo, adv_tottootoot], [adv_tottoototo, adv_tottootott]],
                                 [[adv_tottoottoo, adv_tottoottot], [adv_tottoottto, adv_tottootttt]]]], [
                                   [[[adv_tottotoooo, adv_tottotooot], [adv_tottotooto, adv_tottotoott]],
                                    [[adv_tottototoo, adv_tottototot], [adv_tottototto, adv_tottotottt]]],
                                   [[[adv_tottottooo, adv_tottottoot], [adv_tottottoto, adv_tottottott]],
                                    [[adv_tottotttoo, adv_tottotttot], [adv_tottotttto, adv_tottottttt]]]]], [[[[[
                                 adv_totttooooo,
                                 adv_totttoooot],
                                 [
                                     adv_totttoooto,
                                     adv_totttooott]],
                                 [[
                                     adv_totttootoo,
                                     adv_totttootot],
                                     [
                                         adv_totttootto,
                                         adv_totttoottt]]],
                                 [[[
                                     adv_totttotooo,
                                     adv_totttotoot],
                                     [
                                         adv_totttototo,
                                         adv_totttotott]],
                                     [[
                                         adv_totttottoo,
                                         adv_totttottot],
                                         [
                                             adv_totttottto,
                                             adv_totttotttt]]]],
                                  [[[[
                                      adv_tottttoooo,
                                      adv_tottttooot],
                                      [
                                          adv_tottttooto,
                                          adv_tottttoott]],
                                      [[
                                          adv_tottttotoo,
                                          adv_tottttotot],
                                          [
                                              adv_tottttotto,
                                              adv_tottttottt]]],
                                      [[[
                                          adv_totttttooo,
                                          adv_totttttoot],
                                          [
                                              adv_totttttoto,
                                              adv_totttttott]],
                                          [[
                                              adv_tottttttoo,
                                              adv_tottttttot],
                                              [
                                                  adv_tottttttto,
                                                  adv_totttttttt]]]]]]]],
                           [[[[[[[[adv_ttoooooooo, adv_ttooooooot], [adv_ttooooooto, adv_ttoooooott]],
                                 [[adv_ttoooootoo, adv_ttoooootot], [adv_ttoooootto, adv_ttooooottt]]],
                                [[[adv_ttooootooo, adv_ttooootoot], [adv_ttoooototo, adv_ttooootott]],
                                 [[adv_ttoooottoo, adv_ttoooottot], [adv_ttoooottto, adv_ttooootttt]]]], [
                                   [[[adv_ttoootoooo, adv_ttoootooot], [adv_ttoootooto, adv_ttoootoott]],
                                    [[adv_ttooototoo, adv_ttooototot], [adv_ttooototto, adv_ttoootottt]]],
                                   [[[adv_ttooottooo, adv_ttooottoot], [adv_ttooottoto, adv_ttooottott]],
                                    [[adv_ttoootttoo, adv_ttoootttot], [adv_ttoootttto, adv_ttooottttt]]]]], [[[[[
                               adv_ttootooooo,
                               adv_ttootoooot],
                               [
                                   adv_ttootoooto,
                                   adv_ttootooott]],
                               [[
                                   adv_ttootootoo,
                                   adv_ttootootot],
                                   [
                                       adv_ttootootto,
                                       adv_ttootoottt]]],
                               [[[
                                   adv_ttoototooo,
                                   adv_ttoototoot],
                                   [
                                       adv_ttootototo,
                                       adv_ttoototott]],
                                   [[
                                       adv_ttootottoo,
                                       adv_ttootottot],
                                       [
                                           adv_ttootottto,
                                           adv_ttoototttt]]]],
                                  [[[[
                                      adv_ttoottoooo,
                                      adv_ttoottooot],
                                      [
                                          adv_ttoottooto,
                                          adv_ttoottoott]],
                                      [[
                                          adv_ttoottotoo,
                                          adv_ttoottotot],
                                          [
                                              adv_ttoottotto,
                                              adv_ttoottottt]]],
                                      [[[
                                          adv_ttootttooo,
                                          adv_ttootttoot],
                                          [
                                              adv_ttootttoto,
                                              adv_ttootttott]],
                                          [[
                                              adv_ttoottttoo,
                                              adv_ttoottttot],
                                              [
                                                  adv_ttoottttto,
                                                  adv_ttootttttt]]]]]],
                             [[[[[[adv_ttotoooooo, adv_ttotooooot], [adv_ttotooooto, adv_ttotoooott]],
                                 [[adv_ttotoootoo, adv_ttotoootot], [adv_ttotoootto, adv_ttotooottt]]],
                                [[[adv_ttotootooo, adv_ttotootoot], [adv_ttotoototo, adv_ttotootott]],
                                 [[adv_ttotoottoo, adv_ttotoottot], [adv_ttotoottto, adv_ttotootttt]]]], [
                                   [[[adv_ttototoooo, adv_ttototooot], [adv_ttototooto, adv_ttototoott]],
                                    [[adv_ttotototoo, adv_ttotototot], [adv_ttotototto, adv_ttototottt]]],
                                   [[[adv_ttotottooo, adv_ttotottoot], [adv_ttotottoto, adv_ttotottott]],
                                    [[adv_ttototttoo, adv_ttototttot], [adv_ttototttto, adv_ttotottttt]]]]], [[[[[
                                 adv_ttottooooo,
                                 adv_ttottoooot],
                                 [
                                     adv_ttottoooto,
                                     adv_ttottooott]],
                                 [[
                                     adv_ttottootoo,
                                     adv_ttottootot],
                                     [
                                         adv_ttottootto,
                                         adv_ttottoottt]]],
                                 [[[
                                     adv_ttottotooo,
                                     adv_ttottotoot],
                                     [
                                         adv_ttottototo,
                                         adv_ttottotott]],
                                     [[
                                         adv_ttottottoo,
                                         adv_ttottottot],
                                         [
                                             adv_ttottottto,
                                             adv_ttottotttt]]]],
                                  [[[[
                                      adv_ttotttoooo,
                                      adv_ttotttooot],
                                      [
                                          adv_ttotttooto,
                                          adv_ttotttoott]],
                                      [[
                                          adv_ttotttotoo,
                                          adv_ttotttotot],
                                          [
                                              adv_ttotttotto,
                                              adv_ttotttottt]]],
                                      [[[
                                          adv_ttottttooo,
                                          adv_ttottttoot],
                                          [
                                              adv_ttottttoto,
                                              adv_ttottttott]],
                                          [[
                                              adv_ttotttttoo,
                                              adv_ttotttttot],
                                              [
                                                  adv_ttotttttto,
                                                  adv_ttottttttt]]]]]]],
                            [[[[[[[adv_tttooooooo, adv_tttoooooot], [adv_tttoooooto, adv_tttooooott]],
                                 [[adv_tttooootoo, adv_tttooootot], [adv_tttooootto, adv_tttoooottt]]],
                                [[[adv_tttoootooo, adv_tttoootoot], [adv_tttooototo, adv_tttoootott]],
                                 [[adv_tttooottoo, adv_tttooottot], [adv_tttooottto, adv_tttoootttt]]]], [
                                   [[[adv_tttootoooo, adv_tttootooot], [adv_tttootooto, adv_tttootoott]],
                                    [[adv_tttoototoo, adv_tttoototot], [adv_tttoototto, adv_tttootottt]]],
                                   [[[adv_tttoottooo, adv_tttoottoot], [adv_tttoottoto, adv_tttoottott]],
                                    [[adv_tttootttoo, adv_tttootttot], [adv_tttootttto, adv_tttoottttt]]]]], [[[[[
                                adv_tttotooooo,
                                adv_tttotoooot],
                                [
                                    adv_tttotoooto,
                                    adv_tttotooott]],
                                [[
                                    adv_tttotootoo,
                                    adv_tttotootot],
                                    [
                                        adv_tttotootto,
                                        adv_tttotoottt]]],
                                [[[
                                    adv_tttototooo,
                                    adv_tttototoot],
                                    [
                                        adv_tttotototo,
                                        adv_tttototott]],
                                    [[
                                        adv_tttotottoo,
                                        adv_tttotottot],
                                        [
                                            adv_tttotottto,
                                            adv_tttototttt]]]],
                                  [[[[
                                      adv_tttottoooo,
                                      adv_tttottooot],
                                      [
                                          adv_tttottooto,
                                          adv_tttottoott]],
                                      [[
                                          adv_tttottotoo,
                                          adv_tttottotot],
                                          [
                                              adv_tttottotto,
                                              adv_tttottottt]]],
                                      [[[
                                          adv_tttotttooo,
                                          adv_tttotttoot],
                                          [
                                              adv_tttotttoto,
                                              adv_tttotttott]],
                                          [[
                                              adv_tttottttoo,
                                              adv_tttottttot],
                                              [
                                                  adv_tttottttto,
                                                  adv_tttotttttt]]]]]],
                             [[[[[[adv_ttttoooooo, adv_ttttooooot], [adv_ttttooooto, adv_ttttoooott]],
                                 [[adv_ttttoootoo, adv_ttttoootot], [adv_ttttoootto, adv_ttttooottt]]],
                                [[[adv_ttttootooo, adv_ttttootoot], [adv_ttttoototo, adv_ttttootott]],
                                 [[adv_ttttoottoo, adv_ttttoottot], [adv_ttttoottto, adv_ttttootttt]]]], [
                                   [[[adv_ttttotoooo, adv_ttttotooot], [adv_ttttotooto, adv_ttttotoott]],
                                    [[adv_ttttototoo, adv_ttttototot], [adv_ttttototto, adv_ttttotottt]]],
                                   [[[adv_ttttottooo, adv_ttttottoot], [adv_ttttottoto, adv_ttttottott]],
                                    [[adv_ttttotttoo, adv_ttttotttot], [adv_ttttotttto, adv_ttttottttt]]]]], [[[[[
                                 adv_tttttooooo,
                                 adv_tttttoooot],
                                 [
                                     adv_tttttoooto,
                                     adv_tttttooott]],
                                 [[
                                     adv_tttttootoo,
                                     adv_tttttootot],
                                     [
                                         adv_tttttootto,
                                         adv_tttttoottt]]],
                                 [[[
                                     adv_tttttotooo,
                                     adv_tttttotoot],
                                     [
                                         adv_tttttototo,
                                         adv_tttttotott]],
                                     [[
                                         adv_tttttottoo,
                                         adv_tttttottot],
                                         [
                                             adv_tttttottto,
                                             adv_tttttotttt]]]],
                                  [[[[
                                      adv_ttttttoooo,
                                      adv_ttttttooot],
                                      [
                                          adv_ttttttooto,
                                          adv_ttttttoott]],
                                      [[
                                          adv_ttttttotoo,
                                          adv_ttttttotot],
                                          [
                                              adv_ttttttotto,
                                              adv_ttttttottt]]],
                                      [[[
                                          adv_tttttttooo,
                                          adv_tttttttoot],
                                          [
                                              adv_tttttttoto,
                                              adv_tttttttott]],
                                          [[
                                              adv_ttttttttoo,
                                              adv_ttttttttot],
                                              [
                                                  adv_ttttttttto,
                                                  adv_tttttttttt]]]]]]]]]])
            matrix.append(A)
        return matrix
