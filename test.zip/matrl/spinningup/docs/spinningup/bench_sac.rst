SAC Head-to-Head
=================

HalfCheetah
-----------

.. figure:: ../images/plots/sac/sac_halfcheetah_performance.svg
    :align: center


Hopper
------

.. figure:: ../images/plots/sac/sac_hopper_performance.svg
    :align: center


Walker2d
--------

.. figure:: ../images/plots/sac/sac_walker2d_performance.svg
    :align: center

Swimmer
-------

.. figure:: ../images/plots/sac/sac_swimmer_performance.svg
    :align: center


Ant
---

.. figure:: ../images/plots/sac/sac_ant_performance.svg
    :align: center