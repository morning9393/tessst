TD3 Head-to-Head
=================

HalfCheetah
-----------

.. figure:: ../images/plots/td3/td3_halfcheetah_performance.svg
    :align: center


Hopper
------

.. figure:: ../images/plots/td3/td3_hopper_performance.svg
    :align: center


Walker2d
--------

.. figure:: ../images/plots/td3/td3_walker2d_performance.svg
    :align: center

Swimmer
-------

.. figure:: ../images/plots/td3/td3_swimmer_performance.svg
    :align: center


Ant
---

.. figure:: ../images/plots/td3/td3_ant_performance.svg
    :align: center