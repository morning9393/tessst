Vanilla Policy Gradients Head-to-Head
=====================================

HalfCheetah
-----------

.. figure:: ../images/plots/vpg/vpg_halfcheetah_performance.svg
    :align: center


Hopper
------

.. figure:: ../images/plots/vpg/vpg_hopper_performance.svg
    :align: center


Walker2d
--------

.. figure:: ../images/plots/vpg/vpg_walker2d_performance.svg
    :align: center

Swimmer
-------

.. figure:: ../images/plots/vpg/vpg_swimmer_performance.svg
    :align: center


Ant
---

.. figure:: ../images/plots/vpg/vpg_ant_performance.svg
    :align: center