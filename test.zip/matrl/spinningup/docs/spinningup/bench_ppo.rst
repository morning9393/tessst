Proximal Policy Optimization Head-to-Head
=========================================

HalfCheetah
-----------

.. figure:: ../images/plots/ppo/ppo_halfcheetah_performance.svg
    :align: center


Hopper
------

.. figure:: ../images/plots/ppo/ppo_hopper_performance.svg
    :align: center


Walker2d
--------

.. figure:: ../images/plots/ppo/ppo_walker2d_performance.svg
    :align: center

Swimmer
-------

.. figure:: ../images/plots/ppo/ppo_swimmer_performance.svg
    :align: center


Ant
---

.. figure:: ../images/plots/ppo/ppo_ant_performance.svg
    :align: center