DDPG Head-to-Head
=================

HalfCheetah
-----------

.. figure:: ../images/plots/ddpg/ddpg_halfcheetah_performance.svg
    :align: center


Hopper
------

.. figure:: ../images/plots/ddpg/ddpg_hopper_performance.svg
    :align: center


Walker2d
--------

.. figure:: ../images/plots/ddpg/ddpg_walker2d_performance.svg
    :align: center

Swimmer
-------

.. figure:: ../images/plots/ddpg/ddpg_swimmer_performance.svg
    :align: center


Ant
---

.. figure:: ../images/plots/ddpg/ddpg_ant_performance.svg
    :align: center