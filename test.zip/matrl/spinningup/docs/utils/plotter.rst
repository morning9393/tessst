=======
Plotter
=======

See the page on `plotting results`_ for documentation of the plotter.

.. _`plotting results`: ../user/plotting.html