def trpo(*args, **kwargs):
    print('\n\nUnfortunately, TRPO has not yet been implemented in PyTorch '\
        + 'for Spinning Up. TRPO will migrate some time in the future.\n\n')
    raise NotImplementedError