from onpolicy.envs.starcraft2.multiagentenv import MultiAgentEnv
import numpy as np
import gym
import itertools
from copy import deepcopy
from gym.spaces import Discrete
from ma_gym.envs.combat.combat import Combat

PRE_IDS = {
    'wall': 'W',
    'empty': 'E',
    'agent': 'A',
    'opponent': 'X',
}


class CombatEnv(MultiAgentEnv):
    def __init__(self):
        # self.base_env = gym.make(args['game_name'])
        self.base_env = Combat(grid_shape=(15, 15), n_agents=5, n_opponents=5, step_cost=-0.05, max_steps=1000)
        self.episode_limit = self.base_env._max_steps
        self.n_actions = 5 + self.base_env._n_opponents
        self.n_agents = self.base_env.n_agents

        self.action_space = []
        self.observation_space = []
        self.share_observation_space = []
        for i in range(self.n_agents):
            self.action_space.append(Discrete(self.n_actions))
            self.observation_space.append(self.get_obs_size())
            self.share_observation_space.append(self.get_state_size())

    def step(self, actions):
        actions = np.squeeze(actions, axis=-1)
        obs, reward, terminated, info = self.base_env.step(actions)

        for i in range(self.n_agents):
            if actions[i] > 4 and reward[i] > 0:
                reward[i] += 1
            if info['win']:
                reward[i] += 100

        reward = np.expand_dims(reward, axis=-1)
        return obs, self.get_state(), reward, terminated, info, self.get_avail_actions()

    def get_obs(self):
        """ Returns all agent observations in a list """
        # print('get_obs', self.base_env.get_agent_obs())
        return self.base_env.get_agent_obs()

    def get_obs_agent(self, agent_id):
        """ Returns observation for agent_id """
        # print('get_obs_agent', agent_id, self.get_obs()[agent_id])
        return self.get_obs()[agent_id]

    def get_obs_size(self):
        """ Returns the shape of the observation """
        # return int
        # print('get_obs_size', len(self.get_obs_agent(0)))
        return len(self.get_obs_agent(0))

    def get_state(self):
        """Returns the global state."""
        state = np.array(self.get_obs()).flatten()
        state = np.expand_dims(state, 0).repeat(self.n_agents, axis=0)
        return state
        # return self.global_obs()
        # return self.get_obs_agent(0)

    def global_obs(self):
        grid = self.base_env._full_obs
        agent_h = self.base_env.agent_health
        opp_h = self.base_env.opp_health
        agent_c = self.base_env._agent_cool
        opp_c = self.base_env._opp_cool
        obs = np.zeros((4, 15, 15))
        for row in range(0, 15):
            for col in range(0, 15):
                if PRE_IDS['empty'] not in grid[row][col]:
                    x = grid[row][col]
                    _type = 1 if PRE_IDS['agent'] in x else -1
                    _id = int(x[1:]) - 1  # id
                    obs[0][row][col] = _type
                    obs[1][row][col] = _id
                    obs[2][row][col] = agent_h[_id] if _type == 1 else opp_h[_id]
                    obs[3][row][col] = agent_c[_id] if _type == 1 else opp_c[_id]
                    obs[3][row][col] = 1 if obs[3][row][col] else -1
        obs = np.expand_dims(obs.flatten(), 0).repeat(self.n_agents, axis=0)
        return obs

    def get_state_size(self):
        """ Returns the shape of the state"""
        # print('get_state_size', self.n_agents)
        # return self.n_agents
        # print('get_state_size', self.get_obs_size())
        # return self.get_obs_size()
        has_state_fn = getattr(self.base_env, "get_state", None)
        if has_state_fn:
            return self.base_env.state_size
        else:
            return int(len(self.get_state().flatten()) / self.n_agents)
            # return self.get_obs_size()
        # return self.n_agents

    def get_avail_actions(self):
        """Returns the available actions of all agents in a list."""
        avail_actions = []
        for agent_id in range(self.n_agents):
            avail_agent = self.get_avail_agent_actions(agent_id)
            avail_actions.append(avail_agent)
        return avail_actions

    def get_avail_agent_actions(self, agent_id):
        """ Returns the available actions for agent_id """
        return np.ones(self.n_actions)

    def get_total_actions(self):
        """ Returns the total number of actions an agent could ever take """
        # print('get_total_actions', self.n_actions)
        return self.n_actions

    def reset(self):
        """ Returns initial observations and states"""
        self.base_env.reset()
        return self.get_obs(), self.get_state(), self.get_avail_actions()

    def get_stats(self):
        return None

    def render(self):
        self.base_env.render()

    def close(self):
        self.base_env.close()

    def seed(self, n):
        self.base_env.seed(n)

    def save_replay(self):
        pass

    def all_obs(self):
        def make_obs(pos, shape):
            pos = [round(pos[0] / (shape[0] - 1), 2), round(pos[1] / (shape[1] - 1), self.get_obs_size())]
            if self.get_obs_size() > 2:
                others = [0.] * (self.get_obs_size() - 2)
                pos = pos + others
            return pos

        x = np.arange(self.base_env._grid_shape[0])
        y = np.arange(self.base_env._grid_shape[1])
        obs = np.asarray(list(map(lambda pos: make_obs(pos, self.base_env._grid_shape), itertools.product(x, y))))
        obs_n = [obs] * self.n_agents
        obs_n = np.concatenate(obs_n, axis=1).reshape(-1, self.n_agents, self.get_obs_size())
        return obs_n

    def get_env_info(self):
        state_num = None
        if getattr(self.base_env, "state_num", None):
            state_num = self.base_env.state_num
        else:
            state_num = self.base_env._grid_shape[0] * self.base_env._grid_shape[1]
        all_obs = None
        if getattr(self.base_env, "all_obs", None):
            all_obs = self.base_env.all_obs()
        else:
            all_obs = self.all_obs()

        env_info = {
            "state_shape": self.get_state_size(),
            "obs_shape": self.get_obs_size(),
            "n_actions": self.get_total_actions(),
            "n_agents": self.base_env.n_agents,
            "episode_limit": self.episode_limit,
            'state_num': state_num,
            "all_obs": all_obs
        }
        return env_info
